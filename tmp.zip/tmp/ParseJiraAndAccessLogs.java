package jira_log_analyzer;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.TreeMap;

import jira_log_analyzer.EpLogAnalyzer.EnumReportKind;
import jira_log_analyzer.EpLogAnalyzer.EnumSeverity;
import pojo.PojoJiraLogRowData;
import serviceForLogParser.ConstantsOfJiraLogs;

public class ParseJiraAndAccessLogs {

	public ParseJiraAndAccessLogs(EpLogAnalyzer ep) {
		this.ep = ep;
	}

	private EpLogAnalyzer ep;

	UtilsLogsParsing utilsLogsParsing = new UtilsLogsParsing();
	UtilsLogsSys utilsLogsSys = new UtilsLogsSys();

	public void extractDataFromJiraLogFiles(String[] aFiles, int aRepKind) {
		if (aFiles != null && aFiles.length > 0) {
			boolean _useThisFile = false;
			String _p = "";

			LocalDateTime _fileCreated = null;
			LocalDateTime _fileUpdated = null;
			// ~~ Get Date from DateTime:
			LocalDate _localDateStart = ep.localDateStart.toLocalDate();
			LocalDate _localDateEnd = ep.localDateEnd.toLocalDate();
			for (String _fileName : aFiles) {
				/// ~~ Confirm the usefulness of the log file base on log type and date ~~
				if (aRepKind == EnumReportKind.AccessLog.getRepKindCode()) {
					_p = EpLogAnalyzer.SysSetngs.getInDirJiraApplicationLogs();
					String _filenameDateStr = _fileName.substring(EpLogAnalyzer.AtlassianJiraAccessLogFileName.length() + 1); // ~~ Extract date from the file name e.g.: 'access_log.2021-10-29'
					LocalDate _filenameDate = utilsLogsSys.getLocalDate(_filenameDateStr);
					// ~~ Parse file only if it is in the given interval
					if (_filenameDate != null) {
						_useThisFile = isFileNameContansDateFromTheRequestedInterval(_filenameDate, _localDateStart, _localDateEnd);
						// System.out.println("~ " + _filenameDate + " in:(" + _localDateStart + "-" + _localDateEnd + ") use:" + _useThisFile);
					}
				} else if (aRepKind == EnumReportKind.CatalinaLog.getRepKindCode()) {
					_p = EpLogAnalyzer.SysSetngs.getInDirJiraApplicationLogs();
					String _filenameDateStr = _fileName.substring(EpLogAnalyzer.AtlassianJiraCatalinaLogFileName.length()); // ~~ Extract date from the file name e.g.: 'C:/Program Files/Atlassian/Jira/logs/catalina.2021-10-29.log'
					_filenameDateStr = _filenameDateStr.substring(0, _filenameDateStr.length() - ".log".length());
					LocalDate _filenameDate = utilsLogsSys.getLocalDate(_filenameDateStr);
					// ~~ Parse file only if it is in the given interval
					if (_filenameDate != null) {
						_useThisFile = isFileNameContansDateFromTheRequestedInterval(_filenameDate, _localDateStart, _localDateEnd);
					}
				} else if (aRepKind == EnumReportKind.JiraLog.getRepKindCode()) {
					_p = EpLogAnalyzer.SysSetngs.getInDirJiraHomeLogs();
					_useThisFile = true;
				}

				// ~~ USE THIS FILE ~~
				if (_useThisFile) {
					try {
						/// ~~ Retrieve the basic file attributes BasicFileAttributes include the file name, size, type, creation date, modification date, permissions, owner, and group.
						BasicFileAttributes attr = Files.readAttributes(Paths.get(_p + "/" + _fileName), BasicFileAttributes.class);
						FileTime fct = attr.creationTime();
						FileTime fut = attr.lastModifiedTime();
						_fileCreated = formatDateTime(fct);
						_fileUpdated = formatDateTime(fut);
					} catch (IOException e1) {
						e1.printStackTrace();
					}
					// ~~ Read log file ~~
					// ~~ isJiraLogsIsCheckFileMetaData -- check if File Attribute update/lastModifiedTime is altered (e.g. after coping). But if modification datetime is original, keep it true, it will help to skip checking outdated files.
					if (!EpLogAnalyzer.SysSetngs.isJiraLogsIsCheckFileMetaData() || _fileUpdated.isAfter(ep.localDateStart) && _fileUpdated.isBefore(ep.localDateEnd)) {

						/// System.out.println("Reading file: '" + _fileName + "', Created: " + _fileCreated + ", Updated: " + _fileUpdated);
						try (BufferedReader _br = new BufferedReader(new FileReader(_p + "/" + _fileName))) {

							/// ~ Loop file lines:
							PojoJiraLogRowData jiraLogRow = null;
							String aFullLine = "";
							while (aFullLine != null) { // ~ Read and parse next log file line:
								aFullLine = _br.readLine();
								/// System.out.println(_line); ///DEBUG
								if (utilsLogsSys.isThisLooksLikeTimeStampedReportLine(aFullLine)) {
									LocalDateTime _logDateTime = parseJiraLogRowDateTimeStamp(aFullLine, aRepKind);
									if (_logDateTime != null) {
										if ((_logDateTime.isAfter(ep.localDateStart) || _logDateTime.isEqual(ep.localDateStart)) && //
												(_logDateTime.isBefore(ep.localDateEnd) || _logDateTime.isEqual(ep.localDateEnd))) {
											boolean isStringToBeUsed = false;
											/// ~~ Business Rules Filter ~~
											if (EpLogAnalyzer.SysSetngs.isJiraLogsIsCollectAllLogData()) {
												isStringToBeUsed = true;
											} else if (EpLogAnalyzer.SysSetngs.isJiraLogsIsCollectIfStringToFindIsFound()) {
												isStringToBeUsed = utilsLogsParsing.isSubStringToFindIsPresentInTheRawDataLine(aFullLine, EpLogAnalyzer.SysSetngs.getCollectIfTheseSubstringsAreFound());
											}
											if (isStringToBeUsed) {
												/// ~~ Parse loc string and populate Pojo, including Object key 'keyUserReportKindSeverity' ~~
												if (aRepKind == EnumReportKind.JiraLog.getRepKindCode()) {
													jiraLogRow = parseAtlassianJiraLogRow(aFullLine);
												} else if (aRepKind == EnumReportKind.AccessLog.getRepKindCode()) {
													jiraLogRow = parseAccessLogRow(aFullLine);
												} else if (aRepKind == EnumReportKind.CatalinaLog.getRepKindCode()) {
													jiraLogRow = parseCatalinaLogRow(aFullLine);
												}
												if (jiraLogRow != null) {
													// ~~ Check if that line has to be considered and added to the final report
													if (EpLogAnalyzer.SysSetngs.isJiraLogsIsCollectErrorsAndWarnings()) { // TODO
													}
													// ~~ Add parent file and other properties
													Long _logLineTimeMsec = parseJiraLogRowDateTimeMsec(_logDateTime);
													jiraLogRow.setSourceLogFileName(_fileName);
													jiraLogRow.setFullOriginalLine(aFullLine);
													jiraLogRow.setLocalDateTime(_logDateTime);
													jiraLogRow.setLocalDateTimeMsec(_logLineTimeMsec);
													jiraLogRow.setEventsCountDataPoint(1L); // ~~ Initial count of events (log entries) with identical timestamps
													jiraLogRow.setEventsCountPerChartTick(0L); // ~~ Will be populated later during data compressing using 'EventsCountDataPoint'

													/// ~~ Assign the case to the report's rank ~~
													/// ~~ Day Set of data ranks, First Key - rounded to a days in msec, Second Key - Actual Event's time
													TreeMap<Long, TreeMap<Long, PojoJiraLogRowData>> overallUserDayActivityAllRanks;
													if (jiraLogRow.getKeyUserReportKindSeverity() != null) {
														Long keyRoundedToDate = _logLineTimeMsec - _logLineTimeMsec % (ep.rankWidthMm * 60 * 1000);
														if (ep.DictGroupByTypeDateCollected.containsKey(jiraLogRow.getKeyUserReportKindSeverity())) {
															/// ~~ Top Key -- UserAccount Rank -- already exists, just add new event/activity to this existing or new Day Rank
															overallUserDayActivityAllRanks = ep.DictGroupByTypeDateCollected.get(jiraLogRow.getKeyUserReportKindSeverity());
															// jiraLogRow.setUserAccountLastEventThisDay(jiraLogRow.getLocalDateTimeMsec()); //~~ This is next event to be used to calculate last event per day for the user Account
															if (overallUserDayActivityAllRanks.containsKey(keyRoundedToDate)) {
																/// ~~ Top Key/ Day Rank already exists for this Rank, just add new event/activity to this existing Day Rank
																TreeMap<Long, PojoJiraLogRowData> _existingRank = overallUserDayActivityAllRanks.get(keyRoundedToDate);
																if (_existingRank.containsKey(_logLineTimeMsec)) {
																	// ~~ Note: if we have more than one log entries with the same time, just count them. May loose description of one (or more) of the log entry
																	_existingRank.get(_logLineTimeMsec).setEventsCountDataPoint(_existingRank.get(_logLineTimeMsec).getEventsCountDataPoint() + 1);
																} else {
																	/// ~~~ New event (log entry) with such unique time stamp
																	_existingRank.put(_logLineTimeMsec, jiraLogRow); // ~~ Add new dataPoint
																}
																// while (_existingRank.containsKey(_logLineTimeMsec)) {
																// _logLineTimeMsec++; //if time stamp dublicated, modify a time by 1+ mSec (create new key), so we can keep all events in the dictionary -- Bad (not clean) way to keep track of dublicated jira log time stamps
																// }
															} else {
																/// ~~ Add new Day Rank ~~
																TreeMap<Long, PojoJiraLogRowData> _newRank = new TreeMap<Long, PojoJiraLogRowData>();
																_newRank.put(_logLineTimeMsec, jiraLogRow);
																overallUserDayActivityAllRanks.put(keyRoundedToDate, _newRank);
															}
														} else {
															// ~~ UserKey does not exists in this Rank, create new
															overallUserDayActivityAllRanks = new TreeMap<Long, TreeMap<Long, PojoJiraLogRowData>>();
															// jiraLogRow.setUserAccountFirstEventThisDay(jiraLogRow.getLocalDateTimeMsec()); //~~ This is the chronologically first event for this account at this day
															TreeMap<Long, PojoJiraLogRowData> _newRank = new TreeMap<Long, PojoJiraLogRowData>();
															_newRank.put(_logLineTimeMsec, jiraLogRow);
															overallUserDayActivityAllRanks.put(keyRoundedToDate, _newRank);
															ep.DictGroupByTypeDateCollected.put(jiraLogRow.getKeyUserReportKindSeverity(), overallUserDayActivityAllRanks);
														}
													}
													// System.out.println("~~New row added " + _pojoJiraLogRowObj.getLocalDateTimeMsec() + " " + _pojoJiraLogRowObj.getLocalDateTime());
												} // ~~ fi (_pojoJiraLogRowObj != null
											} // ~~ fi isStringToBeUsed
										} // ~~ check if line update time in the given period
									} // ~~ fi _useThisLine / Line is Usefull ~~
								}
							} // ~~ Loop file lines:
						} catch (FileNotFoundException e) {
							e.printStackTrace();
						} catch (IOException e) {
							e.printStackTrace();
						}

						// ~~ Finished Reading the log file ~~
						killRanksBelowThresholdCounter(ep.DictGroupByTypeDateCollected);
						// System.out.println("Finished Reading the log file: '" + _fileName);

					} // ~~ check if file update time in the given period
				} // ~~ fi ~~ USE THIS FILE ~~
			} // ~~ loop files
				// System.out.println("Done ParseJiraAndAccessLogs.");
		}
	}

	final LocalDateTime parseJiraLogRowDateTimeStamp(String aRawReportLine, int aRepKind) {
		LocalDateTime reportLineTimeStamp = null;
		String logDateTimeStrng = "";
		if (aRepKind == EnumReportKind.JiraLog.getRepKindCode()) {
			/// ~ 2021-10-27 18:55:58,976
			logDateTimeStrng = aRawReportLine.substring(0, 23);
			if (logDateTimeStrng.substring(19, 20).compareTo(",") == 0) { // Make sure it's a date
				reportLineTimeStamp = utilsLogsSys.extractToLocalDateTime(logDateTimeStrng);
			}
		} else if (aRepKind == EnumReportKind.CatalinaLog.getRepKindCode()) {
			/// ~ 29-Sep-2021 09:49:32.694 INFO [main] org.apache.catalina.startup.VersionLoggerListener.log Server version name: Apache Tomcat/8.5.65
			/// ~ 29-Sep-2021 09:49:32.694
			logDateTimeStrng = aRawReportLine.substring(0, 24);
			if (logDateTimeStrng.substring(2, 3).compareTo("-") == 0) { // Make sure it's a date
				reportLineTimeStamp = utilsLogsSys.getDateCatalinaLog(logDateTimeStrng);
			}
		} else if (aRepKind == EnumReportKind.AccessLog.getRepKindCode()) {
			int limitLineLengthTo = utilsLogsParsing.nthOccurrence(aRawReportLine, " ", 4); // TODO attention: check last arrSplit02 needed
			String[] arrSplit02 = aRawReportLine.substring(0, limitLineLengthTo).split(" "); // ~~ to avoid overSized String[] array
			String dateStr = arrSplit02[3].substring(1); // '[07/Oct/2022:23:03:06'
			reportLineTimeStamp = utilsLogsSys.getLocalDateTimeShort(dateStr); // '07/Oct/2022:23:03:06'
		}
		return reportLineTimeStamp;
	}

	final Long parseJiraLogRowDateTimeMsec(LocalDateTime aReportLineTimeStamp) {
		Long _logLineTimeMsec = null;
		if (aReportLineTimeStamp != null) {
			ZonedDateTime _zdt = aReportLineTimeStamp.atZone(ZoneId.of("UTC"));
			/// _zdt = aReportLineTimeStamp.atZone(ZoneId.of("America/New_York"));
			/// _zdt = aReportLineTimeStamp.atZone(ZoneId.systemDefault());
			_logLineTimeMsec = _zdt.toInstant().toEpochMilli();
		}
		return _logLineTimeMsec;
	}

	final PojoJiraLogRowData parseAtlassianJiraLogRow(String aFullLine) {
		/// ~ File: 'atlassian-jira.log'
		PojoJiraLogRowData jiraLogRow = null;
		if (utilsLogsSys.isThisLooksLikeTimeStampedReportLine(aFullLine)) {
			jiraLogRow = new PojoJiraLogRowData();
			try {
				LocalDateTime _logDateTime = parseJiraLogRowDateTimeStamp(aFullLine, EpLogAnalyzer.EnumReportKind.JiraLog.getRepKindCode());
				if (_logDateTime != null) {
					Long _logLineTimeMsec = parseJiraLogRowDateTimeMsec(_logDateTime);
					String[] splittedFullLine = utilsLogsParsing.splitFullLineBySeverityLevel(aFullLine);
					if (splittedFullLine == null) {
						// #--No Severity -- already reported/logged
					} else {
						jiraLogRow.setLogKind(EnumReportKind.JiraLog.getRepKindCode());
						jiraLogRow.setLocalDateTime(_logDateTime);
						jiraLogRow.setLocalDateTimeMsec(_logLineTimeMsec);
						int idxOfActingService = utilsLogsParsing.nthOccurrence(splittedFullLine[0], " ", 2);
						if (idxOfActingService > 0) {
							jiraLogRow.setActingServiceFull(splittedFullLine[0].substring(idxOfActingService));
							jiraLogRow.setActingServiceCore(utilsLogsParsing.extractTheActingServiceCore(jiraLogRow.getActingServiceFull())); // TODO fix it
						}
						jiraLogRow.setSeverityLevel(splittedFullLine[1]);
						jiraLogRow.setSeverityGraphChar(jiraLogRow.getSeverityLevel().substring(0, 1).toLowerCase());
						String[] subStringTail = splittedFullLine[2].split(" ");
						jiraLogRow.setUserNameFull(subStringTail[0]);
						jiraLogRow.setUserNameCore(utilsLogsParsing.extractUserNameCore(jiraLogRow.getUserNameFull()));
						jiraLogRow.setRequestID(subStringTail[1]);
						jiraLogRow.setSessionID(subStringTail[2]);
						jiraLogRow.setFromIpAddress(subStringTail[3]);
						jiraLogRow.setHttpRequestApiCallFull(subStringTail[4]);
						jiraLogRow.setHttpRequestApiCallCore(subStringTail[4]);
						jiraLogRow.setSearchProvider(subStringTail[5]);
						// if (aFullLine.contains("2026-05-15 14:06:09,000-0500 AnyStuff")) { int DEBUG = -1;} /// DEBUG
						String theSummary = "";
						try {
							theSummary = splittedFullLine[2].substring(splittedFullLine[2].indexOf(subStringTail[5]) + subStringTail[5].length() + 1);
						} catch (Exception e) {
							System.err.println("~ERROR1234583 in: " + aFullLine); /// DEBUG
						}
						jiraLogRow.setSummary(theSummary);
					}
				}
			} catch (Exception e) {
				System.err.println("~ERROR1234599 in: " + aFullLine); /// DEBUG
			}
			jiraLogRow.setKeyUserReportKindSeverity(utilsLogsParsing.buildTheKeyForTheRankGrouping(jiraLogRow.getUserNameCore(), "", 0L, EpLogAnalyzer.EnumReportKind.JiraLog, jiraLogRow));
			jiraLogRow.setJqlLuceneQueryOrHtmlParam(EpLogAnalyzer.EnumReportKind.JiraLog.toString() + "." + jiraLogRow.getSeverityLevel() + ": " + jiraLogRow.getSummary()); // ~ SeismoLog Right Column
		}
		return jiraLogRow;
	}

	private final PojoJiraLogRowData parseAccessLogRow(String aFullLine) {
		// File: access_log.YYYY-mm-dd
		// Log Purpose: HTTP access log (tomcat).
		// Description: A list of each request that Jira node receives and completes processing.
		// HEADER:
		// Origin IP Request ID Username Timestamp Method & Endpoint HTTP status code Bytes sent Time Taken to process the request in millis Accessed URL Client utilized Session ID
		// ~~ successful login, for the sysadmin user, through a browser client, that came from the IP address 10.61.175.127.:
		// 10.61.175.127 654x34x1 sysadmin [04/Feb/2022:10:54:12 -0300] "POST /rest/gadget/1.0/login HTTP/1.1" 200 223 607 https://jiratest/secure/Dashboard.jspa "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.99 Safari/537.36" 51cumq
		// ~~ For comparison, here's an example of how a failed API request to create a new user session,
		// 10.61.175.128 1169x56417x1 - [11/Jul/2021:19:29:49 -0700] "POST /rest/auth/1/session HTTP/1.1" 403 20816 46 "-" "Apache-HttpClient/4.5.5 (Java/1.8.0_202)" "1dl1546"
		// ~~ ... and a successful request to add comments in Jira look like respectively
		// 10.61.175.129 187x549578x1 restuser [27/Aug/2021:03:07:11 -0400] "POST /rest/api/2/issue/JRA-1750/comment HTTP/1.1" 201 737 169 "-" "python-requests/2.26.0" "1nnznnq"
		// ~~ more examples follow the link above

		// ~~ IP_ADDRESS 936x52140x1 USER [05/Sep/2019:18:03:34 -0400] "POST /rest/api/2/issue HTTP/1.1" 401 - 0 "-" "Apache CXF 2.7.18" "-"
		// ~~ 127.0.0.1z 464x2x2 - [12/Aug/2021:07:44:35 -0400] "GET /rest/auditing/latest/statistics/database/usage- HTTP/1.1" 200 55 3588 "-" "Apache-HttpClient/4.5.13 (Java/1.8.0_201)" "-"
		// ~~ 0:0:0:0:0:0:0:1 1365x24x1 localadmin [11/Aug/2021:22:45:33 -0400] "POST /secure/admin/WebSudoAuthenticate.jspa- HTTP/1.1" 302 - 399 "http://localhost:8080/secure/admin/WebSudoAuthenticate!default.jspa?webSudoDestination=%2Fplugins%2Fservlet%2Fupm%3Fsource%3Dside_nav_manage_addons" "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36" "18b20j5"
		// ~~ 35.191.2.232 1165x67177x1 valeritikhonov@geotab.com [11/Oct/2022:10:10:14 +0000] "GET /rest/scriptrunner/latest/custom/customadmin? HTTP/1.1" 200 557 47 "https://jiraupgrade.geotab.com/plugins/servlet/scriptrunner/admin/restendpoints" "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36" "1ok443k"
		// ~~ 127.0.0.1 480x958640x1 localadmin [16/Nov/2022:08:00:10 -0500] "GET /rest/api/latest/field HTTP/1.1" 200 367047 20 "-" "Java/1.8.0_342" "1kiwlf"
		// ~~ 127.0.0.1 - - [16/Nov/2022:08:00:10 -0500] "GET /rest/api/latest/project/PROD HTTP/1.1" 505 - 0 "-" "Java/1.8.0_342" "-"
		// ~~ 0:0:0:0:0:0:0:1 - - [21/Jan/2023:13:16:39 -0500] "null null- null" 400 - 0 "-" "-" "-"
		// if (aFullLine.contains("[21/Jan/2023:13:16:39 -0500]")) {
		// int debugStopPoint = 0;
		// }
		String mustHaveRequiredRestApiRequestMethod = "";
		// "accessLog.restApiKeyword" : "/rest/scriptrunner/latest/",
		if (EpLogAnalyzer.SysSetngs.isAccessLogExtractRestApiCallsOnly() && EpLogAnalyzer.SysSetngs.getAccessLogRequiredRestApiRequestMethod() != null && EpLogAnalyzer.SysSetngs.getAccessLogRequiredRestApiRequestMethod().length() > 0) {
			mustHaveRequiredRestApiRequestMethod = EpLogAnalyzer.SysSetngs.getAccessLogRequiredRestApiRequestMethod();
		}

		PojoJiraLogRowData jiraLogRow = new PojoJiraLogRowData();
		jiraLogRow.setFullOriginalLine(aFullLine);
		jiraLogRow.setLogKind(EnumReportKind.AccessLog.getRepKindCode());
		jiraLogRow.setActingServiceFull(""); // ~~ Acting Service is not presenrt in 'access_log'
		jiraLogRow.setActingServiceCore("");
		int limitLineLengthTo = utilsLogsParsing.nthOccurrence(aFullLine, " ", 11); // TODO attention: check last arrSplit01 needed
		if (limitLineLengthTo == -1) {
			/// ~~ Happened when last line in the access log file is not full (zipped from live Jira)
			return null;
		}
		String[] arrSplit01 = aFullLine.substring(0, limitLineLengthTo).split(" ");
		jiraLogRow.setSeverityGraphChar("h"); // ~~ Human
		jiraLogRow.setFromIpAddress(arrSplit01[0]); // ~~ {35.191.2.232}
		jiraLogRow.setRequestID(arrSplit01[1]); // ~~ {1165x67177x1}
		// ~~ UserName
		jiraLogRow.setUserNameFull(arrSplit01[2]); // ~~ {valeritikhonov@geotab.com}
		jiraLogRow.setUserNameCore(utilsLogsParsing.extractUserNameFromEmail((utilsLogsParsing.extractUserNameCore(jiraLogRow.getUserNameFull()))));
		if (EpLogAnalyzer.SysSetngs.isExcludeNonHumanAccounts() && jiraLogRow.getUserNameFull().compareTo("-") == 0) {
			// ~~ remove all NHA (Non-Human Account) events
			return null;
		}
		// ~~ Log Entry Date time ~~
		LocalDateTime _logDateTime = null;
		String _logDateTimeStr = arrSplit01[3] + " " + arrSplit01[4]; // ~~ {[11/Oct/2022:10:10:14}; {+0000]}
		_logDateTimeStr = _logDateTimeStr.substring(1, _logDateTimeStr.length() - 1);
		_logDateTimeStr = arrSplit01[3].substring(1); // {11/Oct/2022:10:10:14}
		_logDateTime = utilsLogsSys.getLocalDateTimeShort(_logDateTimeStr);
		jiraLogRow.setLocalDateTime(_logDateTime);
		Long _logLineTimeMsec = parseJiraLogRowDateTimeMsec(_logDateTime);
		jiraLogRow.setLocalDateTimeMsec(_logLineTimeMsec);

		// ~~ Note: from split by space element [5] e.g. ' "GET ' we need to form new substring and split by double quotes
		int slidingStringIndexStart = aFullLine.indexOf(arrSplit01[5]);
		int slidingStringIndexInFullLine = aFullLine.indexOf(arrSplit01[5]);
		String sub = aFullLine.substring(slidingStringIndexStart + 1);
		int slidingStringIndexEnd = sub.indexOf("\" "); // ~~ Closing double quote '"'
		slidingStringIndexInFullLine = aFullLine.indexOf("\" "); // ~~ Closing double quote '"'
		sub = sub.substring(0, slidingStringIndexEnd); // ~~ http request substring "GET /rest/api/latest/field HTTP/1.1", or "null null- null"
		slidingStringIndexEnd = sub.indexOf("HTTP/"); // will be -1 for: "null null- null"
		if (slidingStringIndexEnd > -1) {
			try {
				jiraLogRow.setHttpMethodAndEndPoint(sub.substring(slidingStringIndexEnd)); // ~ e.g.: 'HTTP/1.1' -- 'Method & EndPoint' -- 'Method & EndPoint' tail -- Hypertext Transfer Protocol
				sub = sub.substring(0, slidingStringIndexEnd - 1);
			} catch (Exception e1) {
				System.err.println("ERR in: '" + sub + "'\n" + aFullLine + "\n" + e1.getMessage());
				e1.printStackTrace();
			}
		}
		String httpRequestApiCallFull = sub;
		String httpRequestApiCallCore = sub;
		if (httpRequestApiCallFull.length() > 0) {
			String jqlQryOrHttpRequestParams = "";
			if (httpRequestApiCallFull.contains("?")) {
				httpRequestApiCallCore = httpRequestApiCallFull.substring(0, httpRequestApiCallFull.indexOf("?") - 1); // ~~ {/rest/scriptrunner/latest/custom/customadmin?}
				jqlQryOrHttpRequestParams = httpRequestApiCallFull.substring(httpRequestApiCallFull.indexOf("?"));
			}
			jiraLogRow.setHttpRequestApiCallFull(httpRequestApiCallFull);
			jiraLogRow.setHttpRequestApiCallCore(httpRequestApiCallCore); // Will be re-set (shortened) in extractHttpRequestApiCallCore()
			jiraLogRow.setJqlLuceneQueryOrHtmlParam(EpLogAnalyzer.EnumReportKind.AccessLog.toString() + "." + jqlQryOrHttpRequestParams);
			// jiraLogRow.setHttpRequestApiCallFull(arrSplit[6]);
		}
		if (EpLogAnalyzer.SysSetngs.isAccessLogExtractRestApiCallsOnly()) {
			if (!jiraLogRow.getHttpRequestApiCallFull().contains(mustHaveRequiredRestApiRequestMethod)) {
				return null;
			}
		}
		utilsLogsParsing.extractHttpRequestApiCallCore(jiraLogRow);
		jiraLogRow.setRequestMethod(arrSplit01[5]); // ~~ e.g.: {"GET}
		// ~~ Extract httpResponseStatusCode 'HTTP status code'
		jiraLogRow.setHttpResponseStatusCode(-1);
		jiraLogRow.setSeverityLevel("");

		// ~~ Move substring in focus to behind of the HTTP request.
		sub = aFullLine.substring(slidingStringIndexInFullLine + 2);
		String[] arrSplit02 = sub.split(" ");
		try {
			jiraLogRow.setHttpResponseStatusCode(Integer.parseInt(arrSplit02[0])); // ~~ {200} -- 'HTTP status code'
			// ~~ The Log does not have any Severity, so use HTTP Response Code (e.g. 200, 300, 400, 401, etc)
			if (jiraLogRow.getHttpResponseStatusCode() >= ConstantsOfJiraLogs.HTTPStatusCodeGE400Fault) {
				jiraLogRow.setSeverityLevel(EnumSeverity.ERROR.toString());
			} else if (jiraLogRow.getHttpResponseStatusCode() >= ConstantsOfJiraLogs.HTTPStatusCodeGE300Rout) {
				jiraLogRow.setSeverityLevel(EnumSeverity.WARN.toString());
			} else {
				// ~~ Do not modify existing level, if it's already set
			}
		} catch (NumberFormatException e) {
		}
		// ~~ Extract 'Bytes sent' ~~
		try {
			Long _byteSent = 0L;
			if (arrSplit02[1].compareTo("-") != 0) {
				_byteSent = Long.parseLong(arrSplit02[1]); // ~~ {557} -- 'Bytes sent'
				// _byteSent = _byteSent / 1024; //~~ MAY BE USE kBytes to aboid overflow
			}
			jiraLogRow.setBytesSentDataPoint(_byteSent);
		} catch (NumberFormatException e) {
		}
		// ~~ Extract 'Time Taken to process the request in milliSec' ~~
		try {
			Long _executionTime = Long.parseLong(arrSplit02[2]); // ~~ {47} -- 'Time Taken to process the request in milliS'
			jiraLogRow.setExecutionTimeDataPointMSec(_executionTime);
		} catch (NumberFormatException e) {
		}

		// jiraLogRow.setKeyUserReportKindSeverity(Utils.buildTheKeyForTheRankGrouping(jiraLogRow.getUserNameCore(), EntryPoint.EnumReportKind.AccessLog, jiraLogRow.getSeverityLevel())); // ~~ made up severity level 'ACCESS'
		// ~~ atypical KeyUserReportKindSeverity: Use 'IP' + ['HTTP Response Code' as 'User Name'] + 'User name'; and Request type (e.g. GET) as SeverityLevel
		if (true || EpLogAnalyzer.SysSetngs.isAccessLogExtractRestApiCallsOnly()) {
			double exectn = jiraLogRow.getExecutionTimeDataPointMSec() / 1000.0;
			exectn = (double) Math.round(exectn);
			if (exectn < EpLogAnalyzer.SysSetngs.getRankThresholdExecutionTimesSec()) {
				// ~~ Note: This MUST be here to reduce RAM use and refuse those lines, but the number of such short call per Rank will be missed
				// ~~ Note 2: Or better to save it to the rank, and the whole rank in the dictionary after confirmation that events counter threshold is not reached, so do not return null
				// System.err.println("~~~" + exectn + " ? " + EpLogAnalyzer.SysSetngs.getRankThresholdExecutionTimesSec());
				// return null; // ~~ Do not return null, See Note 2 above
			} else {
				// System.out.println("~~~" + exectn + " ? " + EpLogAnalyzer.SysSetngs.getRankThresholdExecutionTimesSec());
			}
			// ~~ Lines below will not work, can't say if jiraLogRow.getCounter() < EpLogAnalyzer.SysSetngs.getRankThresholdEvents() using this Single line
			// if (jiraLogRow.getCounter() < EpLogAnalyzer.SysSetngs.getRankThresholdEvents()) {
			// System.err.println("~~~" + jiraLogRow.getCounter() + " < " + EpLogAnalyzer.SysSetngs.getRankThresholdEvents());
			// return null;
			// } else {
			// System.err.println("~~~" + jiraLogRow.getCounter() + " > " + EpLogAnalyzer.SysSetngs.getRankThresholdEvents());
			// }
			// jiraLogRow.setKeyUserReportKindSeverity(Utils.buildTheKeyForTheRankGrouping(jiraLogRow.getUserNameCore() + " " + jiraLogRow.getHttpRequestApiCallFull().replace(mustHaveRequiredRestApiRequestMethod, "") + " " + String.format("%06.0f", exectn) + "s", null, null));
			String methodAndEndPointCore = null;
			if (jiraLogRow.getHttpRequestApiCallCore() != null && jiraLogRow.getHttpRequestApiCallCore().length() > 0) {
				methodAndEndPointCore = jiraLogRow.getHttpRequestApiCallCore().replace(mustHaveRequiredRestApiRequestMethod, "");
			}
			jiraLogRow.setKeyUserReportKindSeverity(utilsLogsParsing.buildTheKeyForTheRankGrouping(jiraLogRow.getUserNameCore(), methodAndEndPointCore, jiraLogRow.getExecutionTimeDataPointMSec(), EpLogAnalyzer.EnumReportKind.AccessLog, jiraLogRow));
		} else {
			// ~~ all log entries, so pack different events in one rank
			jiraLogRow.setKeyUserReportKindSeverity(utilsLogsParsing.buildTheKeyForTheRankGrouping(jiraLogRow.getUserNameCore(), jiraLogRow.getHttpResponseStatusCode() + "", 0L, EpLogAnalyzer.EnumReportKind.AccessLog, jiraLogRow));
		}
		if (jiraLogRow.getUserNameFull().length() == 1) { // '-'
			jiraLogRow.setSeverityGraphChar(jiraLogRow.getUserNameCore().substring(0, 1)); // ~~ NHA/Bot/Script
		} else {
			jiraLogRow.setSeverityGraphChar(jiraLogRow.getUserNameCore().substring(0, 1).toUpperCase()); // ~~ User,
		}
		return jiraLogRow;
	}

	private final PojoJiraLogRowData parseCatalinaLogRow(String aFullLine) {
		// ~~ File: 'catalina.2021-10-29.log'
		int limitLineLengthTo = utilsLogsParsing.nthOccurrence(aFullLine, " ", 4); // TODO attention: check last arrSplit04 needed
		String[] arrSplit04 = aFullLine.substring(0, limitLineLengthTo).split(" ");

		PojoJiraLogRowData jiraLogRow = new PojoJiraLogRowData();
		jiraLogRow.setLogKind(EnumReportKind.CatalinaLog.getRepKindCode());
		String _actingService = arrSplit04[3]; // ~~ e.g.: [localhost-startStop-2]
		if (_actingService != null && _actingService.length() > 2) {
			_actingService = _actingService.substring(1, _actingService.length() - 1); // ~~ remove '[' ']'
		}
		jiraLogRow.setActingServiceFull(_actingService);
		jiraLogRow.setActingServiceCore(utilsLogsParsing.extractTheActingServiceCore(jiraLogRow.getActingServiceFull()));

		String[] splittedFullLine = utilsLogsParsing.splitFullLineBySeverityLevel(aFullLine);
		jiraLogRow.setSeverityLevel(splittedFullLine[1]);
		jiraLogRow.setSeverityGraphChar(jiraLogRow.getSeverityLevel().substring(0, 1).toLowerCase());

		jiraLogRow.setUserNameFull(EpLogAnalyzer.EnumReportKind.CatalinaLog.toString()); // ~~ Name is not present in Catalina Log, so make one up
		jiraLogRow.setUserNameCore(utilsLogsParsing.extractUserNameCore(jiraLogRow.getUserNameFull()));
		jiraLogRow.setKeyUserReportKindSeverity(utilsLogsParsing.buildTheKeyForTheRankGrouping(jiraLogRow.getUserNameCore(), "", 0L, EpLogAnalyzer.EnumReportKind.CatalinaLog, jiraLogRow));
		return jiraLogRow;
	}

	private final LocalDateTime formatDateTime(FileTime fileTime) {
		// DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("MM/dd/yyyy
		// HH:mm:ss");
		// LocalDateTime localDateTime = fileTime.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
		LocalDateTime localDateTime = fileTime.toInstant().atZone(ZoneId.of("UTC")).toLocalDateTime();
		// return localDateTime.format(DATE_FORMATTER);
		return localDateTime;
	}

	private final boolean isFileNameContansDateFromTheRequestedInterval(LocalDate aFilenameDate, LocalDate aDateStart, LocalDate aDateEnd) {
		// ~~ e.g.: 'access_log.2022-11-10'
		if (aFilenameDate.isEqual(aDateStart) || aFilenameDate.isEqual(aDateEnd) //
				|| aFilenameDate.isAfter(aDateStart) && aFilenameDate.isBefore(aDateEnd)) {
			return true;
		} else {
			return false;
		}
	}

	private final void killRanksBelowThresholdCounter(TreeMap<String, TreeMap<Long, TreeMap<Long, PojoJiraLogRowData>>> aDictGroupByTypeDate) {
		// ~~ Loop and clean all Ranks (kill all ranks in the dictionary after confirmation that events counter threshold is not reached to release RAM
		String rootKey;
		Long dayKey1;
		Iterator<Entry<String, TreeMap<Long, TreeMap<Long, PojoJiraLogRowData>>>> rootRankIterator = aDictGroupByTypeDate.entrySet().iterator();
		while (rootRankIterator.hasNext()) {
			Entry<String, TreeMap<Long, TreeMap<Long, PojoJiraLogRowData>>> rootRank = rootRankIterator.next();
			rootKey = rootRank.getKey();
			Iterator<Entry<Long, TreeMap<Long, PojoJiraLogRowData>>> dayRankIterator = rootRank.getValue().entrySet().iterator();
			while (dayRankIterator.hasNext()) {
				Entry<Long, TreeMap<Long, PojoJiraLogRowData>> dayRank = dayRankIterator.next();
				dayKey1 = dayRank.getKey();
				TreeMap<Long, PojoJiraLogRowData> _rankData = dayRank.getValue();
				if (_rankData != null && _rankData.size() > 0) {
					PojoJiraLogRowData fe = _rankData.firstEntry().getValue();
					if ((_rankData.size() < EpLogAnalyzer.SysSetngs.getRankThresholdEvents() && fe == null) //
							|| fe != null //
									&& fe.getBytesSentPerDayPerRank() != null && fe.getBytesSentPerDayPerRank() < EpLogAnalyzer.SysSetngs.getRankThresholdEvents()//
									&& fe.getExecutionTimePerDayPerRankMSec() != null && fe.getExecutionTimePerDayPerRankMSec() / 1000.0 < EpLogAnalyzer.SysSetngs.getRankThresholdExecutionTimesSec() //
					) {
						// System.out.println(" DataPoints < " + EpLogAnalyzer.SysSetngs.getRankThresholdEvents());
						aDictGroupByTypeDate.get(rootKey).get(dayKey1).clear();
					} else {
						// System.out.println(" DataPoints > " + EpLogAnalyzer.SysSetngs.getRankThresholdEvents());
					}
					// ~~ Iterate all dataPoints in the Rank
					if (false) {
						Iterator<Entry<Long, PojoJiraLogRowData>> _itemsKeyValue = _rankData.entrySet().iterator();
						while (_itemsKeyValue.hasNext()) {
							Entry<Long, PojoJiraLogRowData> _itemKeyValue = _itemsKeyValue.next();
							PojoJiraLogRowData _itemValue = _itemKeyValue.getValue();
						}
					}
				}
			}
		}
	}

}
