package seismo;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.TreeMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import jira_log_analyzer.EpLogAnalyzer;
import jira_log_analyzer.UtilsLogsSys;
import pojo.PojoJiraLogRowData;
import pojo.PojoJsonSystemSettingsFile;

public class UtilsCompressLogDataAndSaveToDbOrCsv {

	private UtilsDBaseSeismoGraphLegendAndData utilsDBaseSeismoGraphLegendAndData = new UtilsDBaseSeismoGraphLegendAndData();
	private Long xFuseSlabGridTickMilliSec; // = 1000 * seismoXFuseJiraLogDataPointsToChartSlabSeconds;
	private PojoJsonSystemSettingsFile aSSetLocal;
	private Properties props;
	/// private final Long seismoXFuseJiraLogDataPointsToChartSlabSeconds = 60L; //~~ Collect and fuse all jira log entries in that time span to decrease number of records in seismo dbase
	/// private final int shiftAboveJMXPlusElementMaxIndex = 0; //512; //~~ Not needed anymore. The shift to avoid generating indexes below that value, for non-conflicting share the same number line with JMX indexes. Must be > JMXPlusElement.size().
	/// private String url;
	private Double msToMinutes = 1000d * 60d;
	private Double bytesToMB = 1024d * 1024d;
	private final String[] headerLabels = { "user/account", "requests count", "time taken to process the request in min", "MB sent" };

	public UtilsCompressLogDataAndSaveToDbOrCsv(PojoJsonSystemSettingsFile aSSet) {
		aSSetLocal = aSSet;
		xFuseSlabGridTickMilliSec = 1000L * aSSet.getSeismoXFuseJiraLogDataPointsToChartSlabSeconds();
		/// url = aSSet.getDbDriver() + aSSet.getDbHost() + ":" + aSSet.getDbPortNumber() + "/" + aSSet.getDbName();
		props = new Properties();
		props.setProperty("user", aSSet.getDbUsername()); // "postgres"
		props.setProperty("password", aSSet.getDbPassword()); // "amp"
		props.setProperty("ssl", aSSet.isDbEnableSsl() ? "true" : "false"); // "false"
		if (EpLogAnalyzer.DEBUG_isTestServer) { /// DEBUG;
			msToMinutes = 1d; /// DEBUG
			bytesToMB = 1d; /// DEBUG
		} /// DEBUG;
	}

	public final void compactAndPersistJiraLogsDataToDBaseOrCsv(TreeMap<Long, TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>> aDictGroupByDateType) {
		/// ~~ Compress data and save it to the Database, or to the csv file, if Dbase is not available
		/// ~~ A Chart Slab (chanks of time, chart grid tick) refers to a designated time interval, such as one minute, used to condense and summarize multiple frequent data points into a single data point to reduce noise
		/// ~~ This approach helps prevent the overcrowding of the chart with numerous data points.

		/// ~~ Note: First Long Key here is the rounded (e.g. to an hour) tick on time scale to host a chunk of compressed log data to sync data for different users to the same time grid, so it's easy to export to excel, synced by the grid time. e.g 60 sec
		/// ~~ Second String key - User accont, clean Full name 'getUserNameCore()' with NO @domain.com after the name
		TreeMap<Long, TreeMap<String, PojoJiraLogRowData>> compressedDataSetForChartOfJiraLogPoints = new TreeMap<Long, TreeMap<String, PojoJiraLogRowData>>();

		/// ~~ Step 1. Find existing latest record in 'ao_be0df6_seismoactivitychartdata'
		/// ~~ Will find in DBase latest already saved record, than compress (fuse) data to remove noise and calculate the value for the chart time line tick
		Long latestSavedLocalDateInMillis = null;
		Long latestSavedLocalDateTimeInMillis = null;
		if (aSSetLocal.isSeismoUseJiraDbToPersistData()) {
			LocalDateTime latestSavedLocalDateTime = utilsDBaseSeismoGraphLegendAndData.selectFromDBTseismoactivitychartdataTheSingleLastRecord();
			// ~~ Check if
			if (latestSavedLocalDateTime != null) {
				// Instant instant = latestLocalDateTime.atZone(ZoneId.systemDefault()).toInstant();
				Instant instant = latestSavedLocalDateTime.atZone(ZoneId.of("UTC")).toInstant();
				latestSavedLocalDateTimeInMillis = instant.toEpochMilli(); // ~~ ET time of last record in dbase so far ~~
				latestSavedLocalDateInMillis = latestSavedLocalDateTimeInMillis - latestSavedLocalDateTimeInMillis % (24 * 3600 * 1000);
			}
		}

		if (false) {
			/// ~~ Find first and last days in the scanned jira log file
			/// ~~ For future use?
			AtomicLong firstDay = new AtomicLong(Long.MAX_VALUE);
			AtomicLong lastDay = new AtomicLong(Long.MIN_VALUE);
			aDictGroupByDateType.forEach((Long keyDay, TreeMap<String, TreeMap<Long, PojoJiraLogRowData>> userAccounts) -> {
				if (firstDay.get() > keyDay) {
					firstDay.set(keyDay);
				}
				if (lastDay.get() < keyDay) {
					lastDay.set(keyDay);
				}
			});
			System.out.println("~~~First and Last days found in the jira log:" + firstDay.get() + ".." + lastDay.get());
		}

		/// ~~ Step 2. Get full Dictionary of the all Jira parsed Logs AND Compress it for chart ~~
		/// ~~ Loop 1 --.Days ~~
		Iterator<Entry<Long, TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>>> daysSets = aDictGroupByDateType.entrySet().iterator();
		while (daysSets.hasNext()) {
			Entry<Long, TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>> dayRanks = daysSets.next();
			/// LocalDateTime debugDate = LocalDateTime.ofInstant(Instant.ofEpochMilli(dayRanks.getKey()), ZoneId.of("UTC")); ///~~DEBUG~~
			/// DateTimeFormatter debugDateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"); ///~~DEBUG~~
			/// System.out.println("~L1.DayRanks.getKey: " + debugDate.format(debugDateTimeFormatter)); ///~~DEBUG~~

			/// ~~ populate 24 hrs time grid for this day ~~
			for (int ii = 0; ii < (24 * 60 * 60 * 1000 / xFuseSlabGridTickMilliSec); ii++) {
				/// ~~ Generate Time Ticks for 24 hours and Add current date 'dayRanks.getKey()'
				compressedDataSetForChartOfJiraLogPoints.put(xFuseSlabGridTickMilliSec * ii + dayRanks.getKey(), null); // ~~With Date and time
			}

			if (latestSavedLocalDateInMillis == null || dayRanks.getKey() >= latestSavedLocalDateInMillis) {
				/// ~~ Loop 2 -- User's Accounts / Errors / Filtered ranks with time greater than time of the existing in seismo DB latest record ~~
				/// ~~ loop may have hundreds records for each unique second key like: [!http:302 '-' ep:'/secure/SetupDatabase!default.jspa-' src:'AccessLog']
				Iterator<Entry<String, TreeMap<Long, PojoJiraLogRowData>>> accountsIter = dayRanks.getValue().entrySet().iterator();
				while (accountsIter.hasNext()) {
					Entry<String, TreeMap<Long, PojoJiraLogRowData>> userAccountRank = accountsIter.next();
					PojoJiraLogRowData uacci = userAccountRank.getValue().firstEntry().getValue();
					PojoJiraLogRowData uaccf = userAccountRank.getValue().values().iterator().next(); /// DEBUG
					String userKey = userAccountRank.getKey(); /// e.g.: {key: !http:302 '-' ep:'/' src:'AccessLog'} ///DEBUG
					String userNameCoreFirstEntry = uacci.getUserNameCore();
					String userNameCoreByIterator = uaccf.getUserNameCore(); /// DEBUG
					// System.out.println("~Next UserNameFull(): " + userNameFull); ///DEBUG
					if (userNameCoreByIterator == null || userNameCoreFirstEntry == null) {
						System.err.println("~WARNING userNameCoreByIterator=" + userNameCoreByIterator + ", userNameCoreFirstEntry=" + userNameCoreFirstEntry); /// DEBUG
						break;
					} else {
						if (userNameCoreByIterator.compareTo(userNameCoreFirstEntry) != 0) { /// DEBUG
							System.err.println("~WARNING Check why methods delivered different names: " + userNameCoreFirstEntry + " != " + userNameCoreByIterator); /// DEBUG
						} /// DEBUG
							// System.out.println("~L2: " + userAccountRank.getKey()); ///~~DEBUG~~

						/// ~~ Business Rules Filter ~~
						/// ~~ Check if User/Account has enought data per this Day/User Rank to pass Threshold and be qualified to be included to the chart's compressed set.
						/// ~~ Plus Let accounts listed in json settings file no matter the volumethey consume
						if (userNameCoreFirstEntry.compareTo("") != 0 && userNameCoreFirstEntry.compareTo("-") != 0 /// TODO move '-' to json setup file
								&& (uacci.getEventsCountPerDayPerRank() > aSSetLocal.getChartThresholdEvents() //
										|| uacci.getExecutionTimePerDayPerRankMSec() > aSSetLocal.getChartThresholdExecutionTimesSec() * 1000 //
										|| uacci.getBytesSentPerDayPerRank() > aSSetLocal.getChartThresholdBytesSent() //
										|| aSSetLocal.getCollectIfAccountsAre() != null && aSSetLocal.getCollectIfAccountsAre().size() > 0 && aSSetLocal.getCollectIfAccountsAre().contains(userNameCoreFirstEntry))) {

							if (false) { /// DEBUG
								System.out.println("~passed rules: [" + userNameCoreFirstEntry + "] [" + userKey + "]" /// DEBUG
										+ " " + uacci.getEventsCountPerDayPerRank() /// DEBUG
										+ " " + uacci.getExecutionTimePerDayPerRankMSec() /// DEBUG
										+ " " + uacci.getBytesSentPerDayPerRank()); /// DEBUG
							} /// DEBUG

							/// ~~ Collect all usersAccounts (they are scattered by days), so check for new usersAccount at every day data set
							utilsDBaseSeismoGraphLegendAndData.addUserAccountToTheHasMapIfItsNotInDBYet(userNameCoreFirstEntry);

							TreeMap<Long, PojoJiraLogRowData> rankData = userAccountRank.getValue();
							/// System.out.println("~~L2.Acc+Event: " + accounts.getKey() + ", RankDataPoints: " + rankData.size()); ///~~DEBUG~~
							Long xRankLeftLowTimeSlotToFuseMiliSec = 0L; // ~~ Floor and ceiling, leftLowTime and rightHighTime
							Long xRankRightHighTimeSlotToFuseMiliSec = xRankLeftLowTimeSlotToFuseMiliSec + xFuseSlabGridTickMilliSec;
							Long xRankDataPointTimeMiliSec = 0L;
							Long countEventsPerTick = 1L;
							boolean isFoundDataPoinsInRank = false;

							/// ~~ Loop 3 (all 24 hours) -- COMPRESS Data Rank all events for the account to the time axis chart grid
							Iterator<Entry<Long, PojoJiraLogRowData>> rankIter = rankData.entrySet().iterator();
							Entry<Long, PojoJiraLogRowData> rankDataValue = null;
							PojoJiraLogRowData xCompressedDataPoint = null; // compressed (fused data blob) DataSetForChartOfJiraLogPoints
							while (rankIter.hasNext()) {
								rankDataValue = rankIter.next();
								if (latestSavedLocalDateTimeInMillis == null || rankDataValue.getValue().getLocalDateTimeMsec() > latestSavedLocalDateTimeInMillis) {
									xRankDataPointTimeMiliSec = rankDataValue.getKey() - dayRanks.getKey(); // ~~ DateTime - Date = Time
									/// xRankDataPointTimeMiliSec = rankDataValue.getKey(); //~~ DateTime
									/// if (xCompressedDataPoint == null) {xCompressedDataPoint = clonePojoJiraLogFilesRow(rankDataValue.getValue());}

									/// ~~~COMPRESSOR (combines log records with time between start and end of within a chart grid)
									// Long xGridTickToHostCompressedDataPointTimeOfTheDayOnly = getGridTimeTickToFuseDataBlobKey(xRankDataPointTimeMiliSec); //~~ Just time as a key 0, 1, ...23 hrs
									Long xGridTickToHostCompressedDataPoint = getGridTimeTickToFuseDataBlobKey(xRankDataPointTimeMiliSec + dayRanks.getKey()); // ~~ If key is Date and Time
									TreeMap<String, PojoJiraLogRowData> existingChartTickWithSomeUsers = compressedDataSetForChartOfJiraLogPoints.get(xGridTickToHostCompressedDataPoint);
									if (existingChartTickWithSomeUsers != null) {
										// System.out.println("~~Existing UserNameFull(): " + rankDataValue.getValue().getUserNameCore()); ///DEBUG
										xCompressedDataPoint = existingChartTickWithSomeUsers.get(rankDataValue.getValue().getUserNameCore());
										if (xCompressedDataPoint != null) {
											/// ~~ Existing chart-ready compressed datapoint
											/// This user account already present at this chart grid time tick, so just increase counters of that user's calls
											if (rankDataValue.getValue().getEventsCountDataPoint() == null) {
												rankDataValue.getValue().setEventsCountDataPoint(0L);
											}
											if (rankDataValue.getValue().getEventsCountPerChartTick() == null) {
												rankDataValue.getValue().setEventsCountPerChartTick(0L);
											}
											if (rankDataValue.getValue().getExecutionTimeDataPointMSec() == null) {
												rankDataValue.getValue().setExecutionTimeDataPointMSec(0L);
											}
											if (rankDataValue.getValue().getExecutionTimePerChartTickMSec() == null) {
												rankDataValue.getValue().setExecutionTimePerChartTickMSec(0L);
											}
											if (rankDataValue.getValue().getBytesSentDataPoint() == null) {
												rankDataValue.getValue().setBytesSentDataPoint(0L);
											}
											if (rankDataValue.getValue().getBytesSentPerChartTick() == null) {
												rankDataValue.getValue().setBytesSentPerChartTick(0L);
											}
											if (xCompressedDataPoint.getEventsCountDataPoint() == null) {
												xCompressedDataPoint.setEventsCountDataPoint(0L);
											}
											if (xCompressedDataPoint.getEventsCountPerChartTick() == null) {
												xCompressedDataPoint.setEventsCountPerChartTick(0L);
											}
											if (xCompressedDataPoint.getExecutionTimeDataPointMSec() == null) {
												xCompressedDataPoint.setExecutionTimeDataPointMSec(0L);
											}
											if (xCompressedDataPoint.getExecutionTimePerChartTickMSec() == null) {
												xCompressedDataPoint.setExecutionTimePerChartTickMSec(0L);
											}
											if (xCompressedDataPoint.getBytesSentDataPoint() == null) {
												xCompressedDataPoint.setBytesSentDataPoint(0L);
											}
											if (xCompressedDataPoint.getBytesSentPerChartTick() == null) {
												xCompressedDataPoint.setBytesSentPerChartTick(0L);
											}
											xCompressedDataPoint.setEventsCountPerChartTick(xCompressedDataPoint.getEventsCountPerChartTick() + rankDataValue.getValue().getEventsCountDataPoint());
											xCompressedDataPoint.setExecutionTimePerChartTickMSec(xCompressedDataPoint.getExecutionTimePerChartTickMSec() + rankDataValue.getValue().getExecutionTimeDataPointMSec());
											xCompressedDataPoint.setBytesSentPerChartTick(xCompressedDataPoint.getBytesSentPerChartTick() + rankDataValue.getValue().getBytesSentDataPoint());
										} else {
											/// This user account does not exist at this chart grid time tick, so create it
											/// ~~ Create New chart-ready compressed datapoint
											xCompressedDataPoint = clonePojoJiraLogFilesRow(rankDataValue.getValue());
											xCompressedDataPoint.setEventsCountPerChartTick(rankDataValue.getValue().getEventsCountDataPoint());
											xCompressedDataPoint.setExecutionTimePerChartTickMSec(rankDataValue.getValue().getExecutionTimeDataPointMSec());
											xCompressedDataPoint.setBytesSentPerChartTick(rankDataValue.getValue().getBytesSentDataPoint());
											existingChartTickWithSomeUsers.put(rankDataValue.getValue().getUserNameCore(), xCompressedDataPoint);
										}
									} else {
										/// ~~~ This User account is not present yet at this chart grid tick data set, so create it
										// System.out.println("~~Missing UserNameFull(): " + rankDataValue.getValue().getUserNameCore()); ///DEBUG
										xCompressedDataPoint = clonePojoJiraLogFilesRow(rankDataValue.getValue());
										xCompressedDataPoint.setEventsCountPerChartTick(rankDataValue.getValue().getEventsCountDataPoint());
										xCompressedDataPoint.setExecutionTimeDataPointMSec(rankDataValue.getValue().getExecutionTimeDataPointMSec());
										xCompressedDataPoint.setExecutionTimePerChartTickMSec(rankDataValue.getValue().getExecutionTimeDataPointMSec());
										xCompressedDataPoint.setBytesSentPerChartTick(rankDataValue.getValue().getBytesSentDataPoint());
										// xCompressedDataPoint.setUserNameFull(rankDataValue.getValue().getUserNameCore()); /// Not needed here
										TreeMap<String, PojoJiraLogRowData> newUserPerTick = new TreeMap<String, PojoJiraLogRowData>();
										newUserPerTick.put(rankDataValue.getValue().getUserNameCore(), xCompressedDataPoint);
										compressedDataSetForChartOfJiraLogPoints.put(xGridTickToHostCompressedDataPoint, newUserPerTick);
									}

									/// ~~ UNUSED ~~~
									if (false) {
										if (xRankDataPointTimeMiliSec > xRankRightHighTimeSlotToFuseMiliSec) {
											if (isFoundDataPoinsInRank) {
												/// ~~ Some data found in previous Time Slot/Blob, so save it
												/// System.out.println("~~~L3.: Save last chunk: "); ///~~DEBUG~~
												xCompressedDataPoint.setEventsCountPerChartTick(--countEventsPerTick);
												if (aSSetLocal.isSeismoUseJiraDbToPersistData()) {
													utilsDBaseSeismoGraphLegendAndData.addUserAccountToTheHasMapIfItsNotInDBYet("Put a UserNameFull here");
												}
												/// this.freshSetOfJiraLogPoints.add(xCompressedDataPoint);
												isFoundDataPoinsInRank = false;
												countEventsPerTick = 1L;
												xCompressedDataPoint = null;
												xRankLeftLowTimeSlotToFuseMiliSec += xFuseSlabGridTickMilliSec;
												xRankRightHighTimeSlotToFuseMiliSec = xRankLeftLowTimeSlotToFuseMiliSec + xFuseSlabGridTickMilliSec;
											}
										}
										// ~~ Skip Time Slots for fusing data to a single data blob point if there is no data points found in the next proposed time slot
										while (xRankDataPointTimeMiliSec > xRankRightHighTimeSlotToFuseMiliSec) {
											xRankLeftLowTimeSlotToFuseMiliSec += xFuseSlabGridTickMilliSec;
											xRankRightHighTimeSlotToFuseMiliSec = xRankLeftLowTimeSlotToFuseMiliSec + xFuseSlabGridTickMilliSec;
										}
										// ~~ Debug ~~
										// LocalDateTime debugDateTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(rankDataValue.getKey()), ZoneId.of("UTC")); ///~~DEBUG~~
										// LocalDateTime debugRankDataPointTimeMiliSec = LocalDateTime.ofInstant(Instant.ofEpochMilli(xRankDataPointTimeMiliSec), ZoneId.of("UTC")); ///~~DEBUG~~
										// DateTimeFormatter debugDateTimeFormatterTime = DateTimeFormatter.ofPattern("HH:mm:ss"); ///~~DEBUG~~
										// System.out.println("~~~L3.DataPointTime: " + debugDateTime.format(debugDateTimeFormatter) + ", DP: " + debugRankDataPointTimeMiliSec.format(debugDateTimeFormatterTime)); ///~~DEBUG~~
										// ~~ End of Debug ~~
										if (xRankDataPointTimeMiliSec < xRankRightHighTimeSlotToFuseMiliSec) {
											// System.out.println("~~~L3.: Save chunk: " + debugDateTime.format(debugDateTimeFormatter) + ", rankTimeSliding: " + debugRankDataPointTimeMiliSec.format(debugDateTimeFormatterTime)); ///~~DEBUG~~
											isFoundDataPoinsInRank = true;
											countEventsPerTick++;
											countEventsPerTick += rankDataValue.getValue().getEventsCountPerChartTick();
										}
									}
								}
							}
							/// ~~ UNUSED ~~~
							if (false && isFoundDataPoinsInRank && xCompressedDataPoint != null) {
								// ~~ Some incomplete data found in previous Time Slot/Blob, so save it.
								/// System.out.println("~~~L3.: Save very last chunk: "); ///~~DEBUG~~
								xCompressedDataPoint.setEventsCountPerChartTick(--countEventsPerTick);
								utilsDBaseSeismoGraphLegendAndData.addUserAccountToTheHasMapIfItsNotInDBYet("Put a UserNameFull here");
								// this.freshSetOfJiraLogPoints.add(xCompressedDataPoint);
							}
						}
					}
				}
			}
		}

		/// ~~~ Step 3. Persist chart data to the database OR to the CSV file
		if (aSSetLocal.isSeismoUseJiraDbToPersistData()) {
			utilsDBaseSeismoGraphLegendAndData.deleteFromDbTSeismoactivitychartdataTheOutdatedJiraLogsData(LocalDateTime.now().minusMinutes(aSSetLocal.getSeismoChartTimeSpanMinutes())); // ~~ Clear obsolete data ~~
			utilsDBaseSeismoGraphLegendAndData.insertToDBTseismoactivitychartdataTheJiraLogsData(compressedDataSetForChartOfJiraLogPoints, aSSetLocal);
			utilsDBaseSeismoGraphLegendAndData.insertToDBTseismographlegendTheSeriesLabels(); // ~~ Check if thre are new legend(s) and persiste them if any.
			utilsDBaseSeismoGraphLegendAndData.selectFromDBTseismographlegendTheSeriesLabels(); // ~~Refresh Series/Legend/Labels dictionary after probably adding new to DB
		} else {
			/// ~~ Print Header (List of the User Accounts)
			saveCompressedDataToCsvFile(compressedDataSetForChartOfJiraLogPoints, aSSetLocal);
			saveBadActors(compressedDataSetForChartOfJiraLogPoints);
		}

		/// System.out.println("~~ Completed reading Jira Logs.");
	}

	private final TreeMap<String, PojoJiraLogRowData> buildHeaderRow(TreeMap<Long, TreeMap<String, PojoJiraLogRowData>> aCompressedDataSetForChartOfJiraLogPoints) {
		/// ~~ in 'aCompressedDataSetForChartOfJiraLogPoints'
		/// ~~ key 1 -- Chart rounded time X axis grid ticks compressed data
		/// ~~ key 2 -- User Accounts
		TreeMap<String, PojoJiraLogRowData> headerRow = new TreeMap<String, PojoJiraLogRowData>();
		/// ~~Gather all users accounts from all data points
		/// ~~ Loop 1 by chart time X axis grid ticks
		aCompressedDataSetForChartOfJiraLogPoints.forEach((Long gridTick, TreeMap<String, PojoJiraLogRowData> someUsersChartDataPoint) -> {
			if (someUsersChartDataPoint != null) {
				/// ~~ Loop 2 by User Accounts
				someUsersChartDataPoint.forEach((String userkey, PojoJiraLogRowData data) -> {
					PojoJiraLogRowData values = new PojoJiraLogRowData();
					if (!headerRow.containsKey(data.getUserNameCore())) {
						/// ~~~ New UserAccount Header column/field name
						headerRow.put(data.getUserNameCore(), values);
					} else {
						/// ~~~ Existing UserAccount Header column/field name
						values = headerRow.get(userkey);
					}
				});
			}
		});
		return headerRow;
	}

	private final String getTabBreadcrumb(TreeMap<String, PojoJiraLogRowData> allFieldsUsersAccounts, String aPrevLexema, String aCurrentLexema) {
		/// ~~ Determins if there are gaps and returns calculated number of TABs to skip empty cells
		/// ~~ Serves only cases like:
		/// U1, U2, U3
		/// , U2, U3
		/// U1, , U3
		StringBuilder breadcrumb = new StringBuilder();
		StringBuilder prevLexema = new StringBuilder(aPrevLexema);
		allFieldsUsersAccounts.forEach((k, v) -> {
			if (prevLexema.length() == 0) {
				prevLexema.append(v);
				/// ~~ this is the first ever request, so previous aPrevLexema == ''
				/// This is first time, so consider to sckip first few fields if they are empty
				breadcrumb.append("\t"); // ~~ Separate from first label/Date column
				if (k.compareTo(aCurrentLexema) == 0) {
					/// ~~ First cell has data, exit method
				} else if (k.compareTo(aCurrentLexema) < 0) {
					// ~~ first one or more cells are empty, so return '0\t'
					breadcrumb.append("0\t");
				}
			} else { // ~~ Not the begining of the row
				if (k.compareTo(aPrevLexema.toString()) >= 0 && k.compareTo(aCurrentLexema) < 0) {
					if (k.compareTo(aPrevLexema.toString()) != 0) {
						breadcrumb.append("0"); // ~~ Add '0' to fill sckipped excel data cell
					}
					breadcrumb.append("\t"); // ~~ Add '0' to fill sckipped excel data cell
				}
			}
		});
		if (breadcrumb.length() == 0) {
			breadcrumb.append("\t");
		}
		return breadcrumb.toString();
	}

	private final void saveCompressedDataToCsvFile(TreeMap<Long, TreeMap<String, PojoJiraLogRowData>> aCompressedDataSetForChartOfJiraLogPoints, PojoJsonSystemSettingsFile aSSetLocal) {
		StringBuilder columnUserNames = new StringBuilder("");
		StringBuilder datalistCallsCounter = new StringBuilder("");
		StringBuilder datalistExecutionTime = new StringBuilder("");
		StringBuilder datalistBytesTransmitted = new StringBuilder("");
		TreeMap<String, PojoJiraLogRowData> headerMap = buildHeaderRow(aCompressedDataSetForChartOfJiraLogPoints);
		// StringBuilder prevUser = new StringBuilder(headerMap.firstEntry().getKey()); //~~ Set name of the very first field/column as previous

		/// ~~ Loop 1 by chart time X axis grid ticks
		aCompressedDataSetForChartOfJiraLogPoints.forEach((Long gridTick, TreeMap<String, PojoJiraLogRowData> someUsersChartDataPoint) -> {
			datalistCallsCounter.append("\n");
			datalistExecutionTime.append("\n");
			datalistBytesTransmitted.append("\n");
			/// datalist.append("" + gridTick / 1000f / 60f / 24f / 60f); //~~ Time only (24 hours [0..1] ), no Date

			/// ~~ Make DateTime from ms
			UtilsLogsSys utilsLogsSys = new UtilsLogsSys();
			String tickDateTime = utilsLogsSys.formatDateTimeFromMs(gridTick);
			datalistCallsCounter.append("" + tickDateTime); // ~~ time as fraction of the day, e.g. 6am = 0.25.
			datalistExecutionTime.append("" + tickDateTime);
			datalistBytesTransmitted.append("" + tickDateTime);
			/// ~~ Obsolete datalist.append("" + gridTick / 1000f / 60f / 24f / 60f); //~~ time as fraction of the day, e.g. 6am = 0.25.

			/// ~~ 'someUsersChartDataPoint'
			/// ~~ key 1 -- Chart rounded time X axis grid ticks compressed data
			/// ~~ key 2 -- User Accounts
			if (someUsersChartDataPoint != null) {
				/// ~~ Loop 2 by User Accounts
				StringBuilder prevUser = new StringBuilder("");
				AtomicInteger lastUsedField = new AtomicInteger(0); // ~~ reset used colums count
				someUsersChartDataPoint.forEach((String userkey, PojoJiraLogRowData data) -> {

					if (data != null) {
						/// ~~ User has data at this chart data point
						String tc = getTabBreadcrumb(headerMap, prevUser.toString(), data.getUserNameCore());
						if (data.getEventsCountPerChartTick() == null) {
							data.setEventsCountPerChartTick(0L);
						}
						if (data.getExecutionTimePerChartTickMSec() == null) {
							data.setExecutionTimePerChartTickMSec(0L);
						}
						if (data.getBytesSentPerChartTick() == null) {
							data.setBytesSentPerChartTick(0L);
						}
						datalistCallsCounter.append("" + tc + data.getEventsCountPerChartTick());
						datalistExecutionTime.append("" + tc + String.format("%.1f", data.getExecutionTimePerChartTickMSec() / msToMinutes)); // ~~ minutes
						datalistBytesTransmitted.append("" + tc + String.format("%.1f", data.getBytesSentPerChartTick() / bytesToMB)); // ~~ MB

						String countTabs = tc.replaceAll("0", ""); // ~~ remove all zeros added to fill the skipped data cell, count just tabs.
						lastUsedField.getAndAdd(countTabs.length());
						prevUser.setLength(0);
						prevUser.append(userkey);
					} else {
						datalistCallsCounter.append("!"); // ~~ Don't see it so far
						datalistExecutionTime.append("!");
						datalistBytesTransmitted.append("!");
					}
				});
				/// ~~ After Fill the 'tail' - excel cells to the right from last filled field/column, if any
				if (lastUsedField.get() < (headerMap.size())) {
					for (int ii = 0; ii < (headerMap.size() - lastUsedField.get()); ii++) {
						datalistCallsCounter.append("\t0.0"); // ~~ Fill with zerow the tail (rest of the otherwise empty cells)
						datalistExecutionTime.append("\t0.0"); // ~~ Fill with zerow the tail (rest of the otherwise empty cells)
						datalistBytesTransmitted.append("\t0.0"); // ~~ Fill with zerow the tail (rest of the otherwise empty cells)
					}
				}
			} else {
				/// ~~~ there is no data at all in this Time Slot on Chart Time Grid, so fill whole row with all zeros
				headerMap.forEach((String k, PojoJiraLogRowData v) -> {
					datalistCallsCounter.append("\t0.0");
					datalistExecutionTime.append("\t0.0");
					datalistBytesTransmitted.append("\t0.0");
				});
			}
		});

		// System.out.println("~~Printing Jira Load data matrix for excel plot"); ///DEBUG
		headerMap.forEach((String k, PojoJiraLogRowData v) -> columnUserNames.append("\t'" + k));
		String toSave = headerLabels[1] + columnUserNames.toString() + datalistCallsCounter.toString() // http.sessions?
				+ "\n\n" + headerLabels[2] + columnUserNames.toString() + datalistExecutionTime.toString() //
				+ "\n\n" + headerLabels[3] + columnUserNames.toString() + datalistBytesTransmitted.toString();
		// System.out.println(toSave); ///DEBUG
		// ~~ Save to the file:
		UtilsLogsSys utilsLogsSys = new UtilsLogsSys();
		utilsLogsSys.saveChartLegendLabels(toSave, EpLogAnalyzer.SysSetngs, "Jira-Load-Matrix-For-Excel-Plot-");

	}

	private final void saveBadActors(TreeMap<Long, TreeMap<String, PojoJiraLogRowData>> aCompressedDataSetForChartOfJiraLogPoints) {
		/// ~~~ Loop all grid ticks and find the SUM or User Account activities: [calls count, execution time, bytes] per that day
		TreeMap<String, PojoJiraLogRowData> badActors = new TreeMap<String, PojoJiraLogRowData>();
		/// ~~~ First key is User Account Core Name
		/// ~~~ Second key is type of User day data: [calls count, execution time, bytes]
		/// ~~~ Loop by grid axis time ticks
		aCompressedDataSetForChartOfJiraLogPoints.forEach((Long gridTick, TreeMap<String, PojoJiraLogRowData> someUserActivities) -> {
			if (someUserActivities != null) {
				/// ~~~ Loop by user's accounts
				someUserActivities.forEach((String user, PojoJiraLogRowData data) -> {
					PojoJiraLogRowData usersActivities;
					/// ~~~ First key is type of User day data: [calls count, execution time, bytes]
					if (badActors.containsKey(user)) {
						usersActivities = badActors.get(user);
						usersActivities.setEventsCountPerDayPerRank(usersActivities.getEventsCountPerDayPerRank() + data.getEventsCountPerChartTick());
						usersActivities.setExecutionTimePerDayPerRankMSec(usersActivities.getExecutionTimePerDayPerRankMSec() + data.getExecutionTimePerChartTickMSec());
						usersActivities.setBytesSentPerDayPerRank(usersActivities.getBytesSentPerDayPerRank() + data.getBytesSentPerChartTick());

						// if (data.getExecutionTimePerChartTickMSec() != null) {
						// usersActivities.setExecutionTimePerDayPerRankMSec(usersActivities.getExecutionTimePerDayPerRankMSec() + data.getExecutionTimePerChartTickMSec());
						// } else {
						// usersActivities.setExecutionTimePerDayPerRankMSec(usersActivities.getExecutionTimePerDayPerRankMSec());
						// }
						// if (usersActivities.getBytesSentPerDayPerRank() != null) {
						// usersActivities.setBytesSentPerDayPerRank(usersActivities.getBytesSentPerDayPerRank() + data.getBytesSentPerChartTick());
						// } else {
						// usersActivities.setBytesSentPerDayPerRank(data.getBytesSentPerChartTick());
						// }

					} else {
						usersActivities = new PojoJiraLogRowData();
						usersActivities.setEventsCountPerDayPerRank(data.getEventsCountPerChartTick());
						usersActivities.setExecutionTimePerDayPerRankMSec(data.getExecutionTimePerChartTickMSec());
						usersActivities.setBytesSentPerDayPerRank(data.getBytesSentPerChartTick());
						/// ~~ Extra Data: [Max Value, time of max Value
						/// ~~ Time of offend (max volume)
						// usersActivities.setEventsCountMaxPerDayAllRanks(data.getEventsCountPerChartTick());
						// usersActivities.setExecutionTimeMaxPerDayAllRanksMSec(data.getExecutionTimePerChartTickMSec());
						// usersActivities.setBytesSentMaxPerDayAllRanks(data.getBytesSentPerChartTick());
						badActors.put(user, usersActivities);
					}
				});
			}
		});

		/// ~~ Essense -- list of the heavy users with summary per day
		System.out.println("\n~~Short list of the heavy users with summary per day"); /// DEBUG
		System.out.print("\n" + headerLabels[0] + "\t" + headerLabels[1] + "\t" + headerLabels[2] + "\t" + headerLabels[3]); // ~~ Header
		badActors.forEach((String user, PojoJiraLogRowData data) -> {
			System.out.print("\n" + user //
					+ "\t" + data.getEventsCountPerDayPerRank()//
					+ "\t" + String.format("%.1f", data.getExecutionTimePerDayPerRankMSec() / msToMinutes) // ~~ minutes
					+ "\t" + String.format("%.1f", data.getBytesSentPerDayPerRank() / bytesToMB) // ~~ MB
			);
		});
		System.out.print("\n"); // footer
	}

	private final Long getGridTimeTickToFuseDataBlobKey(Long aDataPointTime) {
		/// ~~~COMPRESSOR (combines log records with time between start and end of within a chart grid)
		/// ~~ Find Time Slot for fusing data to a single data blob point ~~
		if (aDataPointTime != null) {
			if (aDataPointTime == 0) {
				return xFuseSlabGridTickMilliSec;
			}
			int looper = 0;
			while (aDataPointTime > looper++ * xFuseSlabGridTickMilliSec) {
			}
			return --looper * xFuseSlabGridTickMilliSec - xFuseSlabGridTickMilliSec; // ~~ for grid period 5 minutes, will return 300,000*N, where N - multiples of period next to 'aDataPointTime'
		}
		return null;
	}

	private final PojoJiraLogRowData clonePojoJiraLogFilesRow(PojoJiraLogRowData orig) {
		PojoJiraLogRowData clone = null;
		if (orig != null) {
			clone = new PojoJiraLogRowData();
			clone.setLocalDateTime(orig.getLocalDateTime());
			clone.setUserNameCore(orig.getUserNameCore());
			clone.setUserNameFull(orig.getUserNameFull());
			clone.setHttpResponseStatusCode(orig.getHttpResponseStatusCode());
			clone.setHttpRequestApiCallCore(orig.getHttpRequestApiCallCore());
			if (orig.getEventsCountDataPoint() == null) {
				clone.setEventsCountDataPoint(0L);
			} else {
				clone.setEventsCountDataPoint(orig.getEventsCountDataPoint());
			}
			if (orig.getEventsCountPerChartTick() == null) {
				clone.setEventsCountPerChartTick(0L);
			} else {
				clone.setEventsCountPerChartTick(orig.getEventsCountPerChartTick());
			}
			if (orig.getExecutionTimeDataPointMSec() == null) {
				clone.setExecutionTimeDataPointMSec(0L);
			} else {
				clone.setExecutionTimeDataPointMSec(orig.getExecutionTimeDataPointMSec());
			}
			if (orig.getExecutionTimePerChartTickMSec() == null) {
				clone.setExecutionTimePerChartTickMSec(0L);
			} else {
				clone.setExecutionTimePerChartTickMSec(orig.getExecutionTimePerChartTickMSec());
			}
			if (orig.getBytesSentDataPoint() == null) {
				clone.setBytesSentDataPoint(0L);
			} else {
				clone.setBytesSentDataPoint(orig.getBytesSentDataPoint());
			}
			if (orig.getBytesSentPerChartTick() == null) {
				clone.setBytesSentPerChartTick(0L);
			} else {
				clone.setBytesSentPerChartTick(orig.getBytesSentPerChartTick());
			}
			// ~~ Note: Add more here, if another data will be used in chart labels 'buildLegendNameForJiraLogEntries()'
		}
		return clone;
	}

}
