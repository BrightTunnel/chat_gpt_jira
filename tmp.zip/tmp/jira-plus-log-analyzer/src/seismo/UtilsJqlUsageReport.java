package seismo;

import java.util.TreeMap;
import java.util.TreeSet;

import jira_log_analyzer.EpLogAnalyzer;
import jira_log_analyzer.UtilsLogsParsing;
import jira_log_analyzer.UtilsLogsSys;
import pojo.PojoJiraLogJql;

public class UtilsJqlUsageReport {

	public UtilsJqlUsageReport(EpLogAnalyzer ep) {
		this.ep = ep;
	}
	private EpLogAnalyzer ep;

	private TreeMap<String, PojoJiraLogJql> printme;

	public final void printJqlUsage(TreeMap<Long, TreeMap<String, TreeMap<Long, PojoJiraLogJql>>> aDictJql) {
		// System.out.print("\n~~Printing JQL Usage Report while remapping\n"); ///Debug
		printme = new TreeMap<String, PojoJiraLogJql>();
		aDictJql.forEach((Long kyeDays, TreeMap<String, TreeMap<Long, PojoJiraLogJql>> dayJqls) -> {
			dayJqls.forEach((String keyJql, TreeMap<Long, PojoJiraLogJql> jqlsDataPoints) -> {
				jqlsDataPoints.forEach((Long keyDatPointTime, PojoJiraLogJql dataPoint) -> {
					if (false) { ///Debug
						System.out.print("\nDay:" + kyeDays); ///Debug
						System.out.print("\tTime:" + keyDatPointTime); ///Debug
						System.out.print("\tExecuted in: " + dataPoint.getExecutionTimeDataPointMSec()); ///Debug
						System.out.print("\t[" + dataPoint.getUserNameCore().toString() + "]"); ///Debug
						System.out.print("\t{" + keyJql + "}"); ///Debug
					} ///Debug
						///~~ Build new printable set
					PojoJiraLogJql summaryToPrint = null;
					if (printme.containsKey(keyJql)) {
						summaryToPrint = printme.get(keyJql);
						summaryToPrint.setUsageCounter(summaryToPrint.getUsageCounter() + 1);
					} else {
						summaryToPrint = new PojoJiraLogJql();
						summaryToPrint.setUsageCounter(1L);
						summaryToPrint.setExecutionTimeMin(Long.MAX_VALUE);
						summaryToPrint.setExecutionTimeMax(Long.MIN_VALUE);
						summaryToPrint.setUserNameCore(new TreeSet());
						printme.put(keyJql, summaryToPrint);
					}
					summaryToPrint.setNumberOfClausesInQuery(dataPoint.getNumberOfClausesInQuery());
					summaryToPrint.setNumberOfResults(dataPoint.getNumberOfResults());
					if (summaryToPrint.getUserNameCore().isEmpty() || !dataPoint.getUserNameCore().contains(summaryToPrint.getUserNameCore().first())) { //~~ Source Has single name, so first() 
						summaryToPrint.getUserNameCore().add(dataPoint.getUserNameCore().first());
					}
					if (dataPoint.getExecutionTimeDataPointMSec() != null) {
						if (summaryToPrint.getExecutionTimeMin() == null || summaryToPrint.getExecutionTimeMin() > dataPoint.getExecutionTimeDataPointMSec()) {
							summaryToPrint.setExecutionTimeMin(dataPoint.getExecutionTimeDataPointMSec());
						}
						if (summaryToPrint.getExecutionTimeMax() == null || summaryToPrint.getExecutionTimeMax() < dataPoint.getExecutionTimeDataPointMSec()) {
							summaryToPrint.setExecutionTimeMax(dataPoint.getExecutionTimeDataPointMSec());
						}
					}
					summaryToPrint.setUrl(dataPoint.getUrl());
					///summaryToPrint.setExecutionTimeDataPointMSec(dataPoint.getExecutionTimeDataPointMSec()); //~~ Last or only execution time, kinda useles
				});
			});
		});

		System.out.print("\n~~Slow JQLs and Users called them.\n"); ///Debug
		String header = "";
		header += "use count";
		header += "\tmin exec time ms";
		header += "\tmax exec time ms";
		header += "\tnumberOfClausesInQuery";
		header += "\tnumberOfResults";
		header += "\tjql";
		header += "\turl";
		header += "\tusers";
		//System.out.print("\n" + header); ///Debug
		StringBuilder sb = new StringBuilder(header);
		printme.forEach((String keyJql, PojoJiraLogJql valueJqlDetails) -> {
			sb.append("\n" + valueJqlDetails.getUsageCounter());
			sb.append("\t" + valueJqlDetails.getExecutionTimeMin());
			sb.append("\t" + valueJqlDetails.getExecutionTimeMax());
			if (valueJqlDetails.getNumberOfClausesInQuery() != UtilsLogsParsing.jiraLogValueUnavailable) {
				sb.append("\t" + valueJqlDetails.getNumberOfClausesInQuery());
			} else {
				sb.append("\t");
			}
			if (valueJqlDetails.getNumberOfResults() != UtilsLogsParsing.jiraLogValueUnavailable) {
				sb.append("\t" + valueJqlDetails.getNumberOfResults());
			} else {
				sb.append("\t");
			}
			sb.append("\t" + keyJql);
			sb.append("\t" + valueJqlDetails.getUrl());
			sb.append("\t" + valueJqlDetails.getUserNameCore().toString());
		});
		//System.out.print(sb.toString() + "\n"); ///Debug

		//~~ Save to the file:
		UtilsLogsSys utilsLogsSys = new UtilsLogsSys();
		utilsLogsSys.saveChartLegendLabels(sb.toString(), EpLogAnalyzer.SysSetngs, "SlowJQL-");

	}
}
