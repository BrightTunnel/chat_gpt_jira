package seismo;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.TreeMap;

import jira_log_analyzer.UtilsLogsSys;
import pojo.PojoJiraLogRowData;
import pojo.PojoJsonSystemSettingsFile;

public class UtilsDBaseSeismoGraphLegendAndData {
	///~~ Class dedicated to SQL DBase-related 'SeismoGraph' tables methods

	public static LinkedHashMap<Long, PojoSeismoGraphParam> seismoGraphLegendList = new LinkedHashMap<Long, PojoSeismoGraphParam>();
	private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
	private final int md5keyMaxSizeToLong = 15; // ~~Max number of HEX characters to be converted to Long is less than 16 chars, so be safe use 15 chars only.
	private Properties props;
	private String url;

	public UtilsDBaseSeismoGraphLegendAndData() {
		UtilsLogsSys utilsLogsSys = new UtilsLogsSys();
		PojoJsonSystemSettingsFile sysSetngs00 = utilsLogsSys.getSysSettings("jira-log-analyzer-settings.json");
		props = new Properties();
		props.setProperty("user", sysSetngs00.getDbUsername()); // "postgres"
		props.setProperty("password", sysSetngs00.getDbPassword()); // "amp"
		props.setProperty("ssl", sysSetngs00.isDbEnableSsl() ? "true" : "false"); // "false"
		url = sysSetngs00.getDbDriver() + sysSetngs00.getDbHost() + ":" + sysSetngs00.getDbPortNumber() + "/" + sysSetngs00.getDbName();
	}

	///~~~ Seismograph Data ~~~ 

	final LocalDateTime selectFromDBTseismoactivitychartdataTheSingleLastRecord() {
		Connection conn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		String _sql = "";
		LocalDateTime ldt = null;
		try {
			Class.forName("org.postgresql.Driver");
			conn = DriverManager.getConnection(url, props);
			statement = conn.createStatement();
			_sql = "SELECT MAX(chartaxisxtime) FROM ao_be0df6_seismoactivitychartdata WHERE servicehash>=0;";
			resultSet = statement.executeQuery(_sql);
			Timestamp dt = null;
			if (resultSet.isBeforeFirst()) {
				resultSet.next();
				dt = resultSet.getTimestamp(1); // dBase field 'chartaxisxtime'	
			}
			if (dt != null) {
				ldt = dt.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
			}
			resultSet.close();
			statement.close();
		} catch (Exception e) {
			System.out.println("~~Can't connect to '" + conn + "'\n~~Exit with error 064773458848");
			e.printStackTrace();
			System.exit(1);
		} finally {
			if (resultSet != null) {
				try {
					resultSet.close();
				} catch (Exception e) {
				}
			}
			if (statement != null) {
				try {
					statement.close();
				} catch (Exception e) {
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception e) {
				}
			}
		}
		//System.err.println("~~Latest seismo record: '" + ldt);
		return ldt;
	}

	final void insertToDBTseismoactivitychartdataTheJiraLogsData(TreeMap<Long, TreeMap<String, PojoJiraLogRowData>> compressedDataSetForChartOfJiraLogPoints, PojoJsonSystemSettingsFile aSSetLocal) {
		//System.out.println(" ~INSERT RECORD");
		Connection conn = null;
		//~~ INSERT INTO User (FirstName, LastName) VALUES ('test','test'),('test','test'),... ;
		//~~ INSERT INTO ao_be0df6_seismoactivitychartdata (serviceid, servicehash, chartaxisxtime, chartaxisyvalue) VALUES('Service', 'May 1, 2022 13:14:15', 7.77);
		//String _sql = "INSERT INTO ao_be0df6_seismoactivitychartdata (serviceid, servicehash, chartaxisxtime, chartaxisyvalue) VALUES";
		String _sql = "INSERT INTO ao_be0df6_seismoactivitychartdata (servicehash, chartaxisxtime, chartaxisyvalue) VALUES";
		boolean isInsert = false;
		///~~~ Loop 1. by ticks of compressed chart time grid 
		for (Entry<Long, TreeMap<String, PojoJiraLogRowData>> accountsByDates : compressedDataSetForChartOfJiraLogPoints.entrySet()) {
			///~~~ Loop 2. by user having data for the tick
			if (accountsByDates != null && accountsByDates.getValue() != null) {
				for (Entry<String, PojoJiraLogRowData> usersData : accountsByDates.getValue().entrySet()) {
					if (usersData.getValue().getEventsCountPerChartTick() >= aSSetLocal.getSeismoMinNumberOfEventsPerSlabToPersist()) { //~~ Business Rule~~ Do not save to DB small number of events.
						Long serviceid = calculateLongMD5HashKey(usersData.getKey());
						_sql += "(" + serviceid + ","; // md5

						///~~ Make DateTime from ms
						UtilsLogsSys utilsLogsSys = new UtilsLogsSys();
						String tickDateTime = utilsLogsSys.formatDateTimeFromMs(accountsByDates.getKey());
						_sql += "'" + tickDateTime + "',";
						_sql += "" + usersData.getValue().getEventsCountPerDayAllRanks() + "),";
						/// _sql += "'" + .getLocalDateTime().format(formatter) + "',"; //~~ Old way, save actuallog line time
						/// _sql += "'" + usersData.getValue().getLocalDateTime().format(formatter) + "',";
						/// _sql += "'" + keyValue.getKey().format(formatter) + "',";
						/// _sql += "" + keyValue.getValue().getEventsCountPerChartTick() + "),";
						isInsert = true;
					} else {
						//System.out.println("~~UtilsCompressLogDataAndSaveToDbOrCsv. EventsCountPerChartTick: " + keyValue.getValue().getEventsCountPerChartTick() + " < " + aSSetLocal.getSeismoMinNumberOfEventsPerSlabToPersist());
					}
				}
			}
		}
		if (isInsert) {
			_sql = _sql.substring(0, _sql.length() - 1); //~~ remove last extra comma
			_sql += ";";
			//System.out.println("~~ SQL: " + _sql);
			//~~Execute~~ 
			try {
				Class.forName("org.postgresql.Driver");
				conn = DriverManager.getConnection(url, props);
				final Statement stmt = conn.createStatement();
				boolean res = stmt.execute(_sql);
			} catch (ClassNotFoundException | SQLException e1) {
				System.out.println("~~Can't connect to '" + conn + "'\n~~Exit with error 0647590348");
				System.exit(1);
				// e1.printStackTrace();
			} finally {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		//System.out.println("~~ Completed Insert" );
	}

	final void deleteFromDbTSeismoactivitychartdataTheOutdatedJiraLogsData(LocalDateTime aDateTimeToKillTheDataBefore) {
		// System.out.println(" ~DELETE OLD OUTDATED RECORDS (CLEANING DATA)");
		// e.g: delete from ao_be0df6_seismoactivitychartdata where chartaxisxtime < '2023-05-23 21:49:46.329';

		Connection conn = null;
		String _sql = "DELETE FROM ao_be0df6_seismoactivitychartdata WHERE chartaxisxtime < '" + aDateTimeToKillTheDataBefore.format(formatter) + "'";
		//~~Execute~~ 
		try {
			Class.forName("org.postgresql.Driver");
			conn = DriverManager.getConnection(url, props);
			final Statement stmt = conn.createStatement();
			boolean res = stmt.execute(_sql);
		} catch (ClassNotFoundException | SQLException e1) {
			System.out.println("~~Can't connect to '" + conn + "'\n~~Exit with error 0647798348");
			System.exit(1);
			// e1.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	///~~~ Seismograph Legend Series Labels ~~~ 

	final void selectFromDBTseismographlegendTheSeriesLabels() {
		//System.out.println(" ~SELECT RECORDS");
		Connection conn = null;
		String sql = "SELECT id, servicehash, legend FROM ao_be0df6_seismographlegend ORDER BY servicehash;"; //~~ Order must! Will let us to issue compact serial index for chart legend / series 
		PreparedStatement st;
		PojoSeismoGraphParam _row;
		try {
			Class.forName("org.postgresql.Driver");
			conn = DriverManager.getConnection(url, props);
			final Statement stmt = conn.createStatement();
			boolean res = stmt.execute(sql);
			st = conn.prepareStatement(sql);
			ResultSet rs = st.executeQuery();
			// System.out.println("table_name,column_name,data_type,character_maximum_length,is_nullable,vendor");
			seismoGraphLegendList = new LinkedHashMap<Long, PojoSeismoGraphParam>();
			while (rs.next()) {
				_row = new PojoSeismoGraphParam();
				_row.setLegendServiceHashMd5Key(Long.parseLong(rs.getString(2))); // 'servicehash'
				_row.setLegendDataSetLabel(rs.getString(3)); // 'legend'
				seismoGraphLegendList.put(_row.getLegendServiceHashMd5Key(), _row);
			}
			rs.close();
			st.close();
		} catch (ClassNotFoundException | SQLException e1) {
			System.out.println("~~Can't connect to '" + conn + "'\n~~Exit with error 0546748");
			System.exit(1);
			// e1.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	final void insertToDBTseismographlegendTheSeriesLabels() {
		if (seismoGraphLegendList != null && !seismoGraphLegendList.isEmpty()) {
			for (Entry<Long, PojoSeismoGraphParam> keyValue : seismoGraphLegendList.entrySet()) {
				insertToDBTseismographlegendTheNextSeriesLabel(keyValue.getKey(), keyValue.getValue().getLegendDataSetLabel());
			}
		}
	}

	private final void insertToDBTseismographlegendTheNextSeriesLabel(Long aServicehash, String aLegend) {
		//System.out.println(" ~INSERT RECORD");
		//~~ TODO Insert legend/parameter only if related service value is added to the db table 'ao_be0df6_seismoactivitychartdata' 
		Connection conn = null;
		String _sql = "INSERT INTO ao_be0df6_seismographlegend (servicehash, legend) SELECT " + aServicehash + ",'" + aLegend + "'";
		_sql += " WHERE NOT EXISTS (SELECT servicehash FROM ao_be0df6_seismographlegend WHERE servicehash=" + aServicehash + ");";
		//~~Execute~~
		try {
			Class.forName("org.postgresql.Driver");
			conn = DriverManager.getConnection(url, props);
			final Statement stmt = conn.createStatement();
			boolean res = stmt.execute(_sql);
		} catch (ClassNotFoundException | SQLException e1) {
			System.out.println("~~Can't connect to '" + conn + "'\n~~Exit with error 053489548");
			System.exit(1);
			// e1.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		//System.out.println("~~ Completed Insert" );
	}

	///~~~ Service NON-SQL methods ~~~

	final void addUserAccountToTheHasMapIfItsNotInDBYet(String aKeyUserNameFull) {
		///System.out.print("~~Build list of userAccounts: " + aKeyUserAccount); ///DEBUG
		Long serviceUserAccountID = calculateLongMD5HashKey(aKeyUserNameFull);
		if (!seismoGraphLegendList.containsKey(serviceUserAccountID)) {
			String legendNameForJiraLogEntry = buildLegendNameForJiraLogEntries(aKeyUserNameFull);
			seismoGraphLegendList.put(serviceUserAccountID, new PojoSeismoGraphParam(serviceUserAccountID, legendNameForJiraLogEntry));
		}
	}

	private final String buildLegendNameForJiraLogEntries(String aKeyUserNameFull) {
		///~~ This is the the chart legend e.g '[u4,302,null]'
		///~~ Note: Add more in clonePojoJiraLogFilesRow(), if another data will be used in chart labels 'buildLegendNameForJiraLogEntries()'
		return "[" + aKeyUserNameFull + "]";
		//return "[" + pojoJiraLogRowData.getUserNameCore() + "," + pojoJiraLogRowData.getHttpResponseStatusCode() + "," + pojoJiraLogRowData.getHttpRequestApiCallCore() + "]";
	}

	private final Long calculateLongMD5HashKey(String anOrigString) {
		///~~Generated md5 Hash key to use as unique Database entry ID
		Long longMd5HashKeyOfOrigString = null;
		byte[] bytesOfOrigString = null;
		try {
			bytesOfOrigString = anOrigString.getBytes("UTF-8");
		} catch (UnsupportedEncodingException e1) {
		}
		MessageDigest md;
		try {
			md = MessageDigest.getInstance("MD5");
			byte[] bytesOfMd5HashKey = md.digest(bytesOfOrigString);
			String hexSringOfMd5HashKey = convertByteArrayToHEXString(bytesOfMd5HashKey);
			//~~ Convert HEX to Long, so it's may be used as a key for the legend service name
			String s = "7FFFFFFFFFFFFFFF"; // ~~Max number of HEX characters to be converted to Long is lless than 16 chars, so be safe use 15 chars only.
			s = hexSringOfMd5HashKey.toUpperCase();
			s = s.substring(s.length() - md5keyMaxSizeToLong, s.length()); //System.out.println("HEX String: " + s);
			long l = Long.valueOf(s, 16).longValue();
			longMd5HashKeyOfOrigString = l;
		} catch (NoSuchAlgorithmException e) {
		}
		return longMd5HashKeyOfOrigString;
	}

	private final String convertByteArrayToHEXString(byte[] b) {
		//~~ A faster way to convert a byte array to a HEX string 
		String result = "";
		for (int i = 0; i < b.length; i++) {
			result += Integer.toString((b[i] & 0xff) + 0x100, 16).substring(1);
		}
		return result;
	}

}

/*
-- DROP TABLE public.ao_be0df6_seismoactivitychartdata;
CREATE TABLE public.ao_be0df6_seismoactivitychartdata (
	id serial PRIMARY KEY,
	serviceid numeric NULL,
	chartaxisxtime timestamp(3) NULL,
	chartaxisyvalue float4 NULL,
	servicehash numeric NULL
);

-- DROP TABLE public.ao_be0df6_seismographlegend;
CREATE TABLE public.ao_be0df6_seismographlegend (
	id serial PRIMARY KEY,
	servicehash numeric NOT NULL,
	legend varchar NULL
);
*/

///TODO  check how often file 'jira-log-analyzer-settings.json' has been read in 'UtilsDBaseSeismoGraphLegendAndData'");
