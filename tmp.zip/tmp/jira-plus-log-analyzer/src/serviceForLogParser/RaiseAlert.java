package serviceForLogParser;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Base64;

public class RaiseAlert {
	String alert = "http://localhost:8080/rest/scriptrunner/latest/custom/restCreateIssue?projectname=JCS&issuetype=bug&reporterid=localadmin&summary=mysteingdescr&description=mydescription1";
	String authString = "localadmin:qqq";
	public void sendAlert() {
		// create a client
		HttpClient client = HttpClient.newHttpClient();
		String pwd = "Basic " + Base64.getEncoder().encodeToString(authString.getBytes());
		// create a request
		HttpRequest request = HttpRequest.newBuilder(URI.create(alert)).header("Authorization", pwd).build();
		int statusCode = client.sendAsync(request, HttpResponse.BodyHandlers.ofString()).thenApplyAsync(HttpResponse::statusCode).join();
		System.out.println(statusCode);
	}
}
