package serviceForLogParser;

public class ConstantsOfJiraLogs {

	//~~ HTTP Status Code Range Meanings - 100, 200, 300, 400, 500
	//	100�s - Informational codes used to relay information between client and server during a request. Example 100 code: The server received the request headers and determined the client is okay to continue sending the request body.
	//	200�s - success codes. These indicate that the request issued was successfully fulfilled.
	//	300�s - redirect codes. These codes are used to tell the browser or server that some other action needs to take place to complete the previous request.
	//	400�s - client errors. These indicates an error on the requesters behalf.
	//	500�s - server errors. These indicates an error on the servers behalf.

	public static final int HTTPStatusCodeEQ200Success = 200;
	public static final int HTTPStatusCodeGE300Rout = 300;
	public static final int HTTPStatusCodeGE400Fault = 400;
}
