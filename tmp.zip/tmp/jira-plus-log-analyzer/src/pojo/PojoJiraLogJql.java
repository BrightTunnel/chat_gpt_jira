package pojo;

import java.time.LocalDateTime;
import java.util.TreeSet;

public class PojoJiraLogJql {

	private String keyJiraQueryLanguageLine; //~~  JIRA Query Language full string  	
	private String fullOriginalLine; // ~~ Full Original Log Line

	private LocalDateTime localDateTime; // ~~ 'Timestamp' from the log
	private Long localDateTimeMsec; // ~~ 'Timestamp' from the log -- Re-Calculated to mSec

	private String url; // ~~
	private TreeSet userNameCore; // ~~ Truncated userNameFull if it has Version/Thread ID OR '@domain.com' after the name

	///~~ JQL usage counter
	private Long usageCounter; // ~

	///~~ JQL execution time
	private Long executionTimeDataPointMSec; //~~JQL Execution time
	private Long executionTimeMin; //~~ overall MIN JQL Execution time
	private Long executionTimeMax; //~~ overall MIN JQL Execution time

	private Long numberOfClausesInQuery; //~~
	private Long numberOfResults; //~~

	///~~~ Getters/Setters
	public String getKeyJiraQueryLanguageLine() {
		return keyJiraQueryLanguageLine;
	}
	public void setKeyJiraQueryLanguageLine(String keyJiraQueryLanguageLine) {
		this.keyJiraQueryLanguageLine = keyJiraQueryLanguageLine;
	}
	public String getFullOriginalLine() {
		return fullOriginalLine;
	}
	public void setFullOriginalLine(String fullOriginalLine) {
		this.fullOriginalLine = fullOriginalLine;
	}
	public LocalDateTime getLocalDateTime() {
		return localDateTime;
	}
	public void setLocalDateTime(LocalDateTime localDateTime) {
		this.localDateTime = localDateTime;
	}
	public Long getLocalDateTimeMsec() {
		return localDateTimeMsec;
	}
	public void setLocalDateTimeMsec(Long localDateTimeMsec) {
		this.localDateTimeMsec = localDateTimeMsec;
	}

	public Long getExecutionTimeDataPointMSec() {
		return executionTimeDataPointMSec;
	}
	public void setExecutionTimeDataPointMSec(Long executionTimeDataPointMSec) {
		this.executionTimeDataPointMSec = executionTimeDataPointMSec;
	}

	public TreeSet getUserNameCore() {
		return userNameCore;
	}
	public void setUserNameCore(TreeSet userNameCore) {
		this.userNameCore = userNameCore;
	}
	public Long getExecutionTimeMin() {
		return executionTimeMin;
	}
	public void setExecutionTimeMin(Long executionTimeMin) {
		this.executionTimeMin = executionTimeMin;
	}
	public Long getExecutionTimeMax() {
		return executionTimeMax;
	}
	public void setExecutionTimeMax(Long executionTimeMax) {
		this.executionTimeMax = executionTimeMax;
	}
	public Long getUsageCounter() {
		return usageCounter;
	}
	public void setUsageCounter(Long usageCounter) {
		this.usageCounter = usageCounter;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public Long getNumberOfResults() {
		return numberOfResults;
	}
	public void setNumberOfResults(Long numberOfResults) {
		this.numberOfResults = numberOfResults;
	}
	public Long getNumberOfClausesInQuery() {
		return numberOfClausesInQuery;
	}
	public void setNumberOfClausesInQuery(Long numberOfClausesInQuery) {
		this.numberOfClausesInQuery = numberOfClausesInQuery;
	}

}
