package pojo;

import java.time.LocalDateTime;

public class PojoJiraLogRowData {
	private String fullOriginalLine; // ~~ Full Original Log Line
	//private String md5HashKey; // ~~ HashMap Key for distinguish ApiCall+JQL string

	private LocalDateTime localDateTime; // ~~ 'Timestamp' from the log
	private Long localDateTimeMsec; // ~~ 'Timestamp' from the log -- Re-Calculated to mSec

	private String userNameFull; // ~~ 'Username', sometimes full email, e.g.: 'localadmin', 'anonymous', 'username@domail.com'
	private String userNameCore; // ~~ Truncated userNameFull if it has Version/Thread ID OR '@domain.com' after the name 

	private String fromIpAddress; //~~ 'Origin IP' 35.191.2.232
	private String requestID; //~~ 'Request ID' 1165x67177x1
	private String sessionID; //~~ 'Session ID' e.g: {1ok443k}
	private String summary; //~~ the log line tail

	//~~ 'Accessed URL' e.g: {https://jiraupgrade.geotab.com/plugins/servlet/scriptrunner/admin/restendpoints}
	//~~ 'Client utilized' (browser, app) e.g: {Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36}

	////~~~~~~ 'ActingService's' ~~~~~
	///~~ http-nio-8080-exec-
	///~~ https-openssl-nio-443-exec-
	///~~ automation-rule-executor:thread-
	///~~ Caesium-
	///~~ Sending mailitem com.atlassian.jira.mail.SubscriptionSingleRecepientMailQueueItem
	private String actingServiceFull; // ~~ Acting Service, e.g.: 'localhost-startStop-1', or 'https-openssl-nio-443-exec-13'
	private String actingServiceCore; // ~~ Acting Service, e.g.: 'localhost-startStop'
	private String httpRequestApiCallFull; // ~~ 'Method & EndPoint' e.g:  {GET diagnostics/results?functionId=GET-vep HTTP/1.1} -- REST API call custom end-point
	private String httpRequestApiCallCore; // ~~ 'Method & EndPoint' {/rest/api/diagnostics/results/}
	private String jqlLuceneQueryOrHtmlParam; // ~~ 'Method & EndPoint' part after '?' ~~ JQL LuceneQuery Query, or HTML request parameters after '?' {?functionId=GET-vep }
	private String requestMethod; // 'Method & EndPoint' [POST, GET, etc.]
	private String httpMethodAndEndPoint; //~ e.g.: 'HTTP/1.1' -- 'Method & EndPoint' -- Hypertext Transfer Protocol
	private int httpResponseStatusCode; //~~ 'HTTP status code' [2xx, 3xx, 4xx, 5xx - Client, Server Errors] {200, 400, 404. etc}

	///~~ web requests
	private Long eventsCountDataPoint; // ~~ Always == 1, unless we have two or more log entries with exact timestamps (e.g. 2023-03-27 00:34:27,153-0400) happened to be used in the jira log more than once, count extra time use only (for duplicate will be == 1)   
	private Long eventsCountPerChartTick; // ~~ 'Events (log entries)'  -- Compressed for chart -- Sum of all per time Grid tick (e.g. all per 1hr)
	private Long eventsCountPerDayPerRank; // ~~ 'Events (log entries)'  -- Compressed for chart -- Sum of all per time Grid tick (e.g. all per 1hr)
	private Long eventsCountPerDayAllRanks; // ~~ 'Bytes sent' -- Sum per Day (all ranks, overall use of Jira by all accounts)
	private Long eventsCountMaxPerDayAllRanks; // ~~ 'Bytes sent' MAX per all ranks in a day (Overall MAX JPLB / Jira Peak Load bytes - the highest amount of Jira resources that all consumers draws from the Jira App in a day)
	private Long eventsCountAllowedPerDayForUser; //~~ Scheduled User's bandwidth cap, is an artificial restriction imposed on the transfer of data over a network.
	///~~Also:  "chartThresholdEvents": 10000

	///~~ http bytes sent
	private Long bytesSentDataPoint; // ~~ 'Bytes sent' -- per log entry / datapoint
	private Long bytesSentPerChartTick; // ~~ 'Bytes sent' -- Compressed for chart -- Sum of all per time Grid tick (e.g. all per 1hr)
	private Long bytesSentPerDayPerRank; // ~~ 'Bytes sent' -- Sum per user account rank
	private Long bytesSentPerDayAllRanks; // ~~ 'Bytes sent' -- Sum per Day (all ranks, overall use of Jira by all accounts)
	private Long bytesSentMaxPerDayAllRanks; // ~~ 'Bytes sent' MAX per all ranks in a day (Overall MAX JPLB / Jira Peak Load bytes - the highest amount of Jira resources that all consumers draws from the Jira App in a day)
	private Long bytesSentAllowedPerDayForUser; //~~ Scheduled User's bandwidth cap, is an artificial restriction imposed on the transfer of data over a network.
	///~~Also:  "chartThresholdBytesSent": 10000000

	///~~ http execution time
	private Long executionTimeDataPointMSec; //~~'Time Taken to process the request in�millis'
	private Long executionTimePerChartTickMSec; //~~ Compressed for chart -- Sum of all per time Grid tick (e.g. all per 1hr)
	private Long executionTimePerDayPerRankMSec; //~~Sum of all events per User/Account Rank execution time 'Time Taken to process the request in milliSec'
	private Long executionTimePerDayAllRanksMSec; // ~~ 'http execution Time' -- Sum per Day (all ranks, overall use of Jira by all accounts)
	private Long executionTimeMaxPerDayAllRanksMSec; // ~~ MAX/Peak http execution Time per all ranks in a day (JPLT Jira Peak Load execution Time)
	private Long executionTimeAllowedPerDayForUserMSec; //~~ Scheduled User's http execution time bandwidth cap, is an artificial restriction imposed on use of server application connection time
	///~~Also:  "chartThresholdExecutionTimesSec": 1800

	///~~ Scheduled time frame for the account
	private LocalDateTime userAccountFirstEventThisDay; //~~ To hold a chronologically first event for this account at this day.
	private LocalDateTime userAccountLastEventThisDay; // ~~ To hold a chronologically last event for this account at this day. May be tricky, will hold time of all events, than calculate the last one
	private LocalDateTime userAccountJiraUseScheduledDailyFrom; //~~ Scheduled Time frame when account allowed to execute start
	private LocalDateTime userAccountJiraUseScheduledDailyTo; //~~ Scheduled Time frame when account allowed to execute end

	private String severityLevel; // ~~ Column 3: EnumSeverity: TRACE, DEBUG, INFO, WARN, ERROR, FATAL. There is no 'SEVERE' level
	private String severityGraphChar; // ~~ Added to show on Chart: t, d, i. w, e, f

	//~~Slow query log ~~
	private String searchProvider; // [c.a.j.i.search.providers.LuceneSearchProvider_SLOW]
	private Long numberOfClausesInQuery; // numberOfClausesInQuery=2
	// private Long executionTime; // executionTime=1552 (saved in parameter 'executionTimeDataPointMSec' see above)
	private Long numberOfResults; // numberOfResults=4
	private String collectorType; // collectorType='TopDocs'

	//~~
	private String sourceLogFileName;
	private int logKind; // ~~ JiraLog(1), AccessLog(2), SlowQuery(3), CatalinaLog(4), EMailInLog(5), EMailOutLog(6);
	// ~~ Extra calculated:
	private String keyUserReportKindSeverity; // ~Note, elements of the key may vary. Concatenated: jiraLogRow.setKeyUserReportKindSeverity(jiraLogRow.getUserNameCore() + "<" + EntryPoint.EnumReportKind.SlowQuery.toString() + ">" + severityLevel);
	private int counter; // ~~ case 1: count similar errors
	//private int countEventsPerRank; // ~~ Counter to keep number of the events in the one Rank. 

	// ~~ Getters / Setters ~~

	public String getFullOriginalLine() {
		return fullOriginalLine;
	}

	public void setFullOriginalLine(String fullOriginalLine) {
		this.fullOriginalLine = fullOriginalLine;
	}

	public LocalDateTime getLocalDateTime() {
		return localDateTime;
	}

	public void setLocalDateTime(LocalDateTime localDateTime) {
		this.localDateTime = localDateTime;
	}

	public Long getLocalDateTimeMsec() {
		return localDateTimeMsec;
	}

	public void setLocalDateTimeMsec(Long localDateTimeMsec) {
		this.localDateTimeMsec = localDateTimeMsec;
	}

	public Long getEventsCountDataPoint() {
		return eventsCountDataPoint;
	}

	public void setEventsCountDataPoint(Long thisTimeStampRepeatedCounter) {
		this.eventsCountDataPoint = thisTimeStampRepeatedCounter;
	}

	public String getUserNameFull() {
		return userNameFull;
	}

	public void setUserNameFull(String userNameFull) {
		this.userNameFull = userNameFull;
	}

	public String getUserNameCore() {
		return userNameCore;
	}

	public void setUserNameCore(String userNameCore) {
		this.userNameCore = userNameCore;
	}

	public String getFromIpAddress() {
		return fromIpAddress;
	}

	public void setFromIpAddress(String fromIpAddress) {
		this.fromIpAddress = fromIpAddress;
	}

	public String getRequestID() {
		return requestID;
	}

	public void setRequestID(String requestID) {
		this.requestID = requestID;
	}

	public String getRequestMethod() {
		return requestMethod;
	}

	public void setRequestMethod(String requestMethod) {
		this.requestMethod = requestMethod;
	}

	public String getHttpRequestApiCallFull() {
		return httpRequestApiCallFull;
	}

	public void setHttpRequestApiCallFull(String httpRequestApiCallFull) {
		this.httpRequestApiCallFull = httpRequestApiCallFull;
	}

	public String getHttpRequestApiCallCore() {
		return httpRequestApiCallCore;
	}

	public void setHttpRequestApiCallCore(String httpRequestApiCallCore) {
		this.httpRequestApiCallCore = httpRequestApiCallCore;
	}

	public String getJqlLuceneQueryOrHtmlParam() {
		return jqlLuceneQueryOrHtmlParam;
	}

	public void setJqlLuceneQueryOrHtmlParam(String jqlLuceneQueryOrHtmlParam) {
		this.jqlLuceneQueryOrHtmlParam = jqlLuceneQueryOrHtmlParam;
	}

	public String getHttpMethodAndEndPoint() {
		return httpMethodAndEndPoint;
	}

	public void setHttpMethodAndEndPoint(String httpMethodAndEndPoint) {
		this.httpMethodAndEndPoint = httpMethodAndEndPoint;
	}

	public int getHttpResponseStatusCode() {
		return httpResponseStatusCode;
	}

	public void setHttpResponseStatusCode(int httpResponseStatusCode) {
		this.httpResponseStatusCode = httpResponseStatusCode;
	}

	public Long getEventsCountPerChartTick() {
		return eventsCountPerChartTick;
	}

	public void setEventsCountPerChartTick(Long eventsCountPerChartTick) {
		this.eventsCountPerChartTick = eventsCountPerChartTick;
	}

	public Long getBytesSentDataPoint() {
		return bytesSentDataPoint;
	}

	public void setBytesSentDataPoint(Long bytesSentDataPoint) {
		this.bytesSentDataPoint = bytesSentDataPoint;
	}

	public Long getBytesSentPerDayPerRank() {
		return bytesSentPerDayPerRank;
	}

	public void setBytesSentPerDayPerRank(Long bytesSentPerDayPerRank) {
		this.bytesSentPerDayPerRank = bytesSentPerDayPerRank;
	}

	public Long getBytesSentPerDayAllRanks() {
		return bytesSentPerDayAllRanks;
	}

	public void setBytesSentPerDayAllRanks(Long bytesSentPerDayAllRanks) {
		this.bytesSentPerDayAllRanks = bytesSentPerDayAllRanks;
	}

	public Long getBytesSentMaxPerDayAllRanks() {
		return bytesSentMaxPerDayAllRanks;
	}

	public void setBytesSentMaxPerDayAllRanks(Long bytesSentMaxPerDayAllRanks) {
		this.bytesSentMaxPerDayAllRanks = bytesSentMaxPerDayAllRanks;
	}

	public Long getBytesSentAllowedPerDayForUser() {
		return bytesSentAllowedPerDayForUser;
	}

	public void setBytesSentAllowedPerDayForUser(Long bytesSentAllowedPerDayForUser) {
		this.bytesSentAllowedPerDayForUser = bytesSentAllowedPerDayForUser;
	}

	public Long getExecutionTimeDataPointMSec() {
		return executionTimeDataPointMSec;
	}

	public void setExecutionTimeDataPointMSec(Long executionTimeDataPointMSec) {
		this.executionTimeDataPointMSec = executionTimeDataPointMSec;
	}

	public Long getExecutionTimePerChartTickMSec() {
		return executionTimePerChartTickMSec;
	}

	public void setExecutionTimePerChartTickMSec(Long executionTimePerChartTickMSec) {
		this.executionTimePerChartTickMSec = executionTimePerChartTickMSec;
	}

	public Long getExecutionTimePerDayPerRankMSec() {
		return executionTimePerDayPerRankMSec;
	}

	public void setExecutionTimePerDayPerRankMSec(Long executionTimePerDayPerRankMSec) {
		this.executionTimePerDayPerRankMSec = executionTimePerDayPerRankMSec;
	}

	public Long getExecutionTimePerDayAllRanksMSec() {
		return executionTimePerDayAllRanksMSec;
	}

	public void setExecutionTimePerDayAllRanksMSec(Long executionTimePerDayAllRanksMSec) {
		this.executionTimePerDayAllRanksMSec = executionTimePerDayAllRanksMSec;
	}

	public Long getExecutionTimeMaxPerDayAllRanksMSec() {
		return executionTimeMaxPerDayAllRanksMSec;
	}

	public void setExecutionTimeMaxPerDayAllRanksMSec(Long executionTimeMaxPerDayAllRanksMSec) {
		this.executionTimeMaxPerDayAllRanksMSec = executionTimeMaxPerDayAllRanksMSec;
	}

	public Long getExecutionTimeAllowedPerDayForUserMSec() {
		return executionTimeAllowedPerDayForUserMSec;
	}

	public void setExecutionTimeAllowedPerDayForUserMSec(Long executionTimeAllowedPerDayForUserMSec) {
		this.executionTimeAllowedPerDayForUserMSec = executionTimeAllowedPerDayForUserMSec;
	}

	public LocalDateTime getUserAccountFirstEventThisDay() {
		return userAccountFirstEventThisDay;
	}

	public void setUserAccountFirstEventThisDay(LocalDateTime userAccountFirstEventThisDay) {
		this.userAccountFirstEventThisDay = userAccountFirstEventThisDay;
	}

	public LocalDateTime getUserAccountLastEventThisDay() {
		return userAccountLastEventThisDay;
	}

	public void setUserAccountLastEventThisDay(LocalDateTime userAccountLastEventThisDay) {
		this.userAccountLastEventThisDay = userAccountLastEventThisDay;
	}

	public LocalDateTime getUserAccountJiraUseScheduledDailyFrom() {
		return userAccountJiraUseScheduledDailyFrom;
	}

	public void setUserAccountJiraUseScheduledDailyFrom(LocalDateTime userAccountJiraUseScheduledDailyFrom) {
		this.userAccountJiraUseScheduledDailyFrom = userAccountJiraUseScheduledDailyFrom;
	}

	public LocalDateTime getUserAccountJiraUseScheduledDailyTo() {
		return userAccountJiraUseScheduledDailyTo;
	}

	public void setUserAccountJiraUseScheduledDailyTo(LocalDateTime userAccountJiraUseScheduledDailyTo) {
		this.userAccountJiraUseScheduledDailyTo = userAccountJiraUseScheduledDailyTo;
	}

	public String getActingServiceFull() {
		return actingServiceFull;
	}

	public void setActingServiceFull(String actingServiceFull) {
		this.actingServiceFull = actingServiceFull;
	}

	public String getActingServiceCore() {
		return actingServiceCore;
	}

	public void setActingServiceCore(String actingServiceCore) {
		this.actingServiceCore = actingServiceCore;
	}

	public String getSeverityLevel() {
		return severityLevel;
	}

	public void setSeverityLevel(String severityLevel) {
		this.severityLevel = severityLevel;
	}

	public String getSeverityGraphChar() {
		return severityGraphChar;
	}

	public void setSeverityGraphChar(String severityGraphChar) {
		this.severityGraphChar = severityGraphChar;
	}

	public String getSearchProvider() {
		return searchProvider;
	}

	public void setSearchProvider(String searchProvider) {
		this.searchProvider = searchProvider;
	}

	public Long getNumberOfResults() {
		return numberOfResults;
	}

	public void setNumberOfResults(Long numberOfResults) {
		this.numberOfResults = numberOfResults;
	}

	public String getCollectorType() {
		return collectorType;
	}

	public void setCollectorType(String collectorType) {
		this.collectorType = collectorType;
	}

	public String getSourceLogFileName() {
		return sourceLogFileName;
	}

	public void setSourceLogFileName(String sourceLogFileName) {
		this.sourceLogFileName = sourceLogFileName;
	}

	public int getLogKind() {
		return logKind;
	}

	public void setLogKind(int logKind) {
		this.logKind = logKind;
	}

	public String getKeyUserReportKindSeverity() {
		return keyUserReportKindSeverity;
	}

	public void setKeyUserReportKindSeverity(String keyUserReportKindSeverity) {
		this.keyUserReportKindSeverity = keyUserReportKindSeverity;
	}

	public int getCounter() {
		return counter;
	}

	public void setCounter(int counter) {
		this.counter = counter;
	}

	public Long getBytesSentPerChartTick() {
		return bytesSentPerChartTick;
	}

	public void setBytesSentPerChartTick(Long bytesSentPerChartTick) {
		this.bytesSentPerChartTick = bytesSentPerChartTick;
	}

	public Long getEventsCountPerDayPerRank() {
		return eventsCountPerDayPerRank;
	}

	public void setEventsCountPerDayPerRank(Long eventsCountPerDayPerRank) {
		this.eventsCountPerDayPerRank = eventsCountPerDayPerRank;
	}

	public Long getEventsCountPerDayAllRanks() {
		return eventsCountPerDayAllRanks;
	}

	public void setEventsCountPerDayAllRanks(Long eventsCountPerDayAllRanks) {
		this.eventsCountPerDayAllRanks = eventsCountPerDayAllRanks;
	}

	public Long getEventsCountMaxPerDayAllRanks() {
		return eventsCountMaxPerDayAllRanks;
	}

	public void setEventsCountMaxPerDayAllRanks(Long eventsCountMaxPerDayAllRanks) {
		this.eventsCountMaxPerDayAllRanks = eventsCountMaxPerDayAllRanks;
	}

	public Long getEventsCountAllowedPerDayForUser() {
		return eventsCountAllowedPerDayForUser;
	}

	public void setEventsCountAllowedPerDayForUser(Long eventsCountAllowedPerDayForUser) {
		this.eventsCountAllowedPerDayForUser = eventsCountAllowedPerDayForUser;
	}

	public Long getNumberOfClausesInQuery() {
		return numberOfClausesInQuery;
	}

	public void setNumberOfClausesInQuery(Long numberOfClausesInQuery) {
		this.numberOfClausesInQuery = numberOfClausesInQuery;
	}

	public String getSessionID() {
		return sessionID;
	}

	public void setSessionID(String sessionID) {
		this.sessionID = sessionID;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

}
