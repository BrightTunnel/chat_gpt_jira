package pojo;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import java.util.Properties;

import jiraPojoObjects.PojoSearchRequest;
import jira_log_analyzer.EpLogAnalyzer;
import jira_log_analyzer.UtilsLogsSys;

public class ModelJiraDBase {

	UtilsLogsSys utilsLogsSys = new UtilsLogsSys();
	
	public ModelJiraDBase(EpLogAnalyzer ep) {
		this.ep = ep;
	}
	private EpLogAnalyzer ep;

	public void sqlSelectSearchrequest() {
		//~~Save to the file 'jql_list.tsv' list of all JQLs
		// String url = "jdbc:postgresql://localhost:5432/jira?user=postgres&password=secret&ssl=true";
		// String url = "jdbc:postgresql://localhost:5432/jira";
		String url = EpLogAnalyzer.SysSetngs.getDbDriver() + EpLogAnalyzer.SysSetngs.getDbHost() + ":" + EpLogAnalyzer.SysSetngs.getDbPortNumber() + "/" + EpLogAnalyzer.SysSetngs.getDbName();
		Properties props = new Properties();
		props.setProperty("user", EpLogAnalyzer.SysSetngs.getDbUsername()); // "postgres"
		props.setProperty("password", EpLogAnalyzer.SysSetngs.getDbPassword()); // "amp"
		props.setProperty("ssl", EpLogAnalyzer.SysSetngs.isDbEnableSsl() ? "true" : "false"); // "false"
		Connection conn = null;
		String _srr = "\t";
		try {
			conn = DriverManager.getConnection(url, props);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		String sql = "SELECT sr.id, sr.filtername, sr.reqcontent, sr.authorname, sr.username FROM searchrequest sr";
		PreparedStatement st;
		PojoSearchRequest _sr;
		if (conn != null) {
			try {
				st = conn.prepareStatement(sql);
				ResultSet rs = st.executeQuery();
				// System.out.println("table_name,column_name,data_type,character_maximum_length,is_nullable,vendor");
				while (rs.next()) {
					_sr = new PojoSearchRequest();
					_sr.setId(Long.parseLong(rs.getString(1)));
					_sr.setFiltername(rs.getString(2));
					_sr.setReqcontent(rs.getString(3));
					_sr.setAuthorname(rs.getString(4));
					_sr.setUsername(rs.getString(5));
					ep.DictJiraDbTableSearchRequest.put(_sr.getId() + "", _sr);
				}
				rs.close();
				st.close();
				String header = "name" + _srr + "content" + _srr + "description" + _srr + "author" + _srr + "user" + _srr + "group" + _srr + "project" + _srr + "count\r";
				FileOutputStream outputStream;
				String str;
				try {
					outputStream = new FileOutputStream(EpLogAnalyzer.SysSetngs.getOutDirReports() + "/jql_list.tsv");
					byte[] strToBytes = header.getBytes();
					outputStream.write(strToBytes);
					for (Map.Entry<String, PojoSearchRequest> entry : ep.DictJiraDbTableSearchRequest.entrySet()) { // entry.getKey()
						str = entry.getValue().getFiltername() + _srr + utilsLogsSys.sanitizeString(entry.getValue().getReqcontent()) + _srr + entry.getValue().getDescription() + _srr + entry.getValue().getAuthorname() + _srr + entry.getValue().getUsername() + _srr + entry.getValue().getGroupname() + _srr + entry.getValue().getProjectid() + _srr + entry.getValue().getFav_count() + "\r";
						strToBytes = str.getBytes();
						outputStream.write(strToBytes);
						// System.out.println(entry.getValue().getTable_name() + "," + entry.getValue().getColumn_name() + "," + entry.getValue().getData_type() + "," +
						// entry.getValue().getIs_nullable() +
						// "," + entry.getValue().getCharacter_maximum_length() + "," +
						// entry.getValue().getAoGroupTableVendor());
					}
					outputStream.close();
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
