package pojo;

public class PojoLuceneQueryExecutionEvent {

	///~	LuceneQueryExecutionEvent{query={project = "BUS"} order by created ASC,
	///~		queryTermMetrics={
	///~			org.apache.lucene.search.TermInSetQuery=TermMetric{count=2, isCustomField=false},
	///~			issue_assignee:JIRAUSER15959=TermMetric{count=1, isCustomField=false},
	///~			projid:12604=TermMetric{count=2, isCustomField=false}
	///~		},
	///~		numberOfClausesInQuery=5,
	///~		executionTime=2958,
	///~		numberOfResults=31,
	///~		collectorType='TopDocs'
	///~	}

	private String luceneQuery; // 'query={project = "BUS"} order by created ASC,'
	private Long luceneNumberOfClausesInQuery; // 'numberOfClausesInQuery=5,'
	private Long luceneExecutionTime; // 'executionTime=2958,'
	private Long luceneNumberOfResults; // 'numberOfResults=31,'
	private String luceneCollectorType; // 'collectorType='TopDocs''

	///~ getters and setters
	public String getLuceneQuery() {
		return luceneQuery;
	}
	public void setLuceneQuery(String luceneQuery) {
		this.luceneQuery = luceneQuery;
	}
	public Long getLuceneNumberOfClausesInQuery() {
		return luceneNumberOfClausesInQuery;
	}
	public void setLuceneNumberOfClausesInQuery(Long luceneNumberOfClausesInQuery) {
		this.luceneNumberOfClausesInQuery = luceneNumberOfClausesInQuery;
	}
	public Long getLuceneExecutionTime() {
		return luceneExecutionTime;
	}
	public void setLuceneExecutionTime(Long luceneExecutionTime) {
		this.luceneExecutionTime = luceneExecutionTime;
	}
	public Long getLuceneNumberOfResults() {
		return luceneNumberOfResults;
	}
	public void setLuceneNumberOfResults(Long luceneNumberOfResults) {
		this.luceneNumberOfResults = luceneNumberOfResults;
	}
	public String getLuceneCollectorType() {
		return luceneCollectorType;
	}
	public void setLuceneCollectorType(String luceneCollectorType) {
		this.luceneCollectorType = luceneCollectorType;
	}

}
