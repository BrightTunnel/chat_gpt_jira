package reports;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.TreeMap;

import jira_log_analyzer.EpLogAnalyzer.EnumReportKind;
import jira_log_analyzer.EpLogAnalyzer.EnumSeverity;
import jira_log_analyzer.UtilsLogsParsing;
import pojo.PojoJiraLogRowData;
import pojo.PojoJsonSystemSettingsFile;

public class Reports {

	UtilsLogsParsing utilsLogsParsing = new UtilsLogsParsing();

	public void saveAllCollectedDataReport(TreeMap<Long, TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>> aDictGroupByDateType, PojoJsonSystemSettingsFile aSSet, String aFilePrefixDate) {
		if (aDictGroupByDateType != null && aDictGroupByDateType.size() > 0) {
			DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			final StringBuilder content = new StringBuilder("");
			content.append("DateTime\tRankKey\tUserName\tUserEmail\tEventsCountr\tRankUsedMin\tRankKBytes\tQuery\tCollectorType\tSearchProvider\tOrigLine\r"); //~~ Header
			Iterator<Entry<Long, TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>>> rankIter = aDictGroupByDateType.entrySet().iterator();
			while (rankIter.hasNext()) {
				Entry<Long, TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>> _rankKeyValue = rankIter.next();
				Iterator<Entry<String, TreeMap<Long, PojoJiraLogRowData>>> _usersIter = _rankKeyValue.getValue().entrySet().iterator();
				while (_usersIter.hasNext()) {
					Entry<String, TreeMap<Long, PojoJiraLogRowData>> _userKeyValue = _usersIter.next();
					TreeMap<Long, PojoJiraLogRowData> _rankData = _userKeyValue.getValue();
					Long _bytesSentPerDayPerRank = _userKeyValue.getValue().firstEntry().getValue().getBytesSentPerDayPerRank();
					if (_bytesSentPerDayPerRank == null) {
						_bytesSentPerDayPerRank = 0L;
					}
					Iterator<Entry<Long, PojoJiraLogRowData>> _itemsKeyValue = _rankData.entrySet().iterator();
					while (_itemsKeyValue.hasNext()) { // ~~ Iterate all log entries in a Rank
						Entry<Long, PojoJiraLogRowData> _itemKeyValue = _itemsKeyValue.next();
						PojoJiraLogRowData vlue = _itemKeyValue.getValue();
						String reportLine = "";
						reportLine += vlue.getLocalDateTime().format(dateTimeFormatter) + "\t";
						reportLine += vlue.getKeyUserReportKindSeverity() + "\t";
						reportLine += vlue.getUserNameCore() + "\t";
						reportLine += vlue.getUserNameFull() + "\t";
						reportLine += vlue.getCounter() + "\t"; //~~ Events Per Rank counter 
						// reportLine += vlue.getExecutionTimeMilliSec() / 1000 + "\t";
						//reportLine += vlue.getExecutionTimeSumPerRankMilliSec() / 1000 / 60 + "\t";
						// reportLine += vlue.getBytesSent() + "\t";
						reportLine += _bytesSentPerDayPerRank / 1024 + "\t";
						reportLine += vlue.getJqlLuceneQueryOrHtmlParam() + "\t";
						if (vlue.getCollectorType() != null) {
							reportLine += vlue.getCollectorType() + "\t";
						} else {
							reportLine += "\t";
						}
						if (vlue.getSearchProvider() != null) {
							reportLine += vlue.getSearchProvider() + "\t";
						} else {
							reportLine += "\t";
						}
						reportLine += vlue.getFullOriginalLine() + "\n";
						content.append(reportLine);
					}
				}
			}
			String path = aSSet.getOutDirReports() + "/" + aFilePrefixDate + " All errors.csv";
			try {
				Files.write(Paths.get(path), content.toString().getBytes());
			} catch (IOException e) {
				e.printStackTrace();
			}
			System.out.println("Report tsv file saved to: '" + path + "'");
		}
	}

	public void saveReportLogCombined(TreeMap<Long, TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>> aDictGroupByDateType, PojoJsonSystemSettingsFile aSSet, String aFilePrefixDate) {
		//~~ Count exact errors (All unique errors will be compressed in one string in the report)
		System.out.println("Do: SaveReportLogCombined");
		if (aDictGroupByDateType != null && aDictGroupByDateType.size() > 0) {
			// ~~ Collect records containing ERRORs 
			TreeMap<String, PojoJiraLogRowData> _tm = new TreeMap<String, PojoJiraLogRowData>();
			final StringBuilder content = new StringBuilder("");
			Long _httpBytesSentSumPerRank = 0L;
			Long _httpExecutionTimeSumPerRank = 0L;
			Iterator<Entry<Long, TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>>> rankIter = aDictGroupByDateType.entrySet().iterator();
			while (rankIter.hasNext()) {
				Entry<Long, TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>> _rankKeyValue = rankIter.next();
				Iterator<Entry<String, TreeMap<Long, PojoJiraLogRowData>>> _usersIter = _rankKeyValue.getValue().entrySet().iterator();
				while (_usersIter.hasNext()) {
					Entry<String, TreeMap<Long, PojoJiraLogRowData>> _userKeyValue = _usersIter.next();
					_httpBytesSentSumPerRank = _userKeyValue.getValue().firstEntry().getValue().getBytesSentPerDayAllRanks();
					_httpExecutionTimeSumPerRank = _userKeyValue.getValue().firstEntry().getValue().getExecutionTimePerDayAllRanksMSec();
					TreeMap<Long, PojoJiraLogRowData> _rankData = _userKeyValue.getValue();
					Iterator<Entry<Long, PojoJiraLogRowData>> _itemsKeyValue = _rankData.entrySet().iterator();
					int countEventsPerRank = 0;
					while (_itemsKeyValue.hasNext()) { // ~~ Iterate all log entries in a Rank
						Entry<Long, PojoJiraLogRowData> _itemKeyValue = _itemsKeyValue.next();
						PojoJiraLogRowData _itemValue = _itemKeyValue.getValue();
						if (_itemValue != null) {
							if (true || aSSet.isReportAllAccessLogRecordsNotErrorsOnly() || utilsLogsParsing.ifSeverityLevelIsAnError(_itemValue.getSeverityLevel())) {
								//_tm.put(_itemValue.getLocalDateTimeMsec(), _itemValue);
								// System.err.println("~~ctr: " + countEventsPerRank);
								if (!_tm.containsKey(_itemValue.getKeyUserReportKindSeverity())) {
									_tm.put(_itemValue.getKeyUserReportKindSeverity(), _itemValue);
								}
								_tm.get(_itemValue.getKeyUserReportKindSeverity()).setCounter(++countEventsPerRank); // ~~ Save latest Events Per the Rank counter  
								// content.append(_itemValue.getFullOriginalLine());
								// content.append("\r");
							}
						}
					}
				}
				// content.append("\r");
			}
			// ~~ Collect records containing ERRORs ~~
			DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			content.append("DateTime\tRankKey\tUserName\tUserEmail\tEventsCountr\tRankUsedMin\tRankKBytes\tQuery\tCollectorType\tSearchProvider\tOrigLine\r"); //~~ Header
			if (_httpBytesSentSumPerRank == null) {
				_httpBytesSentSumPerRank = 0L;
			}
			if (_httpExecutionTimeSumPerRank == null) {
				_httpExecutionTimeSumPerRank = 0L;
			}
			final Long _httpBytesSentSumPerRankFinal = _httpBytesSentSumPerRank;
			final Long _httpExecutionTimeSumPerRankFinal = _httpExecutionTimeSumPerRank;
			_tm.forEach((k, vlue) -> {
				if (true) { // TODO
					//~~ System.err.println("~~time: " + vlue.getExecutionTime() / 1000 + " > " + aSSet.getRankThresholdExecutionTimesSec());
					if (vlue.getCounter() >= aSSet.getRankThresholdEvents() //
							|| vlue.getBytesSentPerDayPerRank() >= aSSet.getRankThresholdBytesSent() //
							|| (vlue.getExecutionTimePerDayPerRankMSec() / 1000.0) >= aSSet.getRankThresholdExecutionTimesSec() //
					) {
						//System.err.println("   ~~let it " + v.getExecutionTime());
						String reportLine = "";
						reportLine += vlue.getLocalDateTime().format(dateTimeFormatter) + "\t";
						reportLine += vlue.getKeyUserReportKindSeverity() + "\t";
						reportLine += vlue.getUserNameCore() + "\t";
						reportLine += vlue.getUserNameFull() + "\t";
						reportLine += vlue.getCounter() + "\t"; //~~ Events Per Rank counter 
						// reportLine += vlue.getExecutionTimeMilliSec() / 1000 + "\t";
						reportLine += vlue.getExecutionTimePerDayPerRankMSec() / 1000 / 60 + "\t";
						// reportLine += vlue.getBytesSent() + "\t";
						reportLine += _httpBytesSentSumPerRankFinal / 1024 + "\t";
						reportLine += _httpExecutionTimeSumPerRankFinal + "\t";
						reportLine += vlue.getJqlLuceneQueryOrHtmlParam() + "\t";
						if (vlue.getCollectorType() != null) {
							reportLine += vlue.getCollectorType() + "\t";
						} else {
							reportLine += "\t";
						}
						if (vlue.getSearchProvider() != null) {
							reportLine += vlue.getSearchProvider() + "\t";
						} else {
							reportLine += "\t";
						}
						reportLine += vlue.getFullOriginalLine() + "\n";
						content.append(reportLine);
					} else {
						//System.err.println("   ~~cut off" + vlue.getExecutionTime());
					}
				} else {
					if (vlue.getLogKind() == EnumReportKind.JiraLog.getRepKindCode()) {
						if (utilsLogsParsing.ifSeverityLevelIsAnError(vlue.getSeverityLevel())) {
							content.append(vlue.getLocalDateTime().format(dateTimeFormatter) + "\t" + vlue.getKeyUserReportKindSeverity() + "\t" + vlue.getUserNameCore() + "\t" + vlue.getUserNameFull() + "\t\t\t\t\t\t" + vlue.getFullOriginalLine() + "\r");
						}
					}
					if (vlue.getLogKind() == EnumReportKind.SlowQuery.getRepKindCode()) {
						content.append(vlue.getLocalDateTime().format(dateTimeFormatter) + "\t" + vlue.getKeyUserReportKindSeverity() + "\t" + vlue.getUserNameCore() + "\t" + vlue.getUserNameFull() + "\t" + vlue.getExecutionTimeDataPointMSec() + "\t" + vlue.getNumberOfResults() + "\t" + vlue.getCollectorType() + "\t" + vlue.getSearchProvider() + "\t" + vlue.getJqlLuceneQueryOrHtmlParam() + "\t" + vlue.getFullOriginalLine() + "\r");
					}
					if (vlue.getLogKind() == EnumReportKind.AccessLog.getRepKindCode()) {
						if (utilsLogsParsing.ifSeverityLevelIsAnError(vlue.getSeverityLevel())) {
							content.append(vlue.getLocalDateTime().format(dateTimeFormatter) + "\t" + vlue.getKeyUserReportKindSeverity() + "\t" + vlue.getUserNameCore() + "\t" + vlue.getUserNameFull() + "\t\t\t\t\t\t" + vlue.getFullOriginalLine() + "\r");
						}
					}
					if (vlue.getLogKind() == EnumReportKind.CatalinaLog.getRepKindCode()) {
						if (utilsLogsParsing.ifSeverityLevelIsAnError(vlue.getSeverityLevel())) {
							content.append(vlue.getLocalDateTime().format(dateTimeFormatter) + "\t" + vlue.getKeyUserReportKindSeverity() + "\t" + vlue.getUserNameCore() + "\t" + vlue.getUserNameFull() + "\t\t\t\t\t\t" + vlue.getFullOriginalLine() + "\r");
						}
					}
				}
			});
			String path = aSSet.getOutDirReports() + "/" + aFilePrefixDate + " All errors.csv";
			try {
				Files.write(Paths.get(path), content.toString().getBytes());
			} catch (IOException e) {
				e.printStackTrace();
			}
			System.out.println("Report tsv file saved to: '" + path + "'");
		}
	}

	public void saveReportErrorsStat(TreeMap<String, TreeMap<Long, TreeMap<Long, PojoJiraLogRowData>>> aDictGroupByDateType, PojoJsonSystemSettingsFile aSSet, String aFilePrefixDate) {
		System.out.println("Do: SaveReportErrorsStat");
		// ~~ Key: Error key (type, target); Key counter; Value 
		TreeMap<String, PojoJiraLogRowData> GroupBySpecificErrors = new TreeMap<String, PojoJiraLogRowData>();
		TreeMap<String, PojoJiraLogRowData> OrderByErrorsCount = new TreeMap<String, PojoJiraLogRowData>();
		PojoJiraLogRowData _item = null;
		int maxCntr = 0;
		final StringBuilder content = new StringBuilder("");
		// ~~ GroupErrors By Specific Error Type ~~
		Iterator<Entry<String, TreeMap<Long, TreeMap<Long, PojoJiraLogRowData>>>> iterRank0 = aDictGroupByDateType.entrySet().iterator();
		while (iterRank0.hasNext()) {
			Entry<String, TreeMap<Long, TreeMap<Long, PojoJiraLogRowData>>> rank0 = iterRank0.next();
			EnumSeverity _enumSeverity = getSeverityLevelFromString(rank0.getKey());
			boolean _severityError = false;
			if (_enumSeverity != null) {
				_severityError = utilsLogsParsing.ifSeverityLevelIsAnError(_enumSeverity.toString());
			}
			if (aSSet.isReportAllAccessLogRecordsNotErrorsOnly() || _severityError) {
				// ~~ Iterate all days ~~
				Iterator<Entry<Long, TreeMap<Long, PojoJiraLogRowData>>> iterRank1 = rank0.getValue().entrySet().iterator();
				while (iterRank1.hasNext()) {
					Entry<Long, TreeMap<Long, PojoJiraLogRowData>> rank1 = iterRank1.next();
					// ~~ Iterate all entries
					Iterator<Entry<Long, PojoJiraLogRowData>> iterRank2 = rank1.getValue().entrySet().iterator();
					while (iterRank2.hasNext()) {
						Entry<Long, PojoJiraLogRowData> rank2 = iterRank2.next();
						_item = rank2.getValue();
						if (_item != null) {
							String _key = "";
							switch (aSSet.getGroupMessagesOption()) {
								// ~~ _item.getUserNameCore() + ", " + _item.getActingServiceCore() + ", " + _item.getHttpResponseStatusCode()
								case 1 :
									_key = "{" + _item.getHttpRequestApiCallCore() + "}"; // 
									break;
								case 2 :
									_key = "{" + _item.getHttpRequestApiCallCore() + ", " + _item.getUserNameCore() + "}";
									break;
							}
							if (GroupBySpecificErrors.containsKey(_key)) {
								int ctr = GroupBySpecificErrors.get(_key).getCounter();
								GroupBySpecificErrors.get(_key).setCounter(ctr + 1);
								if (maxCntr < ctr + 1) {
									maxCntr = ctr + 1;
								}
							} else {
								GroupBySpecificErrors.put(_key, _item);
							}
						}
					}
				}
			} else {
				// System.out.println("NOT AN ERR");
			}
		}
		// ~~ OrderByErrorsCount ~~
		if (maxCntr > 0) {
			Iterator<Entry<String, PojoJiraLogRowData>> iterRadk0 = GroupBySpecificErrors.entrySet().iterator();
			while (iterRadk0.hasNext()) {
				Entry<String, PojoJiraLogRowData> rank0 = iterRadk0.next();
				String _cntrString = "%0" + (Math.round(Math.log10(maxCntr)) + 1) + "d";
				OrderByErrorsCount.put(String.format(_cntrString, rank0.getValue().getCounter()) + " " + rank0.getKey(), rank0.getValue());
			}
			// ~~ Print in Order  ~~
			iterRadk0 = OrderByErrorsCount.entrySet().iterator();
			while (iterRadk0.hasNext()) {
				Entry<String, PojoJiraLogRowData> rank0 = iterRadk0.next();
				content.append(rank0.getKey() + " [" + rank0.getValue().getSeverityLevel() + "] " + rank0.getValue().getFullOriginalLine() + "\r");
			}
		}
		String fileName = "";
		if (aSSet.isReportAllAccessLogRecordsNotErrorsOnly()) {
			fileName = " All log entries";
		} else {
			fileName = " Errors only";
		}
		String path = aSSet.getOutDirReports() + "/" + aFilePrefixDate + fileName + " Grouped by Key '" + aSSet.getGroupMessagesOption() + "'.csv";
		try {
			Files.write(Paths.get(path), content.toString().getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Report saved to: '" + path + "'");

	}

	//	public void saveReportAccounts(TreeMap<Long, TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>> aDictGroupByDateType, PojoJsonSystemSettingsFile aSSet, String aFilePrefixDate) {
	//		PojoJiraLogRowData _item = null;
	//		int maxCntr = 0;
	//		final StringBuilder content = new StringBuilder("");
	//		Iterator<Entry<Long, TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>>> iterRank0Day = aDictGroupByDateType.entrySet().iterator();
	//		while (iterRank0Day.hasNext()) { //~~ Loop Days ~~
	//			Entry<Long, TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>> _ranksSectionDay = iterRank0Day.next();
	//		}
	//	}

	///~~~ UTILS ~~~

	private EnumSeverity getSeverityLevelFromString(String aStringWithSeverityLevel) {
		EnumSeverity enumSeverity = null;
		for (EnumSeverity severity : EnumSeverity.values()) {
			if (aStringWithSeverityLevel.contains(severity.name())) {
				enumSeverity = severity;
				// System.out.print(severity + ": " + aStringWithSeverityLevel);
			}
		}
		return enumSeverity;
	}

}
