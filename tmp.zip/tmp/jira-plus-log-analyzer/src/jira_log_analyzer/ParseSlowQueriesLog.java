package jira_log_analyzer;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.TreeMap;
import java.util.TreeSet;

import jira_log_analyzer.EpLogAnalyzer.EnumReportKind;
import pojo.PojoJiraLogJql;
import pojo.PojoJiraLogRowData;
import pojo.PojoLuceneQueryExecutionEvent;

public class ParseSlowQueriesLog {
	private EpLogAnalyzer ep;
	public ParseSlowQueriesLog() {
		this.ep = new EpLogAnalyzer(); //~~ not called from EpLogAnalyzer
	}
	public ParseSlowQueriesLog(EpLogAnalyzer ep) {
		this.ep = ep; //~~ called from EpLogAnalyzer
	}

	///~~ Log Lab Box ~~
	private final int sjflavor = 0; //~~ Slow Jql log file format/flavor: [0: LAB, 1: GEO] // use 0 for both  
	private final int[] idx05ActingService = {2, 2}; // http-nio-8080-exec-13
	private final int[] idx05SeverityLevel = {3, 7}; // WARN
	private final int[] idx05User = {4, 6}; // localadmin
	private final int[] idx05HttpRequestApiCallFullUrl = {7, 11}; // /rest/issueNav/1/issueTable
	private final int[] idx05SearchProvider = {8, 12}; // [c.a.j.i.search.providers.LuceneSearchProvider_SLOW]
	private final int[] idx05LuceneQueryExecutionEvent = {9, 13}; // LuceneQueryExecutionEvent{query={project = ...

	///~~atlassian-jira-slow-queries keywords
	private final String ajsqKeywordSpace = " "; // space
	private final String ajsqKeywordComma = ","; // comma
	private final String ajsqKeywordCommaSpace = ", "; // comma + space
	private final String ajsqKeywordApostropheSpace = "' "; // apostrophe + space
	private final String ajsqKeywordSol = "/"; //~ [slash, virgule, solidus]
	private final String ajsqKeywordLsb = "["; //~left square bracket
	private final String ajsqKeywordRsb = "]"; //~right square bracket
	///~~~~~~ 'ActingService's' ~~~~~
	///~~ http-nio-8080-exec-
	///~~ https-openssl-nio-443-exec-
	///~~ automation-rule-executor:thread-
	///~~ Caesium-
	///~~ Sending mailitem com.atlassian.jira.mail.SubscriptionSingleRecepientMailQueueItem 
	private final String ajsqActingServiceAutomationRuleExecutor = "automation-rule-executor:thread-"; // automation-rule-executor:thread-1
	private final String ajsqActingServiceCaesium = "Caesium-";
	private final String ajsqActingServiceSendingMailitem = "Sending mailitem";
	private final String ajsqActingServiceSendingMailitemUri = "com.atlassian.jira.mail.SubscriptionSingleRecepientMailQueueItem";
	private final String ajsqActingServiceSendingMailitemFull = ajsqActingServiceSendingMailitem + " " + ajsqActingServiceSendingMailitemUri; // 'Sending mailitem com.atlassian.jira.mail.SubscriptionSingleRecepientMailQueueItem'
	///~~ Other parameters:
	private final String ajsqKeywordUrl = "url: "; // e.g: 'url: /rest/servicedesk/1/servicedesk/BSSD/issuelist/updated; '
	private final String ajsqKeywordUser = "user: ";
	private final String ajsqKeywordWarn = "WARN";
	private final String ajsqKeywordInfo = "INFO";
	//~~ 'Sending mailitem com.atlassian.jira.mail.SubscriptionSingleRecepientMailQueueItem '
	private final String ajsqKeywordOwner = " owner: '"; // owner: 'vincenzomilitello@place.com(JIRAUSER17340)'
	private final String ajsqKeywordMailQueueService = "Mail Queue Service";
	private final String ajsqKeywordLuceneSearchProvider = "[c.a.j.i.search.providers.LuceneSearchProvider_SLOW]";
	///~~ e.g.: ScriptRunner JQL function 'issueFieldMatch' with clause '{issueFunction in issueFieldMatch(project = MyGeotab, labels, (?i)\b\w.*_showstopper\w*\b)}' took '12814' ms to run.
	private final String ajsqKeywordScriptRunnerJQLFunction = "ScriptRunner JQL function"; //~ Alternative for 'LuceneQueryExecutionEvent'
	private final String ajsqKeywordExecutionTimeTook = "' took '"; // ' took '12814' ms to run.
	private final String ajsqKeywordExecutionTimeTookMs = "' ms to run.";
	///~~ LuceneQueryExecutionEvent
	private final String ajsqKeywordLuceneQueryExecutionEvent = "LuceneQueryExecutionEvent";
	private final String ajsqKeywordQuery = "{query=";
	private final String ajsqKeywordQueryTermMetrics = ", queryTermMetrics=";
	private final String ajsqKeywordNumberOfClausesInQuery = ", numberOfClausesInQuery=";
	private final String ajsqKeywordExecutionTime = ", executionTime=";
	private final String ajsqKeywordNumberOfResults = ", numberOfResults=";
	private final String ajsqKeywordCollectorTypeAps = ", collectorType='";
	private final String ajsqKeywordCollectorType = ", collectorType=";
	///~~
	private UtilsLogsParsing utilsLogsParsing = new UtilsLogsParsing();
	private UtilsLogsSys utilsLogsSys = new UtilsLogsSys(); 
	
	void extractSlowQueries(String[] aSlowQueriesLogFiles) {
		if (aSlowQueriesLogFiles != null && aSlowQueriesLogFiles.length > 0) {
			String logFilePath = EpLogAnalyzer.SysSetngs.getInDirJiraHomeLogs();
			LocalDateTime dateFileCreated = null;
			LocalDateTime dateFileUpdated = null;
			for (String nextFile : aSlowQueriesLogFiles) {
				// ~~ Filter the file base on log type and date
				try {
					BasicFileAttributes attr = Files.readAttributes(Paths.get(logFilePath + ajsqKeywordSol + nextFile), BasicFileAttributes.class);
					FileTime fct = attr.creationTime();
					FileTime fut = attr.lastModifiedTime();
					dateFileCreated = utilsLogsSys.formatDateTime(fct);
					dateFileUpdated = utilsLogsSys.formatDateTime(fut);
					/// System.out.println("File found, check dates '" + _f + "', Created: " + _fileCreated + ",  Updated: " + _fileUpdated); ///DEBUG
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				if (!EpLogAnalyzer.SysSetngs.isJiraLogsIsCheckFileMetaData() || dateFileUpdated.isAfter(ep.localDateStart) && dateFileUpdated.isBefore(ep.localDateEnd)) {
					///System.out.println("Reading file: '" + fileName + "', Created: " + dateFileCreated + ",  Updated: " + dateFileUpdated); ///DEBUG

					try (BufferedReader _br = new BufferedReader(new FileReader(logFilePath + ajsqKeywordSol + nextFile))) {
						String _rawLine = "";
						///~~~ Read all log file lines ~~~
						while (_rawLine != null) {
							_rawLine = _br.readLine();
							parseSlowQueryLogLine(_rawLine, nextFile);
						}
					} catch (FileNotFoundException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}
				} else {
					System.out.println("File or data in the file '" + nextFile + "' not found for the period");
				}
			}
		}
	}

	public final PojoJiraLogRowData parseSlowQueryLogLine(String aRrawLine, String aFileName) {
		PojoJiraLogRowData jiraLogRow = null;
		PojoLuceneQueryExecutionEvent lucene = null;
		if (aRrawLine != null && aRrawLine.length() > 44) { // ~~ some number, just longer than 23 in the next line
			String logEntryDateTimeString = aRrawLine.substring(0, 23);
			if (logEntryDateTimeString.substring(19, 20).compareTo(ajsqKeywordComma) == 0) { //~~ Make sure it's a date
				LocalDateTime _logDateTime = utilsLogsSys.extractToLocalDateTime(logEntryDateTimeString);
				if ((ep.localDateStart == null && ep.localDateEnd == null) || (_logDateTime.isAfter(ep.localDateStart) && _logDateTime.isBefore(ep.localDateEnd))) {
					ZonedDateTime _zdt = _logDateTime.atZone(ZoneId.of("UTC"));
					//_zdt = _logDateTime.atZone(ZoneId.systemDefault());
					Long _logLineTimeMsec = _zdt.toInstant().toEpochMilli();
					Long keyRoundedToDate = 0L;
					if (ep.rankWidthMm != 0) {
						keyRoundedToDate = _logLineTimeMsec - _logLineTimeMsec % (ep.rankWidthMm * 60 * 1000);
					}
					// _zdt = _logDateTime.atZone(ZoneId.systemDefault());
					_logLineTimeMsec = _zdt.toInstant().toEpochMilli();

					//~~ Create and start filling up object 'jiraLogRow'  
					jiraLogRow = new PojoJiraLogRowData();
					jiraLogRow.setSourceLogFileName(aFileName); // Original Log File name 
					jiraLogRow.setFullOriginalLine(aRrawLine);
					jiraLogRow.setLocalDateTime(_logDateTime);
					jiraLogRow.setLocalDateTimeMsec(_logLineTimeMsec);
					jiraLogRow.setEventsCountDataPoint(1L); //~~ Initial count of events (log entries) with identical timestamps ~~ TODO consider two slow JQL with the same log time stamp (very low probability unlike to access log) 
					/// jiraLogRow.setEventsCountPerChartTick(0L); //~~ Will be populated later during data compressing using 'EventsCountDataPoint'
					jiraLogRow.setLogKind(EnumReportKind.SlowQuery.getRepKindCode());

					///~~ Initiate all parameters:
					jiraLogRow.setActingServiceFull("na");
					jiraLogRow.setActingServiceCore("na");
					jiraLogRow.setHttpRequestApiCallFull("na");
					jiraLogRow.setHttpRequestApiCallCore("na");
					jiraLogRow.setJqlLuceneQueryOrHtmlParam(EpLogAnalyzer.EnumReportKind.SlowQuery.toString() + "." + "na");
					jiraLogRow.setCollectorType("na");
					jiraLogRow.setExecutionTimeDataPointMSec(UtilsLogsParsing.jiraLogValueUnavailable); //~~ Note -7L is used as indicator of unavailability
					jiraLogRow.setKeyUserReportKindSeverity("na");
					jiraLogRow.setNumberOfClausesInQuery(UtilsLogsParsing.jiraLogValueUnavailable); //~~ Note -7L is used as indicator of unavailability 
					jiraLogRow.setNumberOfResults(UtilsLogsParsing.jiraLogValueUnavailable); //~~ Note -7L is used as indicator of unavailability
					jiraLogRow.setSearchProvider("na");
					jiraLogRow.setSeverityLevel("na");
					jiraLogRow.setUserNameCore("na");
					jiraLogRow.setUserNameFull("na");

					///~~ Check what type of the log string is it -- 'com.atlassian.jira.mail' or regular filter/jql  
					boolean isReportLineJiraMail = aRrawLine.contains(ajsqActingServiceSendingMailitemFull); // Sending mailitem com.atlassian.jira.mail.SubscriptionSingleRecepientMailQueueItem
					boolean isReportLineAutomationRuleExecutor = aRrawLine.contains(ajsqActingServiceAutomationRuleExecutor); // automation-rule-executor:thread-1
					boolean isReportLineCaesium = aRrawLine.contains(ajsqActingServiceCaesium); // Caesium-

					if (isReportLineJiraMail) {
						///~~~~ Example of EMail report Line, includes: com.atlassian.jira.mail
						///~ 2024-03-27 00:00:00,000+0000
						///~ Sending mailitem com.atlassian.jira.mail.SubscriptionSingleRecepientMailQueueItem 
						///~ owner: 'vincenzomilitello@place.com(JIRAUSER17340)' 
						///~ WARN 
						///~ kevinsiddique@place.com    
						///~ Mail Queue Service [c.a.j.i.search.providers.LuceneSearchProvider_SLOW] 
						///~ LuceneQueryExecutionEvent{
						///~ 		query={team = "GISec"} AND {assignee in (EMPTY)} AND {resolution = "Unresolved"} order by team DESC,key ASC, 
						///~ 		queryTermMetrics={...},				///~~ DISREGARD 
						///~ 		numberOfClausesInQuery=3, 
						///~ 		executionTime=1312, 
						///~ 		numberOfResults=207, 
						///~ 		collectorType='TopDocs'
						///~ }
						///~~~~ Short version: 
						///~ ScriptRunner JQL function 'issueFieldMatch' with clause '{issueFunction in issueFieldMatch(project = MyGeotab, labels, (?i)\b\w.*_showstopper\w*\b)}' took '12814' ms to run. 

						jiraLogRow.setActingServiceFull(ajsqActingServiceSendingMailitem);
						jiraLogRow.setActingServiceCore(ajsqActingServiceSendingMailitem);
						jiraLogRow.setHttpRequestApiCallFull(ajsqActingServiceSendingMailitemUri);
						jiraLogRow.setHttpRequestApiCallCore(ajsqActingServiceSendingMailitemUri);

						///~~  owner: 'vincenzomilitello@place.com(JIRAUSER17340)'
						String _owner = "";
						if (aRrawLine.contains(ajsqKeywordOwner)) {
							_owner = aRrawLine.substring(aRrawLine.indexOf(ajsqKeywordOwner) + ajsqKeywordOwner.length());
							if (_owner.length() > 2 && _owner.contains(ajsqKeywordApostropheSpace)) {
								_owner = _owner.substring(0, _owner.indexOf(ajsqKeywordApostropheSpace));
							}
						}
						jiraLogRow.setUserNameFull(_owner);
						if (_owner.length() > 2 && _owner.contains("@")) {
							_owner = _owner.substring(0, _owner.indexOf("@"));
							jiraLogRow.setUserNameCore(_owner);
						}

						///~~ WARN INFO etc
						String _warninfoetc = "";
						if (aRrawLine.contains(ajsqKeywordWarn)) {
							_warninfoetc = ajsqKeywordWarn;
							jiraLogRow.setSeverityLevel(_warninfoetc); //~TODO Add 'EnumSeverity'
							jiraLogRow.setKeyUserReportKindSeverity(_warninfoetc); //~TODO
						}

						///~~ search.providers
						String searchProviders = ajsqKeywordLuceneSearchProvider; //~ [c.a.j.i.search.providers.LuceneSearchProvider_SLOW]
						jiraLogRow.setSearchProvider(searchProviders);

						///~~~~~ LuceneQueryExecutionEvent ~~~~
						if (aRrawLine.contains(ajsqKeywordLuceneQueryExecutionEvent)) {
							lucene = parseLucene(aRrawLine);
							jiraLogRow.setJqlLuceneQueryOrHtmlParam(EpLogAnalyzer.EnumReportKind.SlowQuery.toString() + "." + lucene.getLuceneQuery());
							jiraLogRow.setNumberOfClausesInQuery(lucene.getLuceneNumberOfClausesInQuery());
							jiraLogRow.setExecutionTimeDataPointMSec(lucene.getLuceneExecutionTime());
							jiraLogRow.setNumberOfResults(lucene.getLuceneNumberOfResults());
							jiraLogRow.setCollectorType(lucene.getLuceneCollectorType());

						} else if (aRrawLine.contains(ajsqKeywordScriptRunnerJQLFunction)) {
							///~ "ScriptRunner JQL function" -- Alternative for 'LuceneQueryExecutionEvent'
							String _scriptRunnerJQLFunctionPlus = aRrawLine.substring(aRrawLine.indexOf(ajsqKeywordScriptRunnerJQLFunction)); // note: including keyword
							String _scriptRunnerJQLFunction = "";
							String _executionTimeTook = "";
							if (_scriptRunnerJQLFunctionPlus.contains(ajsqKeywordExecutionTimeTook)) {
								_scriptRunnerJQLFunction = _scriptRunnerJQLFunctionPlus.substring(0, _scriptRunnerJQLFunctionPlus.indexOf(ajsqKeywordExecutionTimeTook));
								_scriptRunnerJQLFunction += "'"; //~ restore missing closing apostrophe
								_executionTimeTook = _scriptRunnerJQLFunctionPlus.substring(_scriptRunnerJQLFunctionPlus.indexOf(ajsqKeywordExecutionTimeTook) + ajsqKeywordExecutionTimeTook.length());
								if (_executionTimeTook.contains(ajsqKeywordExecutionTimeTookMs)) {
									_executionTimeTook = _executionTimeTook.substring(0, _executionTimeTook.indexOf(ajsqKeywordExecutionTimeTookMs));
								}
							}
							jiraLogRow.setJqlLuceneQueryOrHtmlParam(EpLogAnalyzer.EnumReportKind.SlowQuery.toString() + "." + _scriptRunnerJQLFunction);
							if (_executionTimeTook != null && _executionTimeTook.length() > 0) {
								jiraLogRow.setExecutionTimeDataPointMSec(Long.parseLong(_executionTimeTook));
							}
						}

					} else if (isReportLineAutomationRuleExecutor || isReportLineCaesium) {
						///~ automation-rule-executor:thread-1
						///~ 2024-03-27 00:00:00,000+0000 
						///~ automation-rule-executor:thread-1 
						///~ WARN 
						///~ Systemuser@geotab.com     
						///~ [c.a.j.i.search.providers.LuceneSearchProvider_SLOW] 
						///~ LuceneQueryExecutionEvent{query={cf[12226] > 0} AND {cf[12226] < "3m"} AND {project in (13300)}, 
						///~ 	queryTermMetrics={
						///~ 		org.apache.lucene.document.LongPoint$1=TermMetric{count=194, isCustomField=false}, 
						///~ 		customfield_12226_last_cycle_state:paused=TermMetric{count=2, isCustomField=true}, 
						///~ 		projid:13701=TermMetric{count=2, isCustomField=false}, 
						///~ 		projid:12700=TermMetric{count=2, isCustomField=false}
						///~ 	}, 
						///~ 	numberOfClausesInQuery=489, 
						///~ 	executionTime=715, 
						///~ 	numberOfResults=0, 
						///~ 	collectorType='TopDocs'
						///~ }

						if (isReportLineAutomationRuleExecutor) {
							jiraLogRow.setActingServiceFull(ajsqActingServiceAutomationRuleExecutor);
							jiraLogRow.setActingServiceCore(ajsqActingServiceAutomationRuleExecutor);
						} else if (isReportLineCaesium) {
							jiraLogRow.setActingServiceFull(ajsqActingServiceCaesium);
							jiraLogRow.setActingServiceCore(ajsqActingServiceCaesium);
						}
						jiraLogRow.setHttpRequestApiCallFull(jiraLogRow.getActingServiceFull()); //~ No http or uri, so reuse ActingService 
						jiraLogRow.setHttpRequestApiCallCore(jiraLogRow.getActingServiceFull()); //~ No http or uri, so reuse ActingService

						///~~  user 'Systemuser@geotab.com'
						String[] splited = null;
						String _user = "";
						if (aRrawLine.contains(ajsqKeywordLuceneSearchProvider)) { //  "[c.a.j.i.search.providers.LuceneSearchProvider_SLOW]"; //~~ Seems to be present in each log line?
							//~ Cut off right part behind USER:  2024-03-27 00:00:00,000+0000 automation-rule-executor:thread-1 WARN Systemuser@geotab.com
							_user = aRrawLine.substring(0, aRrawLine.indexOf(ajsqKeywordLuceneSearchProvider));
							_user = _user.trim();
							splited = _user.split(" ");
						}
						if (splited != null) { //~~ TODO find why null is happening
							_user = splited[splited.length - 1];
							jiraLogRow.setSeverityLevel(splited[3]); //~TODO Add EnumSeverity
							jiraLogRow.setKeyUserReportKindSeverity(splited[3]); //~TODO
						} else {
							System.out.println("ERR134576 in: " + aRrawLine);
						}
						jiraLogRow.setUserNameFull(_user);
						if (_user.length() > 2 && _user.contains("@")) {
							_user = _user.substring(0, _user.indexOf("@"));
							jiraLogRow.setUserNameCore(_user);
						} else {
							jiraLogRow.setUserNameCore(_user);
						}

						///~~ WARN, INFO, etc.
						if (isReportLineAutomationRuleExecutor) {
						} else if (isReportLineCaesium) {
						}

						///~~ search.providers
						String searchProviders = ajsqKeywordLuceneSearchProvider; //~ [c.a.j.i.search.providers.LuceneSearchProvider_SLOW]
						jiraLogRow.setSearchProvider(searchProviders);

						///~~~~~ LuceneQueryExecutionEvent ~~~~
						if (aRrawLine.contains(ajsqKeywordLuceneQueryExecutionEvent)) {
							lucene = parseLucene(aRrawLine);
							jiraLogRow.setJqlLuceneQueryOrHtmlParam(EpLogAnalyzer.EnumReportKind.SlowQuery.toString() + "." + lucene.getLuceneQuery());
							jiraLogRow.setNumberOfClausesInQuery(lucene.getLuceneNumberOfClausesInQuery());
							jiraLogRow.setExecutionTimeDataPointMSec(lucene.getLuceneExecutionTime());
							jiraLogRow.setNumberOfResults(lucene.getLuceneNumberOfResults());
							jiraLogRow.setCollectorType(lucene.getLuceneCollectorType());
						}

					} else {
						///~~ Regular Filter/Jql/etc

						int limitLineLengthTo = utilsLogsParsing.nthOccurrence(aRrawLine, ajsqKeywordSpace, idx05LuceneQueryExecutionEvent[sjflavor] + 1);
						//~~ Regular report line
						String[] arrSplit05 = aRrawLine.substring(0, limitLineLengthTo).split(ajsqKeywordSpace);
						int idxOfJqlQry = aRrawLine.indexOf(ajsqKeywordLuceneQueryExecutionEvent);
						String jqlQry = "";
						if (idxOfJqlQry > 0) { /// tvn
							jqlQry = aRrawLine.substring(idxOfJqlQry);
							if (arrSplit05.length > idx05LuceneQueryExecutionEvent[sjflavor]) {
								arrSplit05[idx05LuceneQueryExecutionEvent[sjflavor]] = jqlQry;
							}
						}
						jiraLogRow.setActingServiceFull(arrSplit05[idx05ActingService[sjflavor]]);
						jiraLogRow.setActingServiceCore(utilsLogsParsing.extractTheActingServiceCore(jiraLogRow.getActingServiceFull()));

						if (aRrawLine.contains(ajsqKeywordUrl) && aRrawLine.contains(ajsqKeywordUser)) {
							int idxUrl = aRrawLine.indexOf(ajsqKeywordUrl) + ajsqKeywordUrl.length();
							int idxUserStart = aRrawLine.indexOf(ajsqKeywordUser) + ajsqKeywordUser.length();
							int idxUserEnd = idxUserStart + aRrawLine.substring(idxUserStart + 1).indexOf(ajsqKeywordSpace) + 1;
							jiraLogRow.setUserNameFull(aRrawLine.substring(idxUserStart, idxUserEnd));
							String url = aRrawLine.substring(idxUrl, idxUserStart - ajsqKeywordUser.length() - 1);
							jiraLogRow.setHttpRequestApiCallFull(url);
							jiraLogRow.setHttpRequestApiCallCore(url);
							utilsLogsParsing.extractHttpRequestApiCallCore(jiraLogRow); // jiraLogRow.setHttpRequestApiCallCore(); 
							int idxSeverityLevelEnd = idxUserEnd + aRrawLine.substring(idxUserEnd + 2).indexOf(ajsqKeywordSpace) + 2;
							jiraLogRow.setSeverityLevel(aRrawLine.substring(idxUserEnd + 1, idxSeverityLevelEnd));
							int idxSearchProviderStart = idxSeverityLevelEnd + aRrawLine.substring(idxSeverityLevelEnd + 2).indexOf(ajsqKeywordLsb) + 2;
							int idxSearchProviderEnd = idxSearchProviderStart + aRrawLine.substring(idxSearchProviderStart + 2).indexOf(ajsqKeywordRsb) + 2;
							jiraLogRow.setSearchProvider(aRrawLine.substring(idxSearchProviderStart + 1, idxSearchProviderEnd));
						} else {
							try {
								jiraLogRow.setUserNameFull(arrSplit05[idx05User[sjflavor]].trim());
								jiraLogRow.setHttpRequestApiCallFull(arrSplit05[idx05HttpRequestApiCallFullUrl[sjflavor]].trim());
								jiraLogRow.setHttpRequestApiCallCore(arrSplit05[idx05HttpRequestApiCallFullUrl[sjflavor]].trim());
								jiraLogRow.setSeverityLevel(arrSplit05[idx05SeverityLevel[sjflavor]].trim());
								jiraLogRow.setSearchProvider(arrSplit05[idx05SearchProvider[sjflavor]].trim());
							} catch (Exception e1) {
								System.err.print("~ERRq532 in: " + jiraLogRow.getFullOriginalLine());
							}
						}

						utilsLogsParsing.extractHttpRequestApiCallCore(jiraLogRow);
						jiraLogRow.setUserNameCore(utilsLogsParsing.extractUserNameFromEmail((utilsLogsParsing.extractUserNameCore(jiraLogRow.getUserNameFull()))));
						jiraLogRow.setKeyUserReportKindSeverity(utilsLogsParsing.buildTheKeyForTheRankGrouping(jiraLogRow.getUserNameCore(), jiraLogRow.getHttpRequestApiCallCore(), jiraLogRow.getExecutionTimeDataPointMSec(), EpLogAnalyzer.EnumReportKind.SlowQuery, jiraLogRow));

						///~~~~~ LuceneQueryExecutionEvent ~~~~
						if (aRrawLine.contains(ajsqKeywordLuceneQueryExecutionEvent)) {
							lucene = parseLucene(aRrawLine);
							jiraLogRow.setJqlLuceneQueryOrHtmlParam(EpLogAnalyzer.EnumReportKind.SlowQuery.toString() + "." + lucene.getLuceneQuery());
							jiraLogRow.setNumberOfClausesInQuery(lucene.getLuceneNumberOfClausesInQuery());
							jiraLogRow.setExecutionTimeDataPointMSec(lucene.getLuceneExecutionTime());
							jiraLogRow.setNumberOfResults(lucene.getLuceneNumberOfResults());
							jiraLogRow.setCollectorType(lucene.getLuceneCollectorType());
						}
					}

					///~~ FINALLY ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
					///~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
					///~~ Populate JQL dictionary~~
					TreeMap<String, TreeMap<Long, PojoJiraLogJql>> setOfJqls = null;
					TreeMap<Long, PojoJiraLogJql> setOfJqlsDayRankDataPoints = null;
					PojoJiraLogJql jqlDataPoint = new PojoJiraLogJql();
					jqlDataPoint.setKeyJiraQueryLanguageLine(jiraLogRow.getJqlLuceneQueryOrHtmlParam()); //~~  JIRA Query Language full string
					jqlDataPoint.setFullOriginalLine(aRrawLine); // ~~ Full Original Log Line
					jqlDataPoint.setUrl(jiraLogRow.getHttpRequestApiCallFull()); //TODO Full or Core?
					jqlDataPoint.setLocalDateTimeMsec(_logLineTimeMsec); // ~~ 'Timestamp' from the log -- Re-Calculated to mSec
					jqlDataPoint.setExecutionTimeDataPointMSec(jiraLogRow.getExecutionTimeDataPointMSec()); //~~ JQL Execution time
					jqlDataPoint.setNumberOfClausesInQuery(jiraLogRow.getNumberOfClausesInQuery());
					jqlDataPoint.setNumberOfResults(jiraLogRow.getNumberOfResults());
					if (jqlDataPoint.getUserNameCore() != null) {
						if (!jqlDataPoint.getUserNameCore().contains(jiraLogRow.getUserNameCore())) {
							jqlDataPoint.getUserNameCore().add(jiraLogRow.getUserNameCore());
						}
					} else {
						TreeSet usersUsingThisJql = new TreeSet();
						usersUsingThisJql.add(jiraLogRow.getUserNameCore());
						jqlDataPoint.setUserNameCore(usersUsingThisJql);
					}
					if (ep.dictJql.containsKey(keyRoundedToDate)) {
						setOfJqls = ep.dictJql.get(keyRoundedToDate);
						if (jiraLogRow.getJqlLuceneQueryOrHtmlParam() != null && setOfJqls.containsKey(jiraLogRow.getJqlLuceneQueryOrHtmlParam())) {
							setOfJqlsDayRankDataPoints = setOfJqls.get(jiraLogRow.getJqlLuceneQueryOrHtmlParam());
						} else {
							setOfJqlsDayRankDataPoints = new TreeMap<Long, PojoJiraLogJql>();
							if (jiraLogRow.getJqlLuceneQueryOrHtmlParam() != null) {
								setOfJqls.put(jiraLogRow.getJqlLuceneQueryOrHtmlParam(), setOfJqlsDayRankDataPoints);
							}
						}
						setOfJqlsDayRankDataPoints.put(_logLineTimeMsec, jqlDataPoint);
					} else {
						if (jiraLogRow.getJqlLuceneQueryOrHtmlParam() != null) {
							setOfJqlsDayRankDataPoints = new TreeMap<Long, PojoJiraLogJql>();
							setOfJqls = new TreeMap<String, TreeMap<Long, PojoJiraLogJql>>();
							setOfJqls.put(jiraLogRow.getJqlLuceneQueryOrHtmlParam(), setOfJqlsDayRankDataPoints);
							setOfJqlsDayRankDataPoints.put(_logLineTimeMsec, jqlDataPoint);
							ep.dictJql.put(keyRoundedToDate, setOfJqls);
						}
					}
					///~~ End Of Populate JQL dictionary ~~

					//~~ Assign the case to the report's rank
					TreeMap<Long, TreeMap<Long, PojoJiraLogRowData>> overallUserDayActivityAllRanks; //~~ Day Set of data ranks, Key - rounded to a days in msec
					if (ep != null && ep.DictGroupByTypeDateCollected != null) {
						if (ep.DictGroupByTypeDateCollected.containsKey(jiraLogRow.getKeyUserReportKindSeverity())) {
							// ~~ Top Key/Rank exists for this Rank, just add new activity to this existing Rank
							overallUserDayActivityAllRanks = ep.DictGroupByTypeDateCollected.get(jiraLogRow.getKeyUserReportKindSeverity());
							// jiraLogRow.setUserAccountLastEventThisDay(jiraLogRow.getLocalDateTimeMsec()); //~~ This is next event to be used to calculate last event per day for the user Account
							if (overallUserDayActivityAllRanks.containsKey(keyRoundedToDate)) {
								TreeMap<Long, PojoJiraLogRowData> _existingRank = overallUserDayActivityAllRanks.get(keyRoundedToDate);
								while (_existingRank.containsKey(_logLineTimeMsec)) {
									_logLineTimeMsec++; // ~~ if we have more than one log entries with the same time, modify a time (key), so we can keep all events in dict
								}
								_existingRank.put(_logLineTimeMsec, jiraLogRow);
							} else { // ~~ Add new report rank
								TreeMap<Long, PojoJiraLogRowData> _newRank = new TreeMap<Long, PojoJiraLogRowData>();
								_newRank.put(_logLineTimeMsec, jiraLogRow);
								overallUserDayActivityAllRanks.put(keyRoundedToDate, _newRank);
							}
						} else {
							// ~~ UserKey does not exists in this Rank, create new
							overallUserDayActivityAllRanks = new TreeMap<Long, TreeMap<Long, PojoJiraLogRowData>>();
							// jiraLogRow.setUserAccountFirstEventThisDay(jiraLogRow.getLocalDateTimeMsec()); //~~ This is the chronologically first event for this account at this day
							TreeMap<Long, PojoJiraLogRowData> _newRank = new TreeMap<Long, PojoJiraLogRowData>();
							_newRank.put(_logLineTimeMsec, jiraLogRow);
							overallUserDayActivityAllRanks.put(keyRoundedToDate, _newRank);
							ep.DictGroupByTypeDateCollected.put(jiraLogRow.getKeyUserReportKindSeverity(), overallUserDayActivityAllRanks);
						}
					}
				}
			}
		}
		return jiraLogRow;
	}

	private PojoLuceneQueryExecutionEvent parseLucene(String aRrawLine) {
		/// https://lucene.apache.org/core/2_9_4/queryparsersyntax.html
		PojoLuceneQueryExecutionEvent dissectedLucene = new PojoLuceneQueryExecutionEvent();

		///~~ query
		String _luceneQueryExecutionEvent = aRrawLine.substring(aRrawLine.indexOf(ajsqKeywordLuceneQueryExecutionEvent) + ajsqKeywordLuceneQueryExecutionEvent.length());
		String _query = _luceneQueryExecutionEvent.substring(_luceneQueryExecutionEvent.indexOf(ajsqKeywordQuery) + ajsqKeywordQuery.length());
		if (_query.contains(ajsqKeywordQueryTermMetrics)) {
			_query = _query.substring(0, _query.indexOf(ajsqKeywordQueryTermMetrics));
		}
		dissectedLucene.setLuceneQuery(_query);

		///~~ numberOfClausesInQuery=
		String _numberOfClausesInQuery = "";
		if (_luceneQueryExecutionEvent.contains(ajsqKeywordNumberOfClausesInQuery)) {
			_numberOfClausesInQuery = _luceneQueryExecutionEvent.substring(_luceneQueryExecutionEvent.indexOf(ajsqKeywordNumberOfClausesInQuery) + ajsqKeywordNumberOfClausesInQuery.length());
			if (_numberOfClausesInQuery.length() > 2 && _numberOfClausesInQuery.contains(ajsqKeywordCommaSpace)) {
				_numberOfClausesInQuery = _numberOfClausesInQuery.substring(0, _numberOfClausesInQuery.indexOf(ajsqKeywordCommaSpace));
			}
		}
		if (_numberOfClausesInQuery != null && _numberOfClausesInQuery.length() > 0) {
			dissectedLucene.setLuceneNumberOfClausesInQuery(Long.parseLong(_numberOfClausesInQuery));
		}

		///~~ executionTime=
		String _executionTime = "";
		if (_luceneQueryExecutionEvent.contains(ajsqKeywordExecutionTime)) {
			_executionTime = _luceneQueryExecutionEvent.substring(_luceneQueryExecutionEvent.indexOf(ajsqKeywordExecutionTime) + ajsqKeywordExecutionTime.length());
			if (_executionTime.length() > 2 && _executionTime.contains(ajsqKeywordCommaSpace)) {
				_executionTime = _executionTime.substring(0, _executionTime.indexOf(ajsqKeywordCommaSpace));
			}
		}
		if (_executionTime != null && _executionTime.length() > 0) {
			dissectedLucene.setLuceneExecutionTime(Long.parseLong(_executionTime));
		}

		///~~ numberOfResults=
		String _numberOfResults = "";
		if (_luceneQueryExecutionEvent.contains(ajsqKeywordNumberOfResults)) {
			_numberOfResults = _luceneQueryExecutionEvent.substring(_luceneQueryExecutionEvent.indexOf(ajsqKeywordNumberOfResults) + ajsqKeywordNumberOfResults.length());
			if (_numberOfResults.length() > 2 && _numberOfResults.contains(ajsqKeywordCommaSpace)) {
				_numberOfResults = _numberOfResults.substring(0, _numberOfResults.indexOf(ajsqKeywordCommaSpace));
			}
		}
		if (_numberOfResults != null && _numberOfResults.length() > 0) {
			dissectedLucene.setLuceneNumberOfResults(Long.parseLong(_numberOfResults));
		}

		///~~ collectorType='TopDocs'
		String _collectorType = "";
		if (_luceneQueryExecutionEvent.contains(ajsqKeywordCollectorType)) {
			_collectorType = _luceneQueryExecutionEvent.substring(_luceneQueryExecutionEvent.indexOf(ajsqKeywordCollectorType) + ajsqKeywordCollectorType.length());
			if (_collectorType.length() > 2 && _collectorType.contains("}")) {
				_collectorType = _collectorType.substring(0, _collectorType.indexOf("}"));
			}
		}
		dissectedLucene.setLuceneCollectorType(_collectorType);

		return dissectedLucene;
	}
}
