package jira_log_analyzer;

import java.awt.Color;

public class UtilsLogsChart {

	public static Color getNextRgbColour(int anIndex, boolean isUseSingleColour) { // int aColorNumber
		if (isUseSingleColour) {
			if ((anIndex & 1) == 0) {
				return new Color(0, 64, 128);
			} else {
				return new Color(128, 0, 128);
			}
		} else {
			anIndex *= 377 * Math.random();
			anIndex = anIndex % (16 * 3);
			int cr = 128;
			int cg = 128;
			int cb = 128;
			if (anIndex < 16) {
				cr = 16 * anIndex;
			} else if (anIndex < 2 * 16) {
				cg = 16 * (anIndex - 16);
			} else {
				cb = 16 * (anIndex - 2 * 16);
			}
			cr = (int) (anIndex + 256 * Math.random());
			cg = (int) (anIndex + 256 * Math.random());
			cb = (int) (anIndex + 256 * Math.random());
			if (cr > 199) {
				cr = 199;
			}
			if (cg > 199) {
				cg = 199;
			}
			if (cb > 199) {
				cb = 199;
			}
			return new Color(cr, cg, cb);
		}
	}

}
