package utilsJsonJiraDc;

import java.net.URL;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import jiraPojoObjects.PojoFilter;
import jiradcapiconnector.JiraDCApiConnector;

public class ParseJiraDcJsonFilter {

	public PojoFilter jiraRestApiGetFilter(URL anApiUrl, String aLoginKey, boolean isBasicLogin) {
		PojoFilter fullFilter = null;
		JiraDCApiConnector jiraDCApiConnector = new JiraDCApiConnector();
		StringBuilder sb = new StringBuilder();
		/// sb.append("~~URL_API_CALL:'" + anApiUrl.toString() + "'"); //DEBUGPRINT
		String filterJsonString = jiraDCApiConnector.jiraRestApiGet(anApiUrl, aLoginKey, isBasicLogin);
		if (filterJsonString != null) {
			if (filterJsonString.compareTo(JiraDCApiConnector.respCode400) == 0) {
				fullFilter = new PojoFilter();
				fullFilter.setId(JiraDCApiConnector.respCode400);
				// sb.append("\n\t~2~" + JiraDCApiConnector.respCode400); //DEBUGPRINT
			} else {
				fullFilter = parseJiraFilterToJson(filterJsonString);
				if (fullFilter != null) {
					sb.append("~Filter " + fullFilter.getId() + " \"" + fullFilter.getName() + "\""); //--Normal case: ~filterID:397477 'Filter Name Here'
				} else {
					sb.append("Err87:" + anApiUrl.getPath() + ": can't parse filter");
				}
			}
		} else {
			/// --this printed in 'jiraRestApiGet()'
			/// sb.append("~filter=null for " + anApiUrl.getPath()); //DEBUGPRINT
		}
		///System.out.print("\n~" + (new Date()).toString() + ", filter:'" + sb + "'");
		if (sb != null && sb.length() > 0) {
			//DEBUGPRINT -- prints each NEW found in Jira filter to console:
			System.out.print("\n" + sb); // ~filterID:397477 'Filter Name Here'
		}
		return fullFilter;
	}

	private PojoFilter parseJiraFilterToJson(String aJson) {
		PojoFilter pojoObject = null;
		if (aJson != null) {
			JSONParser parser = new JSONParser();
			JSONObject jsonObj = null;
			try {
				jsonObj = (JSONObject) parser.parse(aJson);
				pojoObject = new PojoFilter();
				pojoObject.setId((String) jsonObj.get("id"));
				pojoObject.setSelf((String) jsonObj.get("self"));
				pojoObject.setName((String) jsonObj.get("name"));
				pojoObject.setJql((String) jsonObj.get("jql"));
				pojoObject.setViewUrl((String) jsonObj.get("viewUrl"));
				pojoObject.setSearchUrl((String) jsonObj.get("searchUrl"));
				pojoObject.setFavourite((Boolean) jsonObj.get("favourite"));
				pojoObject.setEditable((Boolean) jsonObj.get("editable"));
				JSONObject jsonObjOwner = (JSONObject) jsonObj.get("owner");
				if (jsonObjOwner != null) {
					pojoObject.setOwnerKey((String) jsonObjOwner.get("key"));
					pojoObject.setOwnerName((String) jsonObjOwner.get("name"));
					pojoObject.setOwnerDisplayName((String) jsonObjOwner.get("displayName"));
					pojoObject.setOwnerActive((Boolean) jsonObjOwner.get("active"));
				}
			} catch (ParseException e) {
			}
		}
		return pojoObject;
	}
}
