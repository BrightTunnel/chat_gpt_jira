package utilsJsonJiraDc;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
///import org.json.simple.parser.ParseException;
import org.json.simple.parser.ParseException;

import jiraPojoObjects.PojoFilter;
import jiradcapiconnector.JiraDCApiConnector;

public class ParseJiraDcJsonAuditingFilters {

	public static final String audiingFilters = "dc-auditing-filters.json";

	public LinkedHashMap<String, PojoFilter> jiraRestApiGetAuditingFilters(URL anApiUrl, String aLoginKey, boolean isBasicLogin, Date aLastSavedReportDate) {
		LinkedHashMap<String, PojoFilter> fullFilter = null;
		JiraDCApiConnector jiraDCApiConnector = new JiraDCApiConnector();
		StringBuilder sb = new StringBuilder(); //DEBUGPRINT
		/// sb.append("~~URL_API_CALL:'" + anApiUrl.toString() + "'"); //DEBUGPRINT
		String filterJsonString = jiraDCApiConnector.jiraRestApiGet(anApiUrl, aLoginKey, isBasicLogin);
		if (filterJsonString != null) {
			if (filterJsonString.compareTo(JiraDCApiConnector.respCode400) == 0) {
				fullFilter = new LinkedHashMap<String, PojoFilter>();
				// sb.append("\n\t~2~" + JiraDCApiConnector.respCode400); //DEBUGPRINT
			} else {
				fullFilter = parseAuditingFiltersToJson(filterJsonString, aLastSavedReportDate);
				if (fullFilter != null) {
					// sb.append(fullFilter.getId() + ": '" + fullFilter.getName() + "'"); //DEBUGPRINT --Normal case
				} else {
					sb.append(anApiUrl.getPath() + ": can't parse filter"); //DEBUGPRINT
				}
			}
		} else {
			/// --this printed in 'jiraRestApiGet()'
			/// sb.append("~filter=null for " + anApiUrl.getPath()); //DEBUGPRINT
		}
		/// System.out.println("\n~" + (new Date()).toString() + ", filter:'" + sb + "'"); //DEBUGPRINT
		return fullFilter;
	}

	private LinkedHashMap<String, PojoFilter> parseAuditingFiltersToJson(String filterJsonString, Date aLastSavedReportDate) {
		LinkedHashMap<String, PojoFilter> map = new LinkedHashMap<>();
		JSONParser parser = new JSONParser();
		JSONObject objarr = null;
		try {
			objarr = (JSONObject) parser.parse(filterJsonString);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		if (objarr != null) {
			JSONArray records = (JSONArray) objarr.get("records");

			for (Object recordObj : records) {
				/// PojoFilter filter = new PojoFilter();
				JSONObject record = (JSONObject) recordObj;

				/// long id = (Long) record.get("id");
				/// String summary = (String) record.get("summary");
				/// String remoteAddress = (String) record.get("remoteAddress");
				/// String authorKey = (String) record.get("authorKey");
				String filterUpdatedDateString = (String) record.get("created");
				/// String category = (String) record.get("category");
				/// String eventSource = (String) record.get("eventSource");

				/// System.out.println("ID: " + id);
				/// System.out.println("Summary: " + summary);
				/// System.out.println("Remote Address: " + remoteAddress);
				/// System.out.println("Author: " + authorKey);
				/// System.out.println("Created: " + created);
				/// System.out.println("Category: " + category);
				/// System.out.println("Event Source: " + eventSource);

				String objectId = null;
				JSONObject objectItem = (JSONObject) record.get("objectItem");
				if (objectItem != null) {
					objectId = (String) objectItem.get("id");
					/// String objectName = (String) objectItem.get("name");
					/// String typeName = (String) objectItem.get("typeName");

					/// System.out.println("Object Item ID: " + objectId);
					/// System.out.println("Object Name: " + objectName);
					/// System.out.println("Type Name: " + typeName);
				}

				/// JSONArray changedValues = (JSONArray) record.get("changedValues");
				/// for (Object changeObj : changedValues) {
				/// JSONObject change = (JSONObject) changeObj;
				/// String fieldName = (String) change.get("fieldName");
				/// String changedFrom = (String) change.get("changedFrom");
				/// String changedTo = (String) change.get("changedTo");
				///
				/// /// System.out.println("Changed Field: " + fieldName);
				/// /// System.out.println("From: " + changedFrom);
				/// /// System.out.println("To: " + changedTo);
				/// }

				/// System.out.println("--------");

				if (objectId != null && filterUpdatedDateString != null) {
					SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
					Date filterUpdatedDate = null;
					try {
						filterUpdatedDate = formatter.parse(filterUpdatedDateString);
					} catch (java.text.ParseException e) {
						e.printStackTrace();
					}
					if (filterUpdatedDate != null) {
						/// -- Add a day to cover previous day
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(filterUpdatedDate);
						calendar.add(Calendar.DATE, 1);
						Date newDate = calendar.getTime();
						/// System.out.println("Original Date: " + filterUpdatedDate);
						/// System.out.println("New Date (+1 day): " + newDate);
						if (newDate.after(aLastSavedReportDate)) {
							/// -- Update the filter in the local list of the filters file
							map.put(objectId, null);
							/// System.out.println("Filter " + objectId + " updated after last scan: " + filterUpdatedDate); //DEBUGPRINT
						} else {
							/// System.out.println("Filter " + objectId + " updated before last scan: " + filterUpdatedDate); //DEBUGPRINT
						}
					}
				}
			}
		}
		return map;
	}

	public LinkedHashMap<String, PojoFilter> UNUSED_readAuditingFiltersFromFile(String filePath, Date aLastSavedReportDate) {
		StringBuilder content = new StringBuilder();
		try (FileReader reader = new FileReader(filePath); BufferedReader bufferedReader = new BufferedReader(reader)) {
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				content.append(line).append(System.lineSeparator());
			}
			return parseAuditingFiltersToJson(content.toString(), aLastSavedReportDate);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

}
