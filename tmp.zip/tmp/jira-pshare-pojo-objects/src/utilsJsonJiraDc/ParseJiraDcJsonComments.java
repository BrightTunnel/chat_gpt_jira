package utilsJsonJiraDc;

import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Date;
import java.util.TreeMap;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import jiraPojoObjects.PojoComment;

public class ParseJiraDcJsonComments {

	public TreeMap<Date, PojoComment> mapJsonArgumentCommentsToTree(String aComment, int aJiraInstance) {
		TreeMap<Date, PojoComment> parsedComments = null;
		if (aComment != null) {
			JSONParser parser = new JSONParser();
			JSONObject commentObj = null;
			PojoComment pojoComment = null;
			String commentKey = null;
			/// Lab Box Jira DC Issue '2025-02-14T19:35:14.421-0500':
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
			if (aJiraInstance == 1) {
				sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy", Locale.ENGLISH);
			}
			try {
				commentObj = (JSONObject) parser.parse(aComment);
				commentKey = (String) commentObj.get("key");
				JSONObject fields = (JSONObject) commentObj.get("fields");
				if (fields != null) {
					JSONObject comment = (JSONObject) fields.get("comment");
					if (comment != null) {
						JSONArray comments = (JSONArray) comment.get("comments");
						if (comments != null) {
							parsedComments = new TreeMap<Date, PojoComment>();
							for (int ii = 0; ii < comments.size(); ii++) {
								JSONObject cmntObj = (JSONObject) comments.get(ii);
								pojoComment = new PojoComment();
								pojoComment.setCommentIDString((String) cmntObj.get("id"));
								pojoComment.setCommentText((String) cmntObj.get("body"));
								JSONObject author = (JSONObject) cmntObj.get("author");
								pojoComment.setCommentAuthor((String) author.get("name")); //-- localadmin(localadmin)
								pojoComment.setCommentAuthor((String) author.get("key")); //--  localadmin
								try {
									pojoComment.setCommentCreated(sdf.parse((String) cmntObj.get("created")));
									pojoComment.setCommentUpdated(sdf.parse((String) cmntObj.get("updated")));
								} catch (java.text.ParseException e) {
									System.out.print(e.getMessage() + " " + cmntObj.get("created").toString());
								}
								parsedComments.put(pojoComment.getCommentUpdated(), pojoComment);
							}
						}
					}
				}
			} catch (ParseException e) {
			}
		}
		return parsedComments;
	}
}
