package utilsJsonJiraDc;

import java.net.URL;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import jiraPojoObjects.PojoComponent;
import jiradcapiconnector.JiraDCApiConnector;

public class ParseJiraDcJsonComponent {

	public LinkedHashMap<String, PojoComponent> getJiraDcComponens(URL anApiUrl, String aLogin, boolean isBasicLogin) {
		LinkedHashMap<String, PojoComponent> components = null;
		PojoComponent component = null;
		StringBuilder sb = new StringBuilder();
		String componentsJsonString = new JiraDCApiConnector().jiraRestApiGet(anApiUrl, aLogin, isBasicLogin);
		if (componentsJsonString != null) {
			components = parseJiraComponentsToJson(componentsJsonString);
			if (components != null) {
				for (Entry<String, PojoComponent> entry : components.entrySet()) {
					sb.append(entry.getKey() + ": {" + entry.getValue().getIdString() + " " + entry.getValue().getProjectKey() + " " + entry.getValue().getCname() + "}");
					sb.append("\n");
				}
			} else {
				sb.append("\n" + ": can't parse components");
			}
		} else {
			sb.append("\n" + ": components ID N/A");
		}
		System.out.print(sb); //DEBUGPRINT
		return components;
	}

	private LinkedHashMap<String, PojoComponent> parseJiraComponentsToJson(String aJson) {
		///--List of components for the project
		LinkedHashMap<String, PojoComponent> pojoObjects = null;
		PojoComponent pojoObject = null;
		if (aJson != null) {
			JSONParser parser = new JSONParser();
			JSONObject jsonObj = null;
			try {
				JSONArray jsonArr = (JSONArray) parser.parse(aJson);
				if (jsonArr != null) {
					pojoObjects = new LinkedHashMap<String, PojoComponent>();
					for (int ii = 0; ii < jsonArr.size(); ii++) {
						jsonObj = (JSONObject) jsonArr.get(ii);
						pojoObject = new PojoComponent();
						pojoObject.setIdString((String) jsonObj.get("id"));
						pojoObject.setSelf((String) jsonObj.get("self"));
						pojoObject.setCname((String) jsonObj.get("name"));
						pojoObject.setAssigneeType((String) jsonObj.get("assigneeType"));
						pojoObject.setRealAssigneeType((String) jsonObj.get("realAssigneeType"));
						pojoObject.setAssigneeTypeValid((boolean) jsonObj.get("isAssigneeTypeValid"));
						pojoObject.setProjectKey((String) jsonObj.get("project")); // "project": "PRKEY",
						pojoObject.setProject(Integer.parseInt(jsonObj.get("projectId").toString())); // "projectId": 10300,
						pojoObject.setArchived(jsonObj.get("archived").toString()); // "archived": false,
						pojoObject.setDeleted(jsonObj.get("deleted").toString()); // "deleted": false
						pojoObjects.put(pojoObject.getIdString(), pojoObject);
					}
				}
			} catch (ParseException e) {
				System.out.print(e.getMessage());
			}
		}
		return pojoObjects;
	}
}
