package utilsJsonJiraDc;

///import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
///import java.io.IOException;
///import java.net.URISyntaxException;
///import java.nio.file.Files;
///import java.nio.file.Path;
///import java.nio.file.attribute.BasicFileAttributes;
///import java.nio.file.attribute.FileTime;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import jiraPojoObjects.PojoFilter;

public class PersistFilters {

	public static final String filtersGot = "filtersGot.json";
	public static final String filtersNull = "filtersNull.json";
	private final boolean isPersistNestedFilters = false; //--OBSOLETE, can save extra info (List of Nested Filters for each filter, if any)

	public void persistFilters(TreeMap<String, PojoFilter> map, String FileName) {
		JSONArray jsonArray = new JSONArray();
		for (Entry<String, PojoFilter> entry : map.entrySet()) {
			String key = entry.getKey();
			PojoFilter filter = entry.getValue();
			JSONObject obj = new JSONObject();
			if (filter != null) {
				obj.put("id", filter.getId());
				obj.put("name", filter.getName());
				obj.put("description", filter.getDescription());
				obj.put("ownerName", filter.getOwnerName());
				obj.put("projectid", filter.getProjectid());
				obj.put("jql", filter.getJql());
				/// obj.put("jqlFixed", filter.getJqlFixed());
				if (isPersistNestedFilters) {
					StringBuilder nestedFilters = new StringBuilder("[");
					if (filter.getNestedFilters() != null) {
						for (Entry<String, PojoFilter> entry1 : filter.getNestedFilters().entrySet()) {
							nestedFilters.append(entry1.getKey() + ",");
						}
					}
					if (nestedFilters.length() > 1) {
						nestedFilters.setLength(nestedFilters.length() - 1);
					}
					nestedFilters.append("]");
					obj.put("nestedFilters", nestedFilters.toString());
				}
			} else {
				obj.put("id", key);
			}
			jsonArray.add(obj);
		}

		///--Join JSONArray elements into a single String separated by "\n"
		String result = IntStream.range(0, jsonArray.size()).mapToObj(i -> jsonArray.get(i).toString()).collect(Collectors.joining(",\n"));
		result = "[\n" + result + "\n]";

		try (FileWriter file = new FileWriter(FileName)) {
			///file.write(jsonArray.toJSONString()); //-- Save as single String -- Replaced by:
			file.write(result);
			/// System.out.println("Saved to filters.json");
		} catch (Exception e) {
			/// e.printStackTrace();
		}
	}

	public TreeMap<String, PojoFilter> readAlreadySavedFiltersFromFile(String filePath) {
		/// --Read old saved locally filters
		TreeMap<String, PojoFilter> savedLocallyConfirmedFilters = new TreeMap<>();
		try (FileReader reader = new FileReader(filePath)) {
			JSONParser parser = new JSONParser();
			JSONArray array = (JSONArray) parser.parse(reader);
			/// --Loop saved locally filters
			for (Object fltr : array) {
				JSONObject fltrObj = (JSONObject) fltr;
				String filterId = (String) fltrObj.get("id");
				if (filePath.compareTo(filtersNull) == 0) {
					///---This is non-existing (null) in Jira filters IDs"" 
					savedLocallyConfirmedFilters.put(filterId, null);
				} else if (filePath.compareTo(filtersGot) == 0) {
					///-- Saved previously filters: 
					PojoFilter filter = new PojoFilter();
					filter.setId(filterId);
					filter.setName((String) fltrObj.get("name"));
					filter.setDescription((String) fltrObj.get("description"));
					filter.setOwnerName((String) fltrObj.get("ownerName"));
					filter.setJql((String) fltrObj.get("jql"));
					Object pid = fltrObj.get("projectid");
					filter.setProjectid(pid != null ? Long.parseLong(pid.toString()) : null);
					/// filter.setJqlFixed((String) obj.get("jqlFixed"));
					///--- OBSOLETE
					///		String nestedFilters = (String) fltrObj.get("nestedFilters");
					///		String[] resultArray = null;
					///		if (nestedFilters != null && nestedFilters.length() > 2) {
					///			String cleanedString = nestedFilters.substring(1, nestedFilters.length() - 1); //-- Remove brackets
					///			resultArray = cleanedString.split(",");
					///			///--Add nested filters of the "Forced to be refreshed" parent filter to the list of the "Forced to be refreshed"
					///			for (String nestedFilterIDStr : resultArray) {
					///				int nestedFilterID = Integer.parseInt(nestedFilterIDStr);
					///				configListOfAllForcedToRefreshFilterIDs.add(nestedFilterID);
					///			}
					///		}
					savedLocallyConfirmedFilters.put(filterId, filter);
				}
			}
		} catch (Exception e) {
			/// e.printStackTrace();
		}
		return savedLocallyConfirmedFilters;
	}

}
