package utilsJsonJiraDc;

import java.net.URL;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import jiraPojoObjects.PojoFixVersion;
import jiradcapiconnector.JiraDCApiConnector;

public class ParseJiraDcJsonFixVersion {

	public LinkedHashMap<String, PojoFixVersion> getJiraDcFixVersions(URL anApiUrl, String aLogin, boolean isBasicLogin) {
		///--List of FixVersions for the project
		LinkedHashMap<String, PojoFixVersion> fixVersions = null;
		PojoFixVersion fixVersion = null;
		StringBuilder sb = new StringBuilder();
		String fixVersionsJsonString = new JiraDCApiConnector().jiraRestApiGet(anApiUrl, aLogin, isBasicLogin);
		if (fixVersionsJsonString != null) {
			fixVersions = parseJiraFixVersionsToJson(fixVersionsJsonString);
			if (fixVersions != null) {
				for (Entry<String, PojoFixVersion> entry : fixVersions.entrySet()) {
					sb.append(entry.getKey() + ": {" + entry.getValue().getId() + " " + entry.getValue().getProjectId() + " " + entry.getValue().getName() + "}");
					sb.append("\n");
				}
			} else {
				sb.append("\n" + ": can't parse components");
			}
		} else {
			sb.append("\n" + ": components ID N/A");
		}
		System.out.print(sb); //DEBUGPRINT
		return fixVersions;
	}

	private LinkedHashMap<String, PojoFixVersion> parseJiraFixVersionsToJson(String aJson) {
		///--List of FixVersions for the project
		LinkedHashMap<String, PojoFixVersion> pojoObjects = null;
		PojoFixVersion pojoObject = null;
		if (aJson != null) {
			JSONParser parser = new JSONParser();
			JSONObject jsonObj = null;
			try {
				JSONArray jsonArr = (JSONArray) parser.parse(aJson);
				if (jsonArr != null) {
					pojoObjects = new LinkedHashMap<String, PojoFixVersion>();
					for (int ii = 0; ii < jsonArr.size(); ii++) {
						jsonObj = (JSONObject) jsonArr.get(ii);
						pojoObject = new PojoFixVersion();
						pojoObject.setId((String) jsonObj.get("id"));
						pojoObject.setSelf((String) jsonObj.get("self"));
						pojoObject.setName((String) jsonObj.get("name"));
						pojoObject.setArchived((Boolean) jsonObj.get("archived")); // "archived": false,
						pojoObject.setReleased((Boolean) jsonObj.get("released")); // "released": false,
						pojoObject.setProjectId(Integer.parseInt(jsonObj.get("projectId").toString())); // "projectId": 10300,
						pojoObjects.put(pojoObject.getId(), pojoObject);
					}
				}
			} catch (ParseException e) {
				System.out.print(e.getMessage());
			}
		}
		return pojoObjects;
	}
}
