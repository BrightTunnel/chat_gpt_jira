package utilsJsonJiraDc;

import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import jiraPojoObjects.PojoJiraIssue;
import jiraPojoObjects.PojoJiraIssueBusiness;

public class ParseJiraDcWorkItem {

	private final Character excelRn = '\n'; // --Excel Cell MultiLine eol
	private final HashSet<String> topLevelWiTypes = new HashSet<String>();
	private final String cfMalCode = "customfield_15900"; //-- TD Feature, Epic MAL Code
	private final String cfTargetEnd = "customfield_24101"; //-- TD 'Target end': '2025-10-31'
	private final String cfTeam = "customfield_19600"; //-- TD Team:	id 141177, "name": CWTICI | POD-Data Network
	private final String cfTeamName = "customfield_27301"; //-- TD Team Name: "CWTICI | POD-Data Network"
	private final String cfEpicOwner = "customfield_26900"; //-- TD Epic Owner: "name": "TAK3382", "displayName": "Lname, Fname"
	private String cfEpicName = "customfield_10007"; //-- TD Epic name
	/// private String cfParentLinkTheme = "customfield_19601"; //-- TD epic's parent: 'theme'
	/// private String cfDate0 = "customfield_11412"; //--
	/// private String cfDate1 = "customfield_27802"; //--
	/// private String cfDate2 = "customfield_27815"; //--

	///	'created'
	///	'updated'
	///	'resolutiondate'
	///	'versions []'
	///	'issuelinks []' --empty for feature
	///	'subtasks []'
	///	'summary'
	///	'description'

	public ParseJiraDcWorkItem() {
		topLevelWiTypes.add("Feature");
		topLevelWiTypes.add("Epic");
		cfEpicName = "customfield_10102"; //DEBUGLOCALHOST Lenovo
	}

	public PojoJiraIssue parseWorkItem(String aJsonString) {
		PojoJiraIssue workItem = new PojoJiraIssue();
		try {
			JSONParser parser = new JSONParser();
			JSONObject issue = (JSONObject) parser.parse(aJsonString);
			workItem = parseJiraWorkItem(issue);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return workItem;
	}

	private PojoJiraIssue parseJiraWorkItem(JSONObject issueJson) {
		StringBuilder sbBusinessErrors = new StringBuilder();
		Long issueId = Long.parseLong(issueJson.get("id").toString());
		String issueKey = (String) issueJson.get("key");
		JSONObject fields = (JSONObject) issueJson.get("fields");
		String summary = (String) fields.get("summary");
		if (summary != null && summary.contains("\"")) {
			summary = summary.replaceAll("\"", "'");
			sbBusinessErrors.append("#Warn: Dbl quote in Summary" + excelRn);
		}
		JSONObject creatorObj = (JSONObject) fields.get("creator"); //-- "creator":{"key": "JIRAUSER10100", "name":"TAK3382","displayName":"Lname, Fname"}
		JSONObject reporterObj = (JSONObject) fields.get("reporter"); //-- "reporter":{"key": "JIRAUSER10100", "name":"TAK3382","displayName":"Lname, Fname"}
		JSONObject assigneeObj = (JSONObject) fields.get("assignee"); //-- "assignee":{"key": "JIRAUSER10100", "name":"TAK3382","displayName":"Lname, Fname"}
		String creator = (String) creatorObj.get("displayName");
		String reporter = (String) reporterObj.get("displayName");
		String assignee = "";
		if (assigneeObj != null) {
			assignee = (String) assigneeObj.get("displayName");
		}
		JSONObject prKeyObj = (JSONObject) fields.get("project");
		String prKey = (String) prKeyObj.get("key");
		Date created = getDateFromString((String) fields.get("created"));
		Date updated = getDateFromString((String) fields.get("updated"));
		String targetEnd = (String) fields.get(cfTargetEnd);
		String malCode = (String) fields.get(cfMalCode); // -- MAL Code for Feature, Epic
		String epicName = (String) fields.get(cfEpicName); // --Epic Name
		if (epicName != null && epicName.contains("\"")) {
			epicName = epicName.replaceAll("\"", "'");
			sbBusinessErrors.append("#Warn: Dbl quote in EpicName" + excelRn);
		}
		JSONObject issueType = (JSONObject) fields.get("issuetype");
		String issueTypeName = (String) issueType.get("name");
		JSONObject status = (JSONObject) fields.get("status");
		String statusName = (String) status.get("name");
		String teamName = (String) fields.get(cfTeamName); //-- TD Team Name: "CWTICI | POD-Data Network"
		JSONObject teamObj = (JSONObject) fields.get(cfTeam); //-- TD Team:	id 141177, "name": CWTICI | POD-Data Network
		String team = "";
		if (teamObj != null) {
			team = (String) teamObj.get("name");
		}
		JSONObject epicOwnerObj = (JSONObject) fields.get(cfEpicOwner);
		String epicOwner = "";
		if (epicOwnerObj != null) {
			epicOwner = (String) epicOwnerObj.get("displayName"); //-- TD Epic Owner: "name": "TAK3382", "displayName": "Lname, Fname",	
		}

		///---Save primary WorkItem Values to the PojoJiraIssue
		PojoJiraIssue workItem = new PojoJiraIssue();
		PojoJiraIssueBusiness wiBusiness = new PojoJiraIssueBusiness();
		workItem.setPojoJiraIssueBusiness(wiBusiness);

		workItem.setId(issueId);
		workItem.setKey(issueKey);
		workItem.setPkey(prKey);
		workItem.setIssueType(issueTypeName);
		workItem.setCfMalCode(malCode);
		workItem.setStatus(statusName);
		workItem.setTargetEnd(targetEnd);
		workItem.setSummary(summary);
		workItem.setEpicName(epicName);
		///--Secondary informational set of columns
		workItem.setUpdated(updated); //-- '2025-06-06T08:42:08.797-0400'
		workItem.setCreated(created); //-- '2025-06-06T08:42:08.797-0400'
		workItem.setCreator(creator);
		workItem.setReporter(reporter);
		workItem.setAssignee(assignee);

		wiBusiness.setEpicOwner(epicOwner);
		if (teamName != null) {
			wiBusiness.setTeamName(teamName);
		} else {
			wiBusiness.setTeamName("");
		}
		wiBusiness.setTeam(team);
		///--Add Secondary (calculated) Values
		extractMetaData(workItem);

		/// System.out.print("\n\nissueKey: " + workItem.getIssueType() + " " + issueKey); //DEBUGPRINT

		/// -- Collect Components
		JSONArray components = (JSONArray) fields.get("components");
		if (components != null && !components.isEmpty()) {
			/// System.out.print("\n~~Components."); //DEBUGPRINT
			TreeSet<String> componentsSet = new TreeSet<>();
			for (Object compObj : components) {
				JSONObject comp = (JSONObject) compObj;
				String componentName = comp.get("name").toString();
				componentsSet.add(componentName);
			}
			workItem.setComponents(componentsSet);
		}

		/// -- Collect Fix Versions
		JSONArray fixVersions = (JSONArray) fields.get("fixVersions");
		if (fixVersions != null && !fixVersions.isEmpty()) {
			TreeSet<String> fixVersionsSet = new TreeSet<>();
			for (Object verObj : fixVersions) {
				JSONObject version = (JSONObject) verObj;
				String fixVersionsName = version.get("name").toString();
				fixVersionsSet.add(fixVersionsName);
			}
			workItem.setFixVersions(fixVersionsSet);
		}

		///-- Verify Jira cf value, report error if it has trailing spaces, or tab character
		String cleanedCfValue = checkForSyntaxErrors(workItem.getSummary(), workItem);
		workItem.setSummary(cleanedCfValue);

		cleanedCfValue = checkForSyntaxErrors(workItem.getCfMalCode(), workItem);
		workItem.setCfMalCode(cleanedCfValue);

		if (workItem.getPojoJiraIssueBusiness().getNotesAndBusinessErrors() == null || workItem.getPojoJiraIssueBusiness().getNotesAndBusinessErrors().length() == 0) {
			workItem.getPojoJiraIssueBusiness().setNotesAndBusinessErrors(sbBusinessErrors.toString());
		} else {
			workItem.getPojoJiraIssueBusiness().setNotesAndBusinessErrors(workItem.getPojoJiraIssueBusiness().getNotesAndBusinessErrors() + excelRn + sbBusinessErrors.toString());
		}

		return workItem;
	}

	public void parseEpicLinksToChildTasks(String aJsonString, PojoJiraIssue aRootWorkItem) {
		TreeMap<String, PojoJiraIssue> epicChildren = new TreeMap<String, PojoJiraIssue>();
		///System.out.print("\n~" + aRootWorkItem.getIssueType() + ":" + aRootWorkItem.getKey()); //DEBUGPRINT
		try {
			/// -- Parse the JSON file
			JSONParser parser = new JSONParser();
			JSONObject json = (JSONObject) parser.parse(aJsonString);
			/// -- Get "issues" array
			JSONArray issues = (JSONArray) json.get("issues");
			for (Object obj : issues) {
				PojoJiraIssue workItem = new PojoJiraIssue();
				JSONObject issue = (JSONObject) obj;
				workItem = parseJiraWorkItem(issue);
				epicChildren.put(workItem.getKey(), workItem);
				///System.out.print("\n\t" + workItem.getIssueType() + ":" + workItem.getKey()); //DEBUGPRINT
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		aRootWorkItem.setEpicChildren(epicChildren);
	}

	/// ============================== UTILS =======================================

	private String checkForSyntaxErrors(String aStringToCheck, PojoJiraIssue workItem) {
		///-- Verify String, if it has trailing spaces, or tab character
		String cleanedCfValue = null;
		if (aStringToCheck != null) {
			cleanedCfValue = aStringToCheck.trim();
			StringBuilder sbBusinessErrors = new StringBuilder();
			if (aStringToCheck.compareTo(cleanedCfValue) != 0) {
				sbBusinessErrors.append("#Warn: Trailing space in Summary" + excelRn);
			}
			String unWantedChar = "\t";
			if (aStringToCheck.contains(unWantedChar)) {
				sbBusinessErrors.append("#Warn: TAB in Summary" + excelRn);
				cleanedCfValue = aStringToCheck.replaceAll(unWantedChar, "");
			}
			///-- Persist error if found in PojoJiraIssue
			if (sbBusinessErrors.length() > 0) {
				sbBusinessErrors.setLength(sbBusinessErrors.length() - 1); // --trim last 'excelRn'
			}
			if (workItem.getPojoJiraIssueBusiness().getNotesAndBusinessErrors() == null || workItem.getPojoJiraIssueBusiness().getNotesAndBusinessErrors().length() == 0) {
				workItem.getPojoJiraIssueBusiness().setNotesAndBusinessErrors(sbBusinessErrors.toString());
			} else {
				workItem.getPojoJiraIssueBusiness().setNotesAndBusinessErrors(workItem.getPojoJiraIssueBusiness().getNotesAndBusinessErrors() + excelRn + sbBusinessErrors.toString());
			}
		}
		return cleanedCfValue;
	}

	private void extractMetaData(PojoJiraIssue aFeatureOrEpic) {
		if (topLevelWiTypes.contains(aFeatureOrEpic.getIssueType())) { // --Feature && Epic only. Exclude Task, Story, etc.
			String input = aFeatureOrEpic.getSummary();
			LinkedHashSet<String> metaDataList = new LinkedHashSet<>(); //-- the order of addition is maintained
			/// -- Regex: get content inside round brackets
			Pattern pattern = Pattern.compile("\\(([^)]*)\\)");
			Matcher matcher = pattern.matcher(input);
			while (matcher.find()) {
				String inside = matcher.group(1); // e.g. "Key,kEy2, KEY, DDD"
				for (String item : inside.split(",")) {
					String trimmed = item.trim();
					if (!trimmed.isEmpty()) {
						metaDataList.add(trimmed); // Normalize for case-insensitive uniqueness
					}
				}
			}
			aFeatureOrEpic.getPojoJiraIssueBusiness().setMetaDataOrigSummary(metaDataList);
			///System.out.print("\n~MetaData:" + aFeatureOrEpic.getKey() + " " + aFeatureOrEpic.getMetaData()); //DEBUGPRINT
		}
	}

	private Date getDateFromString(String aDateString) {
		/// -- "2025-04-04T21:30:32.833-0400";
		if (aDateString != null) {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
			ZonedDateTime zdt = ZonedDateTime.parse(aDateString, formatter);
			Instant instant = zdt.toInstant();
			Date date = Date.from(instant);
			return date;
		} else {
			return null;
		}
	}

}
