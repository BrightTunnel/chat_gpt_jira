package jiraPojoXml;

import java.util.HashMap;

public class PojoXmlElement {
	public PojoXmlElement() {
	}
	public PojoXmlElement(String xmlElementName) {
		this.xmlElementName = xmlElementName;
	}

	// ~~ https://www.w3schools.com/xml/xml_dtd_el_vs_attr.asp
	private String xmlElementName; // ~~ <xmlElementName -- Element names can contain letters, digits, hyphens, underscores, and periods
	private String xmlElementID; // ~~ <Element id="10114", also the attribute
	private String xmlElementText; // <price>29.99</price>
	private HashMap<String, PojoXmlAttribute> xmlAttributes; // <book attribute1='v1' attribute2='v2'>
	private HashMap<String, PojoXmlElement> xmlChildren;
	// private String xmlCData; // <description><![CDATA[~~~Descr2~~~]]></description> - [CDATA[]] belongs to Child

	// ~~ Extra ~~
	private int countElement;
	private int elementKind;
	private String fullElementXmlStringOrig; // ~~ Full line from the source file to be parsed to this xml element
	private String fullElementXmlStringDeFaced;

	// ~~~ Getters and Setters ~~~

	public String getXmlElementID() {
		return xmlElementID;
	}

	public void setXmlElementID(String xmlElementID) {
		this.xmlElementID = xmlElementID;
	}

	public String getXmlElementName() {
		return xmlElementName;
	}

	public void setXmlElementName(String xmlElementName) {
		this.xmlElementName = xmlElementName;
	}

	public String getXmlElementText() {
		return xmlElementText;
	}

	public void setXmlElementText(String xmlElementText) {
		this.xmlElementText = xmlElementText;
	}

	public String getFullElementXmlStringOrig() {
		return fullElementXmlStringOrig;
	}

	public void setFullElementXmlStringOrig(String fullElementXmlStringOrig) {
		this.fullElementXmlStringOrig = fullElementXmlStringOrig;
	}

	public int getCountElement() {
		return countElement;
	}

	public void setCountElement(int countElement) {
		this.countElement = countElement;
	}

	public int getElementKind() {
		return elementKind;
	}

	public void setElementKind(int elementKind) {
		this.elementKind = elementKind;
	}

	public HashMap<String, PojoXmlAttribute> getXmlAttributes() {
		return xmlAttributes;
	}

	public void setXmlAttributes(HashMap<String, PojoXmlAttribute> xmlAttribute) {
		this.xmlAttributes = xmlAttribute;
	}

	public HashMap<String, PojoXmlElement> getXmlChildren() {
		return xmlChildren;
	}

	public void setXmlChildren(HashMap<String, PojoXmlElement> xmlChildren) {
		this.xmlChildren = xmlChildren;
	}

	public String getFullElementXmlStringDeFaced() {
		return fullElementXmlStringDeFaced;
	}

	public void setFullElementXmlStringDeFaced(String fullElementXmlStringDeFaced) {
		this.fullElementXmlStringDeFaced = fullElementXmlStringDeFaced;
	}

	//	@Override
	//	public String toString() {
	//		return "PojoXmlElement [xmlElementName=" + xmlElementName + ", xmlElementText=" + xmlElementText + ", countElement=" + countElement + ", fullElementXmlStringOrig=" + fullElementXmlStringOrig + "]";
	//	}

}
