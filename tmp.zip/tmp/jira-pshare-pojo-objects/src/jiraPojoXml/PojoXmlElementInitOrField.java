package jiraPojoXml;

public class PojoXmlElementInitOrField {
	// From script-runner behaviour server-side <validator-script>

	//	<init validator="server">
	//		<validator-script>
	//			<script>
	//				log.debug("In-Line Script in init as field");
	//			</script>
	//			<scriptPath>tvnUtils/tvnAlterOptions.groovy</scriptPath>
	//			</>
	//		</validator-script>
	//		<validator-method>run</validator-method>
	//	</init>

	// <field validator="server" id="issuetype" 					readonly="false" hidden="false" required="false" name="Issue Type">
	// <field validator="server" id="customfield_10552" 	readonly="false" hidden="false" required="false" name="CarMakers">
	//	<field validator="server" id="customfield_10111" name="cfName">
	//		<validator-script>
	//			<script>
	//				log.debug("In-Line Script in init as field");
	//			</script>
	// 		<scriptPath>tvnUtils/BEH001-issue-type.groovy</scriptPath>
	//			<parameters/>
	//		</validator-script>
	//		<validator-method>run</validator-method>
	//	</field>

	private String extractedNodeScript; // from NODE <script/>
	private String extractedAttributeScript; // ~~ Jira 7 may have Script as ATTRIBUTE <init id="__init__" validator-script="import init-as-attribute;"/>
	private String scriptPath;
	private String parameters;
	private String validatorMethod;
	// ~~ Attributes 	
	private String fieldID; // "customfield_10500", OR: ['customfield_10500', 'comments', 'summary', 'resolution', 'description', etc]
	private Long customFieldIdLong; // "10500"
	private String behavCustomFieldName; //  This is not standard actual custom field, it's defined in behaviour.  ALSO for jira7: actual CF name mapped to the 'fieldID', populated later from list of CF when available
	private boolean readonly;
	private boolean hidden;
	private boolean required;
	private String validatorEngine; //  validator="server"/>
	private String validatorClass; // validator-class="" 
	// ~~ Extra 
	private boolean isInitOrField; // ~~ True if xml node is '<init>', false if '<field>'  ~~ <init validator="server"> OR <field validator="server" id="customfield_10111" name="cfName">

	// ~~~ Special Setters ~~~
	public void setFieldID(String fieldID) {
		this.fieldID = fieldID;
		// ~~ 'customfield_10500' >> '10500'
		final String _cfPrefix = "customfield_";
		if (fieldID != null && fieldID.startsWith(_cfPrefix)) {
			String _s = fieldID.substring(_cfPrefix.length());
			this.customFieldIdLong = Long.parseLong(_s);
		}
	}

	// ~~ Getters/Setters ~~
	
	public String getExtractedNodeScript() {
		return extractedNodeScript;
	}
	public void setExtractedNodeScript(String extractedScript) {
		this.extractedNodeScript = extractedScript;
	}

	public String getExtractedAttributeScript() {
		return extractedAttributeScript;
	}

	public void setExtractedAttributeScript(String extractedAttributeScript) {
		this.extractedAttributeScript = extractedAttributeScript;
	}

	public String getScriptPath() {
		return scriptPath;
	}
	public void setScriptPath(String scriptPath) {
		this.scriptPath = scriptPath;
	}
	public String getParameters() {
		return parameters;
	}
	public void setParameters(String parameters) {
		this.parameters = parameters;
	}
	public String getValidatorMethod() {
		return validatorMethod;
	}
	public void setValidatorMethod(String validatorMethod) {
		this.validatorMethod = validatorMethod;
	}
	public boolean isReadonly() {
		return readonly;
	}
	public void setReadonly(boolean readonly) {
		this.readonly = readonly;
	}
	public boolean isHidden() {
		return hidden;
	}
	public void setHidden(boolean hidden) {
		this.hidden = hidden;
	}
	public boolean isRequired() {
		return required;
	}
	public void setRequired(boolean required) {
		this.required = required;
	}
	public boolean isInitOrField() {
		return isInitOrField;
	}
	public void setInitOrField(boolean isInitOrField) {
		this.isInitOrField = isInitOrField;
	}
	public String getValidatorEngine() {
		return validatorEngine;
	}
	public void setValidatorEngine(String validatorEngine) {
		this.validatorEngine = validatorEngine;
	}
	public String getValidatorClass() {
		return validatorClass;
	}
	public void setValidatorClass(String validatorClass) {
		this.validatorClass = validatorClass;
	}
	public String getFieldID() {
		return fieldID;
	}

	public String getBehavCustomFieldName() {
		return behavCustomFieldName;
	}

	public void setBehavCustomFieldName(String behavCustomFieldName) {
		this.behavCustomFieldName = behavCustomFieldName;
	}

	public Long getCustomFieldIdLong() {
		return customFieldIdLong;
	}

	public void setCustomFieldIdLong(Long customFieldIdLong) {
		this.customFieldIdLong = customFieldIdLong;
	}

}
