package utilsGlobal;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;

import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import jiraConstants.ConstJiraStandardFields;
import jiraConstants.ConstJiraStandardFields.SJF;
import jiraConstants.ConstXmlElementsJiraWorkFlow.XmlWFElemt;
import jiraConstants.ConstXmlElementsJiraWorkFlow.argsToExcludeFromReport;
import jiraConstants.ConstXmlElementsJiraWorkFlow.metaToExcludeFromReport;
import jiraConstants.ConstXmlElementsJiraWorkFlow.xmlWfNodesFullList;
import jiraConstants.ConstXmlElementsJiraWorkFlow.xmlWfSection;
import jiraPojoObjects.PojoWorkflow;
import jiraPojoObjects.PojoWorkflowAction;
import jiraPojoObjects.PojoWorkflowStep;
import utilsSanitizeHtmlXmlJsonEcodeEncrypt.Base64EcodingDecoding;
import utilsSanitizeHtmlXmlJsonEcodeEncrypt.UtilsXml;

public class ParseJiraWfExportedAsXml {
	// ~~ Workflow inline Base64 encoded scripts from <workflow> ~~
	private PojoWorkflow wfObj;
	private Deque<String> lifoQueue = new ArrayDeque<>();
	private String prevElem = "";
	private String prevParent = "";
	private StringBuilder stringBuilderCollectWfDetails = new StringBuilder(""); //~~
	private StringBuilder stringBuilderDebugMissingArgs = new StringBuilder(); //~~ List of wf nodes, not liusted in hardcoded enum 
	private StringBuilder stringBuilderWfBreadcrumbs = new StringBuilder(); //~~ Parse and list all <arg> if full path to each
	private StringBuilder wfBreadcrumbsActionKey = new StringBuilder(); //~~ Full path to the action's args (not nessesar, can build just for info purpose) 
	private final XmlUtils xmlUtils = new XmlUtils();

	// issuelinks /// SELECT id, propertyvalue FROM public.propertytext where propertyvalue like '%Linked Issues%';
	// fixVersions /// SELECT * FROM public."AO_C77861_AUDIT_ENTITY" where "CHANGE_VALUES" like '%Fix Version/s%';

	public final PojoWorkflow parseWorkflowXmlObject(String aWorkflowString, StringBuilder stringBuilderWfBreadcrumbs) {
		///~~ Parse One Single Workflow, extract and Base64 decode GroovyScripts
		///~~ 'aWorkflowString' must be full Workflow Element <workflow>...</workflow>
		///~~ This method goes from the Root <workflow> down to all branches with potential Scripts. Need to follow the current WF xml document hierarchy.
		///~~ Save and provide to the caller all Found WF Statuses to the 'List<String> aWfSteps'
		wfObj = new PojoWorkflow();
		LinkedHashMap<String, LinkedHashMap<String, PojoWorkflowStep>> wfTopXmlSegments = new LinkedHashMap<String, LinkedHashMap<String, PojoWorkflowStep>>();
		wfObj.setWfTopXmlSegments(wfTopXmlSegments);

		if (stringBuilderWfBreadcrumbs == null) {
			stringBuilderWfBreadcrumbs = new StringBuilder();
		}

		LinkedHashMap<String, PojoWorkflowAction> wfActions = new LinkedHashMap<String, PojoWorkflowAction>();

		if (aWorkflowString != null && aWorkflowString.trim().length() > 0) {
			//<?xml version="1.0" encoding="UTF-8"?>
			//<!DOCTYPE workflow PUBLIC "-//OpenSymphony Group//DTD OSWorkflow 2.8//EN" "http://www.opensymphony.com/osworkflow/workflow_2_8.dtd">
			//<workflow>
			//  <meta name="jira.description">Task Management workflow</meta>
			//  <meta name="jira.update.author.key">JIRAUSER10000</meta>
			//  <meta name="jira.updated.date">1696639678812</meta>
			/// <meta name="jira.i18n.description" />
			/// <meta name="sd.workflow.key">sdItSupport</meta>
			//  <initial-actions>...
			///~~ Remove two top lines from xml export file if they are present: 
			if (aWorkflowString.startsWith("<?xml ")) {
				aWorkflowString = aWorkflowString.substring(aWorkflowString.indexOf("<workflow>"));
			}

			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			Document document = UtilsXml.convertStringToXMLDocument(aWorkflowString);
			Node rootNode = document.getDocumentElement();

			///~~~ Collect all <workflow/> elements 
			Element rootElement = document.getDocumentElement();
			///~~ Call the function with the root node: To use the function, you can call it with the root element of your XML document. For example, to get nodes at level 2:
			List<Node> wfTopSegments = xmlUtils.getNodesAtLevel(rootElement, 2, 1); //~~WF Top level XML segments: [meta, initial-actions, global-actions, common-actions, steps]
			for (Node wfTopSegment : wfTopSegments) {
				///~~ Loop at Level2 of <workflow> segments
				String wfTopSegmentTextContent = wfTopSegment.getTextContent();
				NamedNodeMap wfTopSegmentAttributes = wfTopSegment.getAttributes();
				Node wfTopSegmentAttributeName = wfTopSegmentAttributes.getNamedItem(XmlWFElemt.name.getEnumStr());

				wfBreadcrumbsActionKey = new StringBuilder(); //~~ Reset the full URI as a key
				wfBreadcrumbsActionKey.append(wfTopSegment.getNodeName());

				switch (wfTopSegment.getNodeName()) {
					case "meta" : //~~WF Segments <meta> -- Doesn't have Actions!
						///~~~ Root Second Level Elements <meta> are on the plain second level, easy to loop, and are part of the main external
						///~~ For multiple Segments <meta> - use special KEY, combined from keyword 'meta.' and the node name (e.g.<meta name="jira.description">process-management-workflow</meta>)
						wfObj.getWfTopXmlSegments().put(wfTopSegment.getNodeName() + "." + wfTopSegmentAttributeName.getNodeValue(), null);
						String closingTag0;
						if (wfTopSegmentTextContent != null && wfTopSegmentTextContent.length() > 0) {
							closingTag0 = ">" + wfTopSegmentTextContent + "</" + wfTopSegment.getNodeName() + ">";
						} else {
							closingTag0 = "/>";
						}
						if (!isMetaMustBeExcluded(wfTopSegmentAttributeName.getNodeValue())) {
							stringBuilderCollectWfDetails.append("\n<meta " + wfTopSegmentAttributeName + closingTag0); // <meta name="jira.description">BSSD Software Approval Workflow</meta>
						}
						if (wfTopSegmentAttributeName.getTextContent().compareTo(xmlWfNodesFullList.jiraDescription.getEnumStr()) == 0) {
							wfObj.setMetaJiraDescription(wfTopSegmentTextContent);
							/// System.out.print("\n~1a. inside the wf parser, found WF xml <meta JiraDescription: '" + wfTopSegmentTextContent + "'"); //DEBUGPRINT print for debugging only
						} else if (wfTopSegmentAttributeName.getTextContent().compareTo(xmlWfNodesFullList.jiraUpdateAuthorKey.getEnumStr()) == 0) {
							wfObj.setMetaJiraUpdateAuthorKey(wfTopSegmentTextContent);
						} else if (wfTopSegmentAttributeName.getTextContent().compareTo(xmlWfNodesFullList.jiraUpdatedDate.getEnumStr()) == 0) {
							wfObj.setMetaJiraUpdatedDate(wfTopSegmentTextContent);
						}
						break;

					case "initial-actions" : //~~WF Segment <initial-actions>
						stringBuilderCollectWfDetails.append("\n<initial-actions>"); //DEBUGPRINT
						loopActionsInTheTopWfSegment(wfObj, wfTopSegment);
						break;
					case "global-actions" : //~~WF Segment <global-actions>
						stringBuilderCollectWfDetails.append("\n<global-actions>"); //DEBUGPRINT
						loopActionsInTheTopWfSegment(wfObj, wfTopSegment);
						break;
					case "common-actions" : //~~WF Segment <common-actions>
						stringBuilderCollectWfDetails.append("\n<common-actions>"); //DEBUGPRINT
						loopActionsInTheTopWfSegment(wfObj, wfTopSegment);
						break;

					case "steps" : //~~WF Segment <steps>
						///~~ Found New Segment <steps>, so create an new object and add it to the WF Object:
						LinkedHashMap<String, PojoWorkflowStep> segmentSteps = new LinkedHashMap<String, PojoWorkflowStep>();
						wfTopXmlSegments.put("steps", segmentSteps);
						///~~~
						stringBuilderCollectWfDetails.append("\n<steps>"); //DEBUGPRINT
						List<Node> nodesAtLevel3Steps = xmlUtils.getNodesAtLevel(wfTopSegment, 2, 1);

						///~~ Loop <step>s in <steps> 
						for (Node nodeAtLevel3Step : nodesAtLevel3Steps) {
							NamedNodeMap attributesStep = nodeAtLevel3Step.getAttributes();
							Node atrNameStep = attributesStep.getNamedItem(XmlWFElemt.name.getEnumStr()); // <step id="1" name="Open">
							Node atrIDStep = attributesStep.getNamedItem(XmlWFElemt.id.getEnumStr()); // <step id="1" name="Open">

							///~~Found New <step>, so create object to hold it
							PojoWorkflowStep theStep = new PojoWorkflowStep();
							theStep.setStepId(Long.parseLong(atrIDStep.getNodeValue()));
							theStep.setStepName(atrNameStep.getNodeValue());
							segmentSteps.put(atrNameStep.getNodeValue(), theStep);

							stringBuilderCollectWfDetails.append("\n\t<" + nodeAtLevel3Step.getNodeName() + " " + atrIDStep + " " + atrNameStep + ">");
							///~~
							wfBreadcrumbsActionKey.append("/" + nodeAtLevel3Step.getNodeName());
							switch (nodeAtLevel3Step.getNodeName()) {
								case "step" :
									///stringBuilderCollectWfDetails.append("\n\t<action>"); //DEBUGPRINT
									List<Node> nodesAtLevel4StepActionTypes = xmlUtils.getNodesAtLevel(nodeAtLevel3Step, 2, 1);
									for (Node nodesAtLevel4ActionType : nodesAtLevel4StepActionTypes) { // <validators>, <results>,...
										String textContentLvl3 = nodesAtLevel4ActionType.getTextContent();
										NamedNodeMap attributesActionType = nodesAtLevel4ActionType.getAttributes();
										Node attrNameActionType = attributesActionType.getNamedItem(XmlWFElemt.name.getEnumStr());
										Node attrIDActionType = attributesActionType.getNamedItem(XmlWFElemt.id.getEnumStr());
										///~~ Report
										String attrNameStepActionBuilt = "";
										if (attrNameActionType != null) {
											attrNameStepActionBuilt = " " + attrNameActionType.getNodeName() + "=\"" + attrNameActionType.getNodeValue() + "\"";
										}
										String closingTag1;
										if (attrNameStepActionBuilt.length() > 0) {
											closingTag1 = "></" + nodesAtLevel4ActionType.getNodeName() + ">";
										} else {
											closingTag1 = ">";
										}
										///~~
										wfBreadcrumbsActionKey.append("/" + nodesAtLevel4ActionType.getNodeName());
										switch (nodesAtLevel4ActionType.getNodeName()) {
											///	<step id="5" name="DONE">
											/// 		<meta name="jira.status.id">10001</meta>
											///			<actions>
											///				<action id="151" name="wfTransition01">
											case "meta" : // e.g. (the only meta for <step> I think) <meta name="jira.status.id">10001</meta>
												String jiraStatusIdValue = nodesAtLevel4ActionType.getTextContent(); // e.g.: "10001" from: <meta name="jira.status.id">10001</meta>
												NamedNodeMap attributesJiraStatusId = nodesAtLevel4ActionType.getAttributes();
												Node jiraStatusIdName = attributesJiraStatusId.getNamedItem(XmlWFElemt.name.getEnumStr());
												if (jiraStatusIdName.getNodeValue().compareTo(xmlWfNodesFullList.jiraStatusId.getEnumStr()) == 0) {
													LinkedHashMap<String, PojoWorkflowStep> _steps = wfObj.getWfTopXmlSegments().get("steps");
													PojoWorkflowStep _step = _steps.get(atrNameStep.getNodeValue()); // atrNameStep.getNodeValue() = "DONE" from: <step id="5" name="DONE">
													_step.setIssuestatusID(jiraStatusIdValue);
												}
												if (!isMetaMustBeExcluded(attrNameActionType.getNodeValue())) {
													stringBuilderCollectWfDetails.append("\n\t\t<" + nodesAtLevel4ActionType.getNodeName() + attrNameStepActionBuilt + closingTag1);
												}
												break;
											case "actions" :
												stringBuilderCollectWfDetails.append("\n\t\t<" + nodesAtLevel4ActionType.getNodeName() + attrNameStepActionBuilt + closingTag1);
												List<Node> nodesAtLevel5StepsAction = xmlUtils.getNodesAtLevel(nodesAtLevel4ActionType, 2, 1);
												///~~Loop actions
												for (Node nodeAtLevel5ActionValidator : nodesAtLevel5StepsAction) {
													NamedNodeMap attributesActionValidatorType = nodeAtLevel5ActionValidator.getAttributes();
													Node attrNameActionValidatorType = attributesActionValidatorType.getNamedItem(XmlWFElemt.name.getEnumStr());
													Node attrIDActionIDhere = attributesActionValidatorType.getNamedItem(XmlWFElemt.id.getEnumStr());
													Node attrIDActionValidatorType = attributesActionValidatorType.getNamedItem(XmlWFElemt.type.getEnumStr());
													///~~ Report
													String attrIDActionIDDetails = "";
													if (attrIDActionIDhere != null) {
														attrIDActionIDDetails = " " + attrIDActionIDhere.getNodeName() + "=\"" + attrIDActionIDhere.getNodeValue() + "\"";
													}
													String attrIDActionNameDetails = "";
													if (attrNameActionValidatorType != null) {
														attrIDActionNameDetails = " " + attrNameActionValidatorType.getNodeName() + "=\"" + attrNameActionValidatorType.getNodeValue() + "\"";
													}
													stringBuilderCollectWfDetails.append("\n\t\t\t<" + nodeAtLevel5ActionValidator.getNodeName() + attrIDActionIDDetails + attrIDActionNameDetails + "/>");
													///~~
													wfBreadcrumbsActionKey.append("/" + nodeAtLevel5ActionValidator.getNodeName());
													switch (nodeAtLevel5ActionValidator.getNodeName()) {
														/// case "initial-actions" : //~~ Not it <steps>
														/// case "global-actions" : //~~ Not it <steps>
														case "common-action" :
															parseAction(theStep, wfTopSegment, nodeAtLevel5ActionValidator, "\t\t");
															break;
														case "action" :
															parseAction(theStep, wfTopSegment, nodeAtLevel5ActionValidator, "\t\t");
															break;
														default :
															System.err.print("\n~~WARN03: node <steps-step-actions-action><" + nodeAtLevel5ActionValidator.getNodeName() + "> is not parsed!"); //DEBUGPRINT
													}
													wfBreadcrumbsActionKey = wfUriBreadcrumbsActionKeyStepUp(wfBreadcrumbsActionKey, nodeAtLevel5ActionValidator.getNodeName());
												}
												break;
											default :
												System.err.print("\n~~WARN04: node <steps-step-action><" + nodesAtLevel4ActionType.getNodeName() + "> is not parsed!"); //DEBUGPRINT
										}
										wfBreadcrumbsActionKey = wfUriBreadcrumbsActionKeyStepUp(wfBreadcrumbsActionKey, nodesAtLevel4ActionType.getNodeName());
									}
									break;
								default :
									System.err.print("\n~~WARN05: node <steps><" + nodeAtLevel3Step.getNodeName() + "> is not parsed!"); //DEBUGPRINT
							}
							wfBreadcrumbsActionKey = wfUriBreadcrumbsActionKeyStepUp(wfBreadcrumbsActionKey, nodeAtLevel3Step.getNodeName());
						} //~~rof
						break;
					default :
						System.err.print("\n~~WARN06: Level 2 wf xtml Section <" + wfTopSegment.getNodeName() + "> is not listed!"); //DEBUGPRINT
				}
			}
			stringBuilderWfBreadcrumbs.append("\n\n<!-- WORKFLOW: '" + wfObj.getMetaJiraDescription() + "' by " + wfObj.getMetaJiraUpdateAuthorKey() + " updated on " + wfObj.getMetaJiraUpdatedDate() + "-->");

			surfNode(rootNode, rootNode);

			///~~~ Read xml Document from a FILE ~~~
			//			docFactory.setNamespaceAware(true);
			//			try {
			//				DocumentBuilder builder = docFactory.newDocumentBuilder();
			//				Document document = builder.parse("a.xml");
			//			} catch (ParserConfigurationException | SAXException | IOException e) {
			//			}

			///~~~  OR Read xml document from a String ~~~

		}

		//System.out.print("\n" + stringBuilderCollectWfDetails);
		//System.out.print("\n\n~~~~~~~~~~~~" + stringBuilderDebugMissingArgs);
		// System.out.print("\n\n~~~~~~~~~~~~" + stringBuilderWfBreadcrumbs);
		//System.exit(0);

		return wfObj;
	}

	private final void loopActionsInTheTopWfSegment(PojoWorkflow wfObj, Node wfTopSegment) {
		/// ~Loop Top level WF XML segments: [meta, initial-actions, global-actions, common-actions, steps]
		//String textContentMeta = wfTopSegment.getTextContent();

		///~~ Create artificial set of <steps.step> objecs to maintain general WF holder structure:
		PojoWorkflowStep theStep = new PojoWorkflowStep();
		theStep.setStepId(-1L);
		theStep.setStepName("N/A for " + wfTopSegment.getNodeName());
		LinkedHashMap<String, PojoWorkflowStep> segmentSteps = new LinkedHashMap<String, PojoWorkflowStep>();
		segmentSteps.put(theStep.getStepName(), theStep);
		wfObj.getWfTopXmlSegments().put(wfTopSegment.getNodeName(), segmentSteps);

		//~~
		List<Node> nodesAtLevel3InitialActions = xmlUtils.getNodesAtLevel(wfTopSegment, 2, 1);
		//~~Loop WF Segment Elements/Actions: []
		for (Node nodeAtLevel3Action : nodesAtLevel3InitialActions) { //~~ Loop Level3:
			NamedNodeMap attributesInitAction = nodeAtLevel3Action.getAttributes();
			Node atrNameInitAction = attributesInitAction.getNamedItem(XmlWFElemt.name.getEnumStr()); // name="Create"
			Node atrIDInitAction = attributesInitAction.getNamedItem(XmlWFElemt.id.getEnumStr()); // id="1"

			stringBuilderCollectWfDetails.append("\n\t<" + nodeAtLevel3Action.getNodeName() + " " + atrIDInitAction + " " + atrNameInitAction + ">");

			wfBreadcrumbsActionKey.append("/" + nodeAtLevel3Action.getNodeName());
			switch (nodeAtLevel3Action.getNodeName()) {
				//				case "common-action" :
				//					parseAction(theStep, wfTopSegment, nodeAtLevel3Action, "");
				//					break;
				case "action" :
					parseAction(theStep, wfTopSegment, nodeAtLevel3Action, "");
					break;
				default :
					System.err.print("\n~~WARN02: node <" + nodeAtLevel3Action.getNodeName() + "> is not parsed!"); //DEBUGPRINT
			}
			wfBreadcrumbsActionKey = wfUriBreadcrumbsActionKeyStepUp(wfBreadcrumbsActionKey, nodeAtLevel3Action.getNodeName());
		}
	}

	private final void parseAction(PojoWorkflowStep theStep, Node wfTopSegment, Node nodeAtLevel3Action, String anIndent) {
		///	condition: <!-- restrict-to.conditions.condition --> //  <conditions type="OR"> <condition type="class"> 
		///	validator: <!-- validators.validator -->
		///	function: <!-- results.unconditional-result.post-functions.function --> //<unconditional-result old-status="Finished" status="Open" step="8"><function type="class"> 	

		NamedNodeMap actionAttrs = nodeAtLevel3Action.getAttributes();
		Node actionId = actionAttrs.getNamedItem(XmlWFElemt.id.getEnumStr()); // id="1"
		Node actionName = actionAttrs.getNamedItem(XmlWFElemt.name.getEnumStr()); // name="Create"
		PojoWorkflowAction actnHost = new PojoWorkflowAction();
		actnHost.setActionId(Long.parseLong(actionId.getNodeValue()));
		if (actionName != null) {
			actnHost.setActionName(actionName.getNodeValue());
			///System.out.println("~~~ Action:" + actionName.getNodeValue()); //DEBUGPRINT
		} else {
			actnHost.setActionName(null); //~~ e.g.: '<streps><step><actions><common-action id="71" />' 
			///System.err.println("\n~~ERR_WF007: 'actionName'==null for 'actionId': " + actionId.getNodeValue()); //DEBUGPRINT
		}

		/// System.out.print("\n~" + argName); /// out: ~name="Create", from: 
		///	<initial-actions>
		///		<action id="1" name="Create">
		///			<validators>

		ArrayList<PojoWorkflowAction> workflowActions = theStep.getWorkflowActions();
		if (workflowActions == null) {
			workflowActions = new ArrayList<>();
			theStep.setWorkflowActions(workflowActions);
		}

		List<Node> nodesAtLevel4ActionTypes = xmlUtils.getNodesAtLevel(nodeAtLevel3Action, 2, 1); //~~ List [restrict-to, validators, results]
		for (Node nodesAtLevel4ActionType : nodesAtLevel4ActionTypes) { // <validators>, <results>,...
			NamedNodeMap attributes = nodesAtLevel4ActionType.getAttributes();
			Node attrID = attributes.getNamedItem(XmlWFElemt.id.getEnumStr());
			Node attrName = attributes.getNamedItem(XmlWFElemt.name.getEnumStr());
			wfBreadcrumbsActionKey.append("/" + nodesAtLevel4ActionType.getNodeName());

			switch (nodesAtLevel4ActionType.getNodeName()) {
				case "meta" :
					if (!isMetaMustBeExcluded(attrName.getNodeValue())) {
						stringBuilderCollectWfDetails.append("\n\t\t" + anIndent + "<" + nodesAtLevel4ActionType.getNodeName() + " " + attrName + "/>");
					}
					break;
				case "restrict-to" :
					stringBuilderCollectWfDetails.append("\n\t\t" + anIndent + "<" + nodesAtLevel4ActionType.getNodeName() + ">");
					exctractScriptFromWfNodeRestrictTo(workflowActions, actnHost, nodesAtLevel4ActionType);
					break;
				case "validators" :
					stringBuilderCollectWfDetails.append("\n\t\t" + anIndent + "<" + nodesAtLevel4ActionType.getNodeName() + ">");
					exctractScriptFromWfNodeValidators(workflowActions, actnHost, nodesAtLevel4ActionType);
					break;
				case "results" : //~~ Postfunctions
					stringBuilderCollectWfDetails.append("\n\t\t" + anIndent + "<" + nodesAtLevel4ActionType.getNodeName() + ">");
					exctractScriptFromWfNodeResults(workflowActions, actnHost, nodesAtLevel4ActionType);
					break;
				default :
					System.err.print("\n~~WARN01: node <initial-actions-action><" + nodesAtLevel4ActionType.getNodeName() + "> is not parsed!"); //DEBUGPRINT
			}
			wfBreadcrumbsActionKey = wfUriBreadcrumbsActionKeyStepUp(wfBreadcrumbsActionKey, nodesAtLevel4ActionType.getNodeName());
		}
	}

	private final void exctractScriptFromWfNodeRestrictTo(ArrayList<PojoWorkflowAction> wfActions, PojoWorkflowAction actnHost, Node aWfNodeResults) {
		///	condition: <!-- restrict-to.conditions.condition -->
		List<Node> nodeRestrictTo = xmlUtils.getNodesAtLevel(aWfNodeResults, 2, 1);
		if (nodeRestrictTo.size() > 0) {
			List<Node> nodeConditions = xmlUtils.getNodesAtLevel(nodeRestrictTo.get(0), 2, 1);
			///~~ NOTE: 'conditions' may be NESTED: <conditions><conditions><condition>
			///~~TODO - iterate till found all final objects <condition>
			wfBreadcrumbsActionKey.append("/restrict-to");
			wfBreadcrumbsActionKey.append("/conditions");
			exctractScriptFromAnyTerminalActionNode(wfActions, nodeConditions, actnHost, null, ""); // condition
		}
	}

	private final void exctractScriptFromWfNodeValidators(ArrayList<PojoWorkflowAction> wfActions, PojoWorkflowAction actnHost, Node aWfNodeValidators) {
		///	validator: <!-- validators.validator -->
		List<Node> nodeValidators = xmlUtils.getNodesAtLevel(aWfNodeValidators, 2, 1);
		exctractScriptFromAnyTerminalActionNode(wfActions, nodeValidators, actnHost, null, ""); // validator
	}

	private final void exctractScriptFromWfNodeResults(ArrayList<PojoWorkflowAction> wfActions, PojoWorkflowAction actnHost, Node aWfNodeResults) {
		///	function: <!-- results.unconditional-result.post-functions.function -->		
		List<Node> nodeResults = xmlUtils.getNodesAtLevel(aWfNodeResults, 2, 1);
		///~~ Exctract This Action/Transition Target WF Step/Status: 
		Node nodeResult = nodeResults.get(0); //~~ Should be one element <unconditional-result old-status="null" status="null" step="2">, so take this first and only Node.
		NamedNodeMap nodeResultAttributes = nodeResult.getAttributes();
		Node wfNextStep = nodeResultAttributes.getNamedItem(XmlWFElemt.step.getEnumStr()); // <unconditional-result old-status="null" status="null" step="2">
		Node wfOldStatus = nodeResultAttributes.getNamedItem(XmlWFElemt.oldStatus.getEnumStr()); // <unconditional-result old-status="null" status="null" step="2">
		Node wfStatus = nodeResultAttributes.getNamedItem(XmlWFElemt.status.getEnumStr()); // <unconditional-result old-status="null" status="null" step="2">
		PojoWorkflowAction actnTarget = new PojoWorkflowAction();
		actnTarget.setActionTransitionTargetStepID(wfNextStep.getNodeValue());

		List<Node> nodeUnconditionalResult = xmlUtils.getNodesAtLevel(nodeResults.get(0), 2, 1);
		List<Node> nodePostFunctions = xmlUtils.getNodesAtLevel(nodeUnconditionalResult.get(0), 2, 1);
		wfBreadcrumbsActionKey.append("/unconditional-result");
		wfBreadcrumbsActionKey.append("/post-functions");
		exctractScriptFromAnyTerminalActionNode(wfActions, nodePostFunctions, actnHost, actnTarget, "\t\t"); // function

	}

	private final void exctractScriptFromAnyTerminalActionNode(ArrayList<PojoWorkflowAction> wfActions, List<Node> nodesTerminalAction, PojoWorkflowAction actnHost, PojoWorkflowAction actnTarget, String anIndent) {

		for (Node terminalActionNode : nodesTerminalAction) {
			///~~ 'Action' might be one of the listed below: 
			///	condition: <!-- restrict-to.conditions.condition -->
			///	validator: <!-- validators.validator -->
			///	function: <!-- results.unconditional-result.post-functions.function --> 

			String actionKind = terminalActionNode.getNodeName();
			actionKind = wfBreadcrumbsActionKey.toString() + "/" + actionKind;
			PojoWorkflowAction workflowTerminalAction = new PojoWorkflowAction();
			workflowTerminalAction.setArgs(new LinkedHashMap<String, String>());
			workflowTerminalAction.setTerminalActionKind(actionKind); // one of : [condition, validator, function]
			if (actnHost != null) {
				workflowTerminalAction.setActionId(actnHost.getActionId());
				workflowTerminalAction.setActionName(actnHost.getActionName());
			}
			boolean isValidFunctionType = false;
			for (xmlWfSection type : xmlWfSection.values()) {
				if (terminalActionNode.getNodeName().compareTo(type.getEnumStr()) == 0) {
					isValidFunctionType = true;
				}
			}
			if (isValidFunctionType) {
				NamedNodeMap attributesFunctionType = terminalActionNode.getAttributes();
				Node attrFunctionName = attributesFunctionType.getNamedItem(XmlWFElemt.name.getEnumStr());
				Node attrFunctionType = attributesFunctionType.getNamedItem(XmlWFElemt.type.getEnumStr());

				if (attrFunctionName != null) {
					workflowTerminalAction.setTerminalActionName(attrFunctionName.getNodeValue());
				}
				if (attrFunctionType != null) {
					workflowTerminalAction.setTerminalActionType(attrFunctionType.getNodeValue());
				}

				if (actnTarget != null) {
					workflowTerminalAction.setActionTransitionTargetStepID(actnTarget.getActionTransitionTargetStepID());
					actnTarget = null;
				}

				///~~Report
				String funcName = "";
				if (attrFunctionName != null) {
					funcName = attrFunctionName.getNodeName() + "=\"" + attrFunctionName.getNodeValue() + "\" ";
				}
				stringBuilderCollectWfDetails.append("\n\t\t\t" + anIndent + "<" + terminalActionNode.getNodeName() + " " + funcName + "" + attrFunctionType + ">"); //DEBUGPRINT

				///~~<function type="class"><arg ... 
				///~~Loop all <arg>s    
				List<Node> nodeArgs = xmlUtils.getNodesAtLevel(terminalActionNode, 2, 1);
				for (Node args : nodeArgs) {
					String textContent = args.getTextContent();
					NamedNodeMap argsAttrs = args.getAttributes();
					Node argName = argsAttrs.getNamedItem(XmlWFElemt.name.getEnumStr());
					textContent = Base64EcodingDecoding.decodeB64(textContent, true);
					///System.out.print("\n~textContent: " + textContent);

					///~~ Populate WF Detailes
					LinkedHashMap<String, String> hm = workflowTerminalAction.getArgs();
					boolean isArgMustBeExcluded = false;
					if (argName != null) {
						isArgMustBeExcluded = isArgMustBeExcluded(argName.getNodeValue());
						if (!isArgMustBeExcluded) {
							for (xmlWfNodesFullList type : xmlWfNodesFullList.values()) {
								if (argName.getNodeValue().compareTo(type.getEnumStr()) == 0) {
									hm.put(argName.getNodeValue(), Base64EcodingDecoding.decodeB64(textContent, true));
								}
							}
						}
						isArgAccountedFor(argName.getNodeValue());
					}

					if (!isArgMustBeExcluded) {
						String closingTag;
						if (textContent != null) {
							closingTag = ">" + textContent + "</" + args.getNodeName() + ">";
						} else {
							closingTag = "/>";
						}
						stringBuilderCollectWfDetails.append("\n\t\t\t\t" + anIndent + "<" + args.getNodeName() + " " + argName + closingTag); //DEBUGPRINT	
					}

				}
			} else {
				System.err.print("\n~~WARN000: Final wf xml action '" + terminalActionNode.getNodeName() + "' is not harcoded. Coder! Add it to the enum."); //DEBUGPRINT
			}
			wfActions.add(workflowTerminalAction);
		}
	}

	private final StringBuilder wfUriBreadcrumbsActionKeyStepUp(StringBuilder wfBreadcrumbsActionKey, String aNodeName) {
		///~~ Step level up back, so prepare parent node for the next sibling:
		///System.out.print("\n\t~1 " + wfBreadcrumbsActionKey);
		String wfBreadcrumbsActionKeyStr = wfBreadcrumbsActionKey.toString();
		int idx = wfBreadcrumbsActionKeyStr.indexOf("/" + aNodeName);
		if (idx > 0) {
			wfBreadcrumbsActionKeyStr = wfBreadcrumbsActionKeyStr.substring(0, idx);
			wfBreadcrumbsActionKey = new StringBuilder(wfBreadcrumbsActionKeyStr);
		}
		///System.out.print("\n\t~2 " + wfBreadcrumbsActionKey + "\tLESS:'" + aNodeName + "'");
		return wfBreadcrumbsActionKey;
	}

	private final boolean isArgAccountedFor(String anArgToCheck) {
		///~~ Check if this WF xml Node Name already listed in my hardcoded enum list of all found WF Nodes so far.
		///~~ If this function returns false, add this new found unlisted <arg > or other? xml Nodes to the enum list 'xmlWfNodesFullList' 
		boolean isArgFoundInTheList = false;
		for (xmlWfNodesFullList type : xmlWfNodesFullList.values()) {
			if (anArgToCheck.compareTo(type.getEnumStr()) == 0) {
				isArgFoundInTheList = true;
			}
		}
		if (!isArgFoundInTheList) {
			stringBuilderDebugMissingArgs.append("\n" + anArgToCheck);
			System.err.print("\n~~WARN10: <arg name: '" + anArgToCheck + "'> is not listed!"); //DEBUGPRINT
		}
		return isArgFoundInTheList;
	}

	private final boolean isArgMustBeExcluded(String anArgToCheck) {
		boolean isArgFoundInTheList = false;
		for (argsToExcludeFromReport type : argsToExcludeFromReport.values()) {
			if (anArgToCheck.compareTo(type.getEnumStr()) == 0) {
				isArgFoundInTheList = true;
			}
		}
		if (isArgFoundInTheList) {
			//System.err.print("\n~~WARN12: <arg name: '" + anArgToCheck + "'> must NOT be reported!"); //DEBUGPRINT
		}
		return isArgFoundInTheList;
	}

	private final boolean isMetaMustBeExcluded(String aMetaToCheck) {
		boolean isArgFoundInTheList = false;
		for (metaToExcludeFromReport type : metaToExcludeFromReport.values()) {
			if (aMetaToCheck.compareTo(type.getEnumStr()) == 0) {
				isArgFoundInTheList = true;
			}
		}
		return isArgFoundInTheList;
	}

	private final String isCSFieldOrFocusKeyWordsPresent(String aString) {
		String fieldFound = "";
		if (aString != null) {
			aString = aString.trim().toLowerCase();
			///~~ In Focus extra key words
			String inFocus = isFocusOnKeyWords(aString);
			if (inFocus.length() > 0) {
				return "~{inFocus: " + inFocus + "}";
			}
			///~~ Jira Custom Fields
			if (aString.contains("customfield_")) {
				try {
					///~~ Note: if string contais more than one 'customfield_', it will found only the first one:  
					fieldFound = aString.substring(aString.indexOf("customfield_"), aString.indexOf("customfield_") + "customfield_10999".length());
				} catch (Exception e) {
					System.err.print("\n~~ERR_WF006 Wrong index of substring 'customfield_' in: " + aString);
					fieldFound = "";
				}
				return fieldFound;
			} else {
				///~~ Jira System Fields
				for (SJF xmlAttributeName : ConstJiraStandardFields.SJF.values()) {
					if (false //~~formatting if
							|| aString.contains(xmlAttributeName.toString().toLowerCase()) // e.g. 'fixVersions'
							|| aString.contains(xmlAttributeName.getEnumStr()) // e.g. 'Fix Version/s'
					) {
						if (!isException(xmlAttributeName.getEnumStr())) {
							return xmlAttributeName.getEnumStr();
						}
					}
				}
			}
		}
		return fieldFound;
	}

	private final boolean isException(String aString) {
		boolean isTrue = false;
		if (aString != null) {
			if (false // 
					|| aString == ConstJiraStandardFields.SJF.key.getEnumStr() //
					|| aString == ConstJiraStandardFields.SJF.status.getEnumStr() // e.g.may be found here: workflowupdateissuestatus
					|| aString == ConstJiraStandardFields.SJF.IssueFunction.getEnumStr() // e.g.may be found here: ch.beecom.jira.jsu.workflow.function.createlinkedissue.CreateLinkedIssueFunction
					|| aString == ConstJiraStandardFields.SJF.Source.getEnumStr() // e.g.may be found here: scopeSource-jql
					|| aString == ConstJiraStandardFields.SJF.attachment.getEnumStr() // e.g.may be found here: transitionAttachmentsOperation
					|| aString == ConstJiraStandardFields.SJF.issuetype.getEnumStr() // e.g.may be found here: targetIssueTypeDefinedByCfSelection
			) {
				return true; //~~ it is exception
			}
		}
		return isTrue;
	}

	private final String isFocusOnKeyWords(String aString) {
		HashSet<String> keyWords = new HashSet();
		keyWords.add("com.googlecode.jsu"); // <arg name="class.name">com.googlecode.jsu.workflow.condition.ValueFieldCondition</arg>
		keyWords.add("ch.beecom.jira.jsu"); // <arg name="class.name">ch.beecom.jira.jsu.workflow.condition.userisinanyusers.UserIsInAnyUsersCondition</arg>
		// <arg name="class.name">com.googlecode.jsu.workflow.condition.UserIsInAnyGroupsCondition</arg>
		// <arg name="class.name">ch.beecom.jira.jsu.workflow.condition.userisinanyusers.UserIsInAnyUsersCondition</arg>
		keyWords.add("jsu.workflow.condition"); // present if first two in place 
		keyWords.add("com.atlassian.jira.workflow.function.issue.UpdateIssueFieldFunction"); // <arg name="class.name">com.atlassian.jira.workflow.function.issue.UpdateIssueFieldFunction</arg>
		StringBuilder ret = new StringBuilder();
		keyWords.forEach(keyWord -> {
			if (aString.contains(keyWord)) {
				ret.append(keyWord + ", ");
			}
		});
		String rern = ret.toString();
		if (rern.length() > 0) {
			rern = "~[keyWords: " + rern + "]";
		}
		return rern;
	}

	private final void surfNode(Node node, Node parentNode) {
		boolean isPrintAllElementsArg = true;
		parentNode = node.getParentNode();
		///~~Print initial / previous status
		///System.out.print("\nPrev: <" + prevParent + "/" + prevElem + "> "); 
		///System.out.print("\nNow: <" + parentNode.getNodeName() + "/" + node.getNodeName() + "> " + lifoQueue.toString());
		if (prevParent == parentNode.getNodeName()) {
			///~~ The Same level
			if (prevElem == node.getNodeName()) {
				///~~ The Same element type (e.g. <meta>)
			} else {
				///~~ New element type at the same level
				if (!lifoQueue.isEmpty()) {
					///~~ Remove previous element type 
					lifoQueue.removeFirst();
				}
				//~~ Add new element type at the same level 
				lifoQueue.addFirst(node.getNodeName());
			}
		} else {
			///~~Different level
			///~~ Goind up till found current Parent
			for (String element : lifoQueue) {
				if (element != parentNode.getNodeName()) {
					lifoQueue.removeFirst();
				} else {
					break;
				}
			}
			lifoQueue.addFirst(node.getNodeName());
		}
		prevParent = parentNode.getNodeName();
		prevElem = node.getNodeName();
		//System.out.print("\n<" + parentNode.getNodeName() + "/" + node.getNodeName() + "> ");
		String DEBUG_printBreadcrumbs = "";
		for (String element : lifoQueue) {
			if (DEBUG_printBreadcrumbs.length() == 0) {
				DEBUG_printBreadcrumbs = element;
			} else {
				DEBUG_printBreadcrumbs = element + "/" + DEBUG_printBreadcrumbs;
			}
		}

		//System.out.print("\n" + DEBUG_printBreadcrumbs);

		///~~ Business Logic:
		NamedNodeMap attrs = node.getAttributes();
		Node attrID = attrs.getNamedItem(XmlWFElemt.id.getEnumStr());
		Node attrStep = attrs.getNamedItem(XmlWFElemt.step.getEnumStr());
		Node attrType = attrs.getNamedItem(XmlWFElemt.type.getEnumStr());
		Node attrName = attrs.getNamedItem(XmlWFElemt.name.getEnumStr());

		stringBuilderWfBreadcrumbs.append("\n");
		stringBuilderWfBreadcrumbs.append(wfObj.getMetaJiraDescription());
		stringBuilderWfBreadcrumbs.append("\t" + DEBUG_printBreadcrumbs + "\t");

		if (node.getNodeName().compareTo(XmlWFElemt.action.getEnumStr()) == 0) {
			/// <action id="11" name="Start Progress">
			// stringBuilder.append("\n" + DEBUG_printBreadcrumbs);
			stringBuilderWfBreadcrumbs.append("~<action " + attrID + ", " + attrName.getTextContent() + ">");

		} else if (node.getNodeName().compareTo(XmlWFElemt.commonAction.getEnumStr()) == 0) {
			/// <common-action id="1111"/>
			// stringBuilder.append("\n" + DEBUG_printBreadcrumbs);
			stringBuilderWfBreadcrumbs.append("~<commonAction " + attrID + ">");

		} else if (node.getNodeName().compareTo(XmlWFElemt.step.getEnumStr()) == 0) {
			/// <step id="4" name="In Progress">
			// stringBuilder.append("\n" + DEBUG_printBreadcrumbs);
			stringBuilderWfBreadcrumbs.append("~<step " + attrID + ", " + attrName.getTextContent() + ">");

		} else if (node.getNodeName().compareTo(XmlWFElemt.unconditionalResult.getEnumStr()) == 0) {
			///<unconditional-result old-status="null" status="null" step="29">
			// stringBuilder.append("\n" + DEBUG_printBreadcrumbs);
			stringBuilderWfBreadcrumbs.append("~<unconditionalResult " + attrStep + ">");

		} else if (node.getNodeName().compareTo(XmlWFElemt.meta.getEnumStr()) == 0) {
			if (attrName.getTextContent().compareTo(xmlWfNodesFullList.approvalFieldId.getEnumStr()) == 0) {
				/// <steps><step><meta name="approval.field.id">customfield_11707</meta>
				// stringBuilder.append("\n" + DEBUG_printBreadcrumbs);
				stringBuilderWfBreadcrumbs.append("~[" + attrName.getTextContent().toUpperCase() + ": " + UtilsGeneral.cleanAmpersandCoding(node.getTextContent()) + "]");
				String foundField = isCSFieldOrFocusKeyWordsPresent(node.getTextContent());
				if (foundField.length() > 0) {
					stringBuilderWfBreadcrumbs.append("\t\t~found2 field '" + foundField + "'");
				}
			}

			///~~~~~~~~~~~~~~~~~~  SegmentExecutor: [condition, validator, function] ~~~~~~~~~~~~~~~~~~ 
			//		} else if (node.getNodeName().compareTo(XmlWFElemt.conditionTypeClass.getEnumStr()) == 0) {
			///~~ <conditions type="AND">
			///~~ <condition type="class">
			///~~ May contain Scripts, JQL, customfield_11707
			//			// stringBuilder.append("\n" + DEBUG_printBreadcrumbs);
			//			stringBuilder.append("~<SegmentExecutor condition type=class: " + attrType + ", " + attrName + ">");

		} else if (node.getNodeName().compareTo(XmlWFElemt.condition.getEnumStr()) == 0) {
			///~~ <conditions type="AND">
			///~~ <condition type="class">
			///~~ May contain Scripts, JQL, customfield_11707
			// stringBuilder.append("\n" + DEBUG_printBreadcrumbs);
			stringBuilderWfBreadcrumbs.append("~<SegmentExecutor condition: " + attrType + ", " + attrName + ">");

		} else if (node.getNodeName().compareTo(XmlWFElemt.validator.getEnumStr()) == 0) {
			///~~ <validator name="TheName" type="class">
			///~~ May contain Scripts, JQL, customfield_11707
			// stringBuilder.append("\n" + DEBUG_printBreadcrumbs);
			stringBuilderWfBreadcrumbs.append("~<SegmentExecutor validator " + attrType + ", " + attrName + ">");

		} else if (node.getNodeName().compareTo(XmlWFElemt.function.getEnumStr()) == 0) {
			///~~ <function type="class"> Note: <function> has no attribute 'name' 
			///~~ May contain Scripts, JQL, customfield_11707
			// stringBuilder.append("\n" + DEBUG_printBreadcrumbs);
			stringBuilderWfBreadcrumbs.append("~<SegmentExecutor function '" + attrType + "'>");

			///~~~~ ELEMENT <arg> ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		} else if (node.getNodeName().compareTo(XmlWFElemt.arg.getEnumStr()) == 0) {
			/// <arg name="FIELD_FUNCTION_ID">06130458-eec7-49c8-958c-bd041de215cb</arg>
			if (isPrintAllElementsArg //
					|| attrName.getTextContent().startsWith(xmlWfNodesFullList.fieldsList.getEnumStr()) //
					|| attrName.getTextContent().startsWith(xmlWfNodesFullList.fieldValue.getEnumStr()) //
					|| attrName.getTextContent().startsWith(xmlWfNodesFullList.fieldName.getEnumStr()) //
					|| attrName.getTextContent().startsWith(xmlWfNodesFullList.FIELD_.getEnumStr())) {
				// stringBuilder.append("\n" + DEBUG_printBreadcrumbs);
				stringBuilderWfBreadcrumbs.append("~[" + UtilsGeneral.cleanAmpersandCoding(attrName.getTextContent()));
				///System.out.print("\t[" + attrName.getTextContent());
				///~~~ Print the BASE64 SCRIPTS and JQL:
				String txt = node.getTextContent();
				txt = Base64EcodingDecoding.decodeB64(txt, true);
				stringBuilderWfBreadcrumbs.append("\t" + txt); //~~ Add `!` as a search key
			}
			///~~ Additionally print found Jira Fields: 
			if (node.getTextContent() != null) {
				String foundField = isCSFieldOrFocusKeyWordsPresent(node.getTextContent());
				if (foundField.length() > 0) {
					stringBuilderWfBreadcrumbs.append("\t~found1 field '" + foundField + "'");
				}
			}
			///~~ Additionally print found Jira Fields:
			if (attrName != null && attrName.getTextContent() != null) {
				String foundField = isCSFieldOrFocusKeyWordsPresent(attrName.getTextContent());
				if (foundField.length() > 0) {
					stringBuilderWfBreadcrumbs.append("\t~found0 field '" + foundField + "'");
				}
			}
		} //~~ fi ~~ ELEMENT <arg> ~~

		///System.out.println();
		///~~ Recursion ~~
		NodeList nodeList = node.getChildNodes();
		for (int i = 0; i < nodeList.getLength(); i++) {
			Node currentNode = nodeList.item(i);
			if (currentNode.getNodeType() == Node.ELEMENT_NODE) {
				///~~calls this method for all the children which is Element
				surfNode(currentNode, node);
			}
		}
	}

	///<workflow>
	///		<initial-actions/>
	///		<global-actions/>
	///		<common-actions/>
	///		<steps/>
	///</workflow>

	// enum xmlWfSection {condition("condition"), validator("validator"), function("function");}

	//<action id="11" name="Start Progress">
	///~~ 'Action' might be one of the listed below: 
	///	condition: <!-- restrict-to.conditions.condition -->
	///	validator: <!-- validators.validator -->
	///	function: <!-- results.unconditional-result.post-functions.function --> 

	//	<restrict-to>
	//		<conditions type="AND">
	//			<condition type="class">

	//	<validators>
	//		<validator name="Validator name added manually" type="class">

	//	<results>
	//		<unconditional-result old-status="null" status="null" step="2">
	//			<post-functions>
	//				<function type="class">

	///TODO
	///~~~ Diiference in export as WF and as XML (with extra JSU, ScriptRunner and other automation removed )
	/// Find all JSU code blocks (condition, validator, function, etc.? -- list classes, list code, list JQL 
	/// Find all Scriptrunner code:
	/// 		Find ''FIELD_CONDITION: {"script":null,"scriptPath":"conditions/check-if-project-is-bst.groovy"} -- All 'scriptPath' with Groovy File in Windows
	/// Find all <arg name="class.name">com.atlassian.jira.workflow.function.issue.UpdateIssueFieldFunction</arg>

	//	The items from the following plugins were removed from the workflow:
	//		 - Adaptavist ScriptRunner for JIRA
	//		 - JSU Automation Suite for Jira Workflows

}
