package utilsGlobal;

import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class XmlUtils {

	public final List<Node> getNodesAtLevel(Node node, int level, int currentLevel) {
		//~~ a recursive function to traverse the XML tree. This function will navigate through the XML tree and collect nodes at the desired level. You can pass in the desired level as a parameter, and it will return a list of nodes from that level.
		List<Node> nodes = new ArrayList<>();
		if (currentLevel == level) {
			nodes.add(node);
		}
		NodeList children = node.getChildNodes();
		for (int i = 0; i < children.getLength(); i++) {
			Node child = children.item(i);
			if (child.getNodeType() == Node.ELEMENT_NODE) {
				nodes.addAll(getNodesAtLevel(child, level, currentLevel + 1));
			}
		}
		return nodes;
	}

}
