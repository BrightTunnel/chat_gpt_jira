package utilsGlobal;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import jiraConstants.ConstXmlElementsBackupJira.XmlAtrb;
import jiraConstants.ConstXmlElementsExportedJiraIssues.XmlExportElemt;
import jiraPojoObjects.PojoComment;
import jiraPojoObjects.PojoCustomField;
import jiraPojoObjects.PojoJiraIssue;

public class ParseJiraIssuesExportedAsXml {

	public final HashMap<String, PojoJiraIssue> parseJiraIssuesExportedAsXml(String aFilePath) {
		HashMap<String, PojoJiraIssue> _issues = null;
		UtilsGeneral utilsGeneral = new UtilsGeneral();
		if (aFilePath != null) {
			File file = new File(aFilePath);
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = null;
			Document doc = null;
			try {
				builder = factory.newDocumentBuilder();
				doc = builder.parse(file);
				if (doc != null) {
					doc.getDocumentElement().normalize();
					// System.out.println("Root element:" + doc.getDocumentElement().getNodeName());
					NodeList nList = doc.getElementsByTagName(XmlExportElemt.item.getEnumStr());
					// System.out.println("----------------------------");
					_issues = new HashMap<String, PojoJiraIssue>();
					PojoJiraIssue _issue = null;
					for (int idx = 0; idx < nList.getLength(); idx++) { // ~~ Iterate by XML elements <items>. Each XML element '<item>' reperesnts one Jira Issue.
						Node xmlElementItemHoldsJiraIssue = nList.item(idx);
						// System.out.print("\nElement " + idx + ": '" + xmlElementItemHoldsJiraIssue.getNodeName() + "'");
						if (xmlElementItemHoldsJiraIssue.getNodeType() == Node.ELEMENT_NODE) {
							Element _xmlElemItemJiraIssue = (Element) xmlElementItemHoldsJiraIssue;
							_issue = new PojoJiraIssue();
							// _issue.setBody("_issue.setBody");
							_issue.setTitle(getElementTextContent(_xmlElemItemJiraIssue, XmlExportElemt.title.getEnumStr()));
							_issue.setLink(getElementTextContent(_xmlElemItemJiraIssue, XmlExportElemt.link.getEnumStr()));

							///~~ element '<project id="10000" key="PR">The text content</project>' 
							NodeList jiraProjectNodes = _xmlElemItemJiraIssue.getElementsByTagName(XmlExportElemt.project.getEnumStr());
							NamedNodeMap jiraProjectAttributes = jiraProjectNodes.item(0).getAttributes(); //~~ The only node (jiraProjectNodes.getLength() == 1)
							Node jiraProjectIDNode = jiraProjectAttributes.getNamedItem("id"); // id="10000"
							Node jiraProjectKeyNode = jiraProjectAttributes.getNamedItem("key"); // key="PR"
							String jiraProjectID = jiraProjectIDNode.getNodeValue(); // id="10000"
							_issue.setProject(Long.parseLong(jiraProjectID)); // id="10000"
							String jiraProjectName = getElementTextContent(_xmlElemItemJiraIssue, XmlExportElemt.project.getEnumStr());

							_issue.setDescription(getElementTextContent(_xmlElemItemJiraIssue, XmlExportElemt.description.getEnumStr()));
							_issue.setEnvironment(getElementTextContent(_xmlElemItemJiraIssue, XmlExportElemt.environment.getEnumStr()));
							_issue.setKey(getElementTextContent(_xmlElemItemJiraIssue, XmlExportElemt.key.getEnumStr()));
							_issue.setSummary(getElementTextContent(_xmlElemItemJiraIssue, XmlExportElemt.summary.getEnumStr()));
							_issue.setIssueType(getElementTextContent(_xmlElemItemJiraIssue, XmlExportElemt.type.getEnumStr())); // ~~ Task ~~
							_issue.setPriority(getElementTextContent(_xmlElemItemJiraIssue, XmlExportElemt.priority.getEnumStr())); // ~~ Low ~~
							_issue.setIssuestatus(getElementTextContent(_xmlElemItemJiraIssue, XmlExportElemt.status.getEnumStr())); // ~~ Open ~~
							_issue.setStatusCategory(getElementTextContent(_xmlElemItemJiraIssue, XmlExportElemt.statusCategory.getEnumStr()));
							_issue.setResolution(getElementTextContent(_xmlElemItemJiraIssue, XmlExportElemt.resolution.getEnumStr()));
							_issue.setAssignee(getElementTextContent(_xmlElemItemJiraIssue, XmlExportElemt.assignee.getEnumStr()));
							_issue.setReporter(getElementTextContent(_xmlElemItemJiraIssue, XmlExportElemt.reporter.getEnumStr()));
							_issue.setAuthor(getElementTextContent(_xmlElemItemJiraIssue, XmlExportElemt.author.getEnumStr()));
							_issue.setLabels(getElementTextContent(_xmlElemItemJiraIssue, XmlExportElemt.labels.getEnumStr()));
							_issue.setCreated(utilsGeneral.getDateLong(getElementTextContent(_xmlElemItemJiraIssue, XmlExportElemt.created.getEnumStr())));
							_issue.setUpdated(utilsGeneral.getDateLong(getElementTextContent(_xmlElemItemJiraIssue, XmlExportElemt.updated.getEnumStr())));
							_issue.setDuedate(utilsGeneral.getDateLong(getElementTextContent(_xmlElemItemJiraIssue, XmlExportElemt.due.getEnumStr())));
							if (getElementTextContent(_xmlElemItemJiraIssue, XmlExportElemt.votes.getEnumStr()) != null) {
								_issue.setVotes(Long.parseLong(getElementTextContent(_xmlElemItemJiraIssue, XmlExportElemt.votes.getEnumStr())));
							}
							if (getElementTextContent(_xmlElemItemJiraIssue, XmlExportElemt.watches.getEnumStr()) != null) {
								_issue.setWatches(Long.parseLong(getElementTextContent(_xmlElemItemJiraIssue, XmlExportElemt.watches.getEnumStr())));
							}
							// _issue.setDateCommented( Utils.getDate("1/3/2000"));
							// _issue.setDateCaseClosed(Utils.getDate("4/Jan/20")); // ~~ dateCreated + 30 days

							// ~~ Comments ~~
							NodeList elmComments = _xmlElemItemJiraIssue.getElementsByTagName(XmlExportElemt.comment.getEnumStr()); // ~~List of all comment's for that item/issue
							if (elmComments != null) {
								HashMap<String, PojoComment> commentsMap = new HashMap<String, PojoComment>();
								PojoComment commentObj = null;
								for (int idxComment = 0; idxComment < elmComments.getLength(); idxComment++) {
									Node nodeComment = elmComments.item(idxComment);
									if (nodeComment != null && nodeComment.getNodeType() == Node.ELEMENT_NODE) {
										Element elmComment = (Element) nodeComment; // ~~ this is single Comment
										commentObj = new PojoComment();
										// ~~ get Attributes and TextContent of single Comment ~~
										String _idLong = elmComment.getAttribute(XmlAtrb.id.getEnumStr());
										Long _id = Long.parseLong(_idLong);
										commentObj.setCommentID(_id);
										String _txt = elmComment.getAttribute(XmlAtrb.author.getEnumStr());
										commentObj.setCommentAuthor(_txt);
										_txt = elmComment.getAttribute(XmlAtrb.created.getEnumStr());
										commentObj.setCommentCreated(utilsGeneral.getDateLong(_txt));
										// ~~ Check if this Comment has value.
										String _textContent = elmComment.getTextContent();
										if (_textContent != null) {
											commentObj.setCommentText(_textContent);
										}
									}
									commentsMap.put(commentObj.getCommentID().toString(), commentObj);
								}
								_issue.setComments(commentsMap);
							}

							// ~~
							_issue.setAttachments(getElementTextContent(_xmlElemItemJiraIssue, XmlExportElemt.attachments.getEnumStr()));
							_issue.setAssignee(getElementTextContent(_xmlElemItemJiraIssue, XmlExportElemt.subtasks.getEnumStr()));

							// ~~ Custom fields ~~
							// Node elmCfs = eElement.getElementsByTagName(XmlElemt.customfields.getEnumStr()).item(0); // ~~Single element [0] 'customfields' per item/issue 
							NodeList elmCfs = _xmlElemItemJiraIssue.getElementsByTagName(XmlExportElemt.customfield.getEnumStr()); // ~~List of all customfield's for that item/issue
							if (elmCfs != null) {
								HashMap<String, PojoCustomField> cfsMap = new HashMap<String, PojoCustomField>();
								for (int idCf = 0; idCf < elmCfs.getLength(); idCf++) {
									Node nodeCf = elmCfs.item(idCf);
									// System.out.println("Current Element " + idCf + ": " + cfNode.getNodeName());
									if (nodeCf.getNodeType() == Node.ELEMENT_NODE) {
										Element elmCf = (Element) nodeCf; // ~~ this is single CustomField
										PojoCustomField cfObj = new PojoCustomField();
										// ~~ get Attributes of single CustomField ~~
										String _idLong = elmCf.getAttribute(XmlAtrb.id.getEnumStr());
										_idLong = _idLong.substring("customfield_".length()); // ~~ Cut off customfield_ from 'customfield_10101' 
										Long _id = Long.parseLong(_idLong);
										cfObj.setCustomFieldIDLong(_id);
										cfObj.setCustomfieldTypeKey(elmCf.getAttribute(XmlAtrb.key.getEnumStr()));

										// ~~ get Elements of single CustomField ~~
										String _textContent = getElementTextContent(elmCf, XmlExportElemt.customfieldname.getEnumStr());
										if (_textContent != null) {
											cfObj.setCfName(_textContent);
										}

										// ~~ Get <customfieldvalue> ~~
										Node nodeCustomFieldValue = elmCf.getElementsByTagName(XmlExportElemt.customfieldvalue.getEnumStr()).item(0);
										if (nodeCustomFieldValue != null) {
											// ~~ Check if this customfield has value. Note: xml element 'customfieldvalues contains a single xml element 'customfieldvalue', so do not loop
											_textContent = nodeCustomFieldValue.getTextContent();
											if (_textContent != null) {
												cfObj.setCfTextContent(_textContent);
											}
											String _datakey = ((Element) nodeCustomFieldValue).getAttribute(XmlAtrb.datakey.getEnumStr());
											if (_datakey != null && _datakey.length() > 0) {
												cfObj.setDatakey(_datakey);
											}
											String _dataremainingtime = ((Element) nodeCustomFieldValue).getAttribute(XmlAtrb.dataremainingtime.getEnumStr());
											if (_dataremainingtime != null && _dataremainingtime.length() > 0) {
												cfObj.setDataremainingtime(_dataremainingtime);
											}
										} else {
											// System.out.println("~~Missing XML Element: " + XmlElemt.customfieldvalue.getEnumStr());
										}
										cfsMap.put(cfObj.getCfName(), cfObj);
									}
								}
								_issue.setCustomfields(cfsMap);
							}
							// ~~ Finally Add issue to the issues Dictionary ~~
							_issues.put(_issue.getKey(), _issue);
							// System.out.println("~~: " + _issue);
						}
					}
				}
			} catch (ParserConfigurationException | SAXException | IOException e) {
				e.printStackTrace();
			}
		}
		return _issues;
	}

	private final String getElementTextContent(Element eElement, String anElementName) {
		String textContent = null;
		if (eElement.getElementsByTagName(anElementName).item(0) != null) {
			textContent = eElement.getElementsByTagName(anElementName).item(0).getTextContent();
		} else {
			// System.out.println("~~Missing XML Element: " + anElementName);
		}
		return textContent;
	}
}
