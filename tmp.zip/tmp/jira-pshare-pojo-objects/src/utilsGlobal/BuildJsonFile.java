package utilsGlobal;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.TreeMap;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import jiraConstants.ConstIniKeys.IniKeys;
import jiraConstants.ConstJiraJsonKeys.JsonCF;
import jiraConstants.ConstJiraJsonKeys.JsonComment;
import jiraConstants.ConstJiraJsonKeys.JsonIssue;
import jiraConstants.ConstJiraJsonKeys.JsonProject;
import jiraConstants.ConstJiraJsonKeys.JsonRoot;
import jiraConstants.ConstsJira.JiraCustomFieldsType;
import jiraPojoObjects.PojoComment;
import jiraPojoObjects.PojoCustomField;
import jiraPojoObjects.PojoCustomFieldOption;
import jiraPojoObjects.PojoCwd_user;
import jiraPojoObjects.PojoIssueStatus;
import jiraPojoObjects.PojoIssueType;
import jiraPojoObjects.PojoJiraIssue;
import jiraPojoObjects.PojoPriority;
import jiraPojoObjects.PojoWorkflow;

public class BuildJsonFile {

	public final static JSONObject buldJsonFragmentProject(HashMap<String, PojoJiraIssue> anIssues, HashMap<String, PojoIssueType> anIssueType, HashMap<String, PojoIssueStatus> anIssueStatus, HashMap<Long, PojoWorkflow> aWorkflow, HashMap<String, PojoPriority> aPriority, HashMap<Long, PojoCwd_user> aCwd_user, boolean isAddIssueKey) {

		// ~~ Create one project ~~
		JSONObject _jsnProject = buldJsonProject(false);

		// ~~ Generate number of issues of each issue type ~~
		JSONArray _issuesJson = buildJsonSetOfIssues(anIssues, anIssueType, anIssueStatus, aWorkflow, aPriority, aCwd_user, !isAddIssueKey);

		// ~~ Finish building Json External project import file ~~
		_jsnProject.put(JsonProject.issues.getEnumStr(), _issuesJson);
		JSONArray _jsnProjects = new JSONArray();
		_jsnProjects.add(_jsnProject);
		JSONObject _jsnRoot = new JSONObject();
		_jsnRoot.put(JsonRoot.projects.getEnumStr(), _jsnProjects);
		return _jsnRoot;
	}

	public final static JSONObject buldJsonProject(boolean isCreateOrUpdateExistingProject) {
		JSONObject _jsnProject = new JSONObject();

		String _projectKey = UtilsGeneral.iniPref.node(IniKeys.project.toString()).get(IniKeys.targetProjectKey.toString(), null); // 'PR'
		_jsnProject.put(JsonProject.key.getEnumStr(), _projectKey);

		if (isCreateOrUpdateExistingProject) {
			String _projectType = UtilsGeneral.iniPref.node(IniKeys.project.toString()).get(IniKeys.projectType.toString(), null); // 'software' or 'service_desk'
			_jsnProject.put(JsonProject.type.getEnumStr(), _projectType); // ~~ 'software' or 'service_desk'
			// _jsnProject.put(JsonProject.type.getObjStr(), "software"); // ~~ Overwrite 'service_desk'

			String _projectName = UtilsGeneral.iniPref.node(IniKeys.project.toString()).get(IniKeys.projectName.toString(), null);
			if (_projectName != null && _projectName.length() > 0) {
				_jsnProject.put(JsonProject.name.getEnumStr(), _projectName);
			} else {
				_jsnProject.put(JsonProject.name.getEnumStr(), "Project name for [" + _projectKey + "] was not provided");
			}

			String _projectDescription = UtilsGeneral.iniPref.node(IniKeys.project.toString()).get(IniKeys.projectDescription.toString(), null);
			if (_projectDescription != null && _projectDescription.length() > 0) {
				_jsnProject.put(JsonProject.description.getEnumStr(), _projectDescription);
			} else {
				_jsnProject.put(JsonProject.description.getEnumStr(), "Project description for [" + _projectKey + "] was not provided");
			}

			String _projectExternalName = UtilsGeneral.iniPref.node(IniKeys.project.toString()).get(IniKeys.projectExternalName.toString(), null);
			if (_projectExternalName != null && _projectExternalName.length() > 0) {
				_jsnProject.put(JsonProject.externalName.getEnumStr(), _projectExternalName);
			} else {
				_jsnProject.put(JsonProject.externalName.getEnumStr(), "Project External Name for [" + _projectKey + "] was not provided");
			}

			_jsnProject.put(JsonProject.lead.getEnumStr(), "localadmin");
			_jsnProject.put(JsonProject.assigneeType.getEnumStr(), "3");
		}

		return _jsnProject;
	}

	public final static JSONArray buildJsonSetOfIssues(HashMap<String, PojoJiraIssue> anIssues, HashMap<String, PojoIssueType> anIssueType, HashMap<String, PojoIssueStatus> anIssueStatus, HashMap<Long, PojoWorkflow> aWorkflow, HashMap<String, PojoPriority> aPriority, HashMap<Long, PojoCwd_user> aCwd_user, boolean useIssueKeyMadeByJira) {
		JSONArray jsonIssues = new JSONArray();
		for (HashMap.Entry<String, PojoJiraIssue> entry : anIssues.entrySet()) {
			String key = entry.getKey();
			PojoJiraIssue _jiraIssue = entry.getValue();
			jsonIssues.add(buldJsonFragmentIssue(_jiraIssue, anIssueType, anIssueStatus, aWorkflow, aPriority, aCwd_user, useIssueKeyMadeByJira));
		}
		return jsonIssues;
	}

	private final static JSONObject buldJsonFragmentIssue(PojoJiraIssue anIssue, HashMap<String, PojoIssueType> anIssueType, HashMap<String, PojoIssueStatus> anIssueStatus, HashMap<Long, PojoWorkflow> aWorkflow, HashMap<String, PojoPriority> aPriority, HashMap<Long, PojoCwd_user> aCwd_user, boolean useIssueKeyMadeByJira) {

		boolean isExpandIDtoDescription = true; //~~ TODO may move this to the parameters

		// ~~ Create an Issue Json object ~~
		JSONObject jsnIssue = new JSONObject();

		jsnIssue.put(JsonIssue.id.getEnumStr(), anIssue.getId());

		jsnIssue.put(JsonIssue.reporter.getEnumStr(), anIssue.getReporter()); //~~ 'JIRAUSER10000'
		if (isExpandIDtoDescription && anIssue.getReporter() != null && anIssue.getReporter().startsWith("JIRAUSER")) {
			Long cwd_userID = Long.parseLong(anIssue.getReporter().substring("JIRAUSER".length()));
			jsnIssue.put(JsonIssue.reporter.getEnumStr(), aCwd_user.get(cwd_userID).getUser_name());
		}

		jsnIssue.put(JsonIssue.assignee.getEnumStr(), anIssue.getAssignee()); //~~ 'JIRAUSER10000'
		if (isExpandIDtoDescription && anIssue.getAssignee() != null && anIssue.getAssignee().startsWith("JIRAUSER")) {
			Long cwd_userID = Long.parseLong(anIssue.getAssignee().substring("JIRAUSER".length()));
			jsnIssue.put(JsonIssue.assignee.getEnumStr(), aCwd_user.get(cwd_userID).getUser_name());
		}

		jsnIssue.put(JsonIssue.creator.getEnumStr(), anIssue.getCreator()); // ~~ Error: {Unrecognized field "author"}
		if (isExpandIDtoDescription && anIssue.getCreator() != null && anIssue.getCreator().startsWith("JIRAUSER")) {
			Long cwd_userID = Long.parseLong(anIssue.getCreator().substring("JIRAUSER".length()));
			jsnIssue.put(JsonIssue.creator.getEnumStr(), aCwd_user.get(cwd_userID).getUser_name());
		}

		///PojoIssueType itp = anIssueType.get(anIssue.getIssueType());
		/// String issueTypeDetails = itp.getPname() + itp.getPstyle();
		if (isExpandIDtoDescription && anIssue.getIssueType() != null && anIssueType != null) {
			jsnIssue.put(JsonIssue.issueType.getEnumStr(), anIssueType.get(anIssue.getIssueType()).getPname());
		} else {
			jsnIssue.put(JsonIssue.issueType.getEnumStr(), anIssue.getIssueType());
		}

		jsnIssue.put(JsonIssue.summary.getEnumStr(), anIssue.getSummary());

		jsnIssue.put(JsonIssue.description.getEnumStr(), anIssue.getDescription());

		if (anIssue.getEnvironment() != null && anIssue.getEnvironment().trim().length() > 0) {
			jsnIssue.put(JsonIssue.environment.getEnumStr(), anIssue.getEnvironment()); // <environment/>
		}

		if (isExpandIDtoDescription && anIssue.getPriority() != null && aPriority != null) {
			jsnIssue.put(JsonIssue.priority.getEnumStr(), aPriority.get(anIssue.getPriority()).getPname());
		} else {
			jsnIssue.put(JsonIssue.priority.getEnumStr(), anIssue.getPriority());
		}

		jsnIssue.put(JsonIssue.resolution.getEnumStr(), anIssue.getResolution());

		if (isExpandIDtoDescription && anIssue.getIssuestatus() != null && anIssueStatus != null) {
			if (anIssueStatus.get(anIssue.getIssuestatus()) != null) {
				jsnIssue.put(JsonIssue.issuestatus.getEnumStr(), anIssueStatus.get(anIssue.getIssuestatus()).getPname());
			}
		} else {
			jsnIssue.put(JsonIssue.issuestatus.getEnumStr(), anIssue.getIssuestatus());
		}

		if (anIssue.getCreated() != null) {
			jsnIssue.put(JsonIssue.created.getEnumStr(), "'" + anIssue.getCreated() + "'");
		}
		if (anIssue.getUpdated() != null) {
			jsnIssue.put(JsonIssue.updated.getEnumStr(), "'" + anIssue.getUpdated() + "'");
		}
		if (anIssue.getDuedate() != null) {
			jsnIssue.put(JsonIssue.duedate.getEnumStr(), "'" + anIssue.getDuedate() + "'");
		}

		if (isExpandIDtoDescription && anIssue.getWorkflow_id() != null) {
			jsnIssue.put(JsonIssue.workflow_id.getEnumStr(), aWorkflow.get(anIssue.getWorkflow_id()).getName()); //~~ must be table 'os_wfentry'
		} else {
			jsnIssue.put(JsonIssue.workflow_id.getEnumStr(), anIssue.getWorkflow_id()); ///~~~ Just WF ID as Long
		}

		jsnIssue.put(JsonIssue.component.getEnumStr(), anIssue.getComponent());
		///~~~ if an issue archived ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		if (anIssue.getArchived() != null && anIssue.getArchived().compareTo("Y") == 0) {
			if (anIssue.getArchivedby() != null) {
				jsnIssue.put(JsonIssue.archivedby.getEnumStr(), anIssue.getArchivedby());
				if (isExpandIDtoDescription && anIssue.getArchivedby() != null && anIssue.getArchivedby().startsWith("JIRAUSER")) {
					Long cwd_userID = Long.parseLong(anIssue.getArchivedby().substring("JIRAUSER".length()));
					jsnIssue.put(JsonIssue.archivedby.getEnumStr(), aCwd_user.get(cwd_userID).getUser_name());
				}
			}
			if (anIssue.getArchiveddate() != null) {
				jsnIssue.put(JsonIssue.archiveddate.getEnumStr(), "'" + anIssue.getArchiveddate() + "'");
			}
		}

		///~~~ EXTRA (Not in the db table 'JiraIssue') ~~~
		if (!useIssueKeyMadeByJira) {
			// ~~ Force to use determined Issue keys
			jsnIssue.put(JsonIssue.key.getEnumStr(), anIssue.getKey());
		} else { // ~~ Let it be generated automatically
		}
		// jsnIssue.put(JsonIssue.resolved.getEnumStr(), anIssue.getResolved().getTime()); // ~~ Can't modify, set when issue resolved
		// jsnIssue.put(JsonIssue.fixVersion.getEnumStr(), anIssue.getFixVersion());

		// ~~ CFs ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		if (anIssue.getCustomfields() != null) {
			// ~~ Add custom fields ~~
			JSONArray jsnCustomFields = new JSONArray();
			HashMap<String, PojoCustomField> _cflds = anIssue.getCustomfields();
			// ~~ Iterate cfs ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			_cflds.forEach((k, v) -> {
				// ~~ Assuming all custom fields are Select
				JSONObject jsnCustomField = new JSONObject();
				jsnCustomField.put(JsonCF.fieldName.getEnumStr(), k);
				jsnCustomField.put(JsonCF.fieldType.getEnumStr(), v.getCustomfieldTypeKey());
				jsnCustomField.put(JsonCF.searcherType.getEnumStr(), v.getCustomfieldSearcherKey());
				// System.out.println(v.getCustomfieldTypeKey() + "\t ~ " + k);
				String _cfTextContent = "";
				if (v.getCustomfieldTypeKey() != null) {
					_cfTextContent = v.getCfTextContent();
					if (_cfTextContent != null) {
						// ~~ Sanitize TextContent ~~
						boolean doSanitize = false;
						doSanitize = doSanitize || (v.getCustomfieldTypeKey().toString().compareTo(JiraCustomFieldsType.cfTypeSelect.getEnumStr()) == 0);
						doSanitize = doSanitize || (v.getCustomfieldTypeKey().toString().compareTo(JiraCustomFieldsType.cfTypeMultiuserpicker.getEnumStr()) == 0);
						doSanitize = doSanitize || (v.getCustomfieldTypeKey().toString().compareTo(JiraCustomFieldsType.cfTypeSdSlaField.getEnumStr()) == 0);
						doSanitize = doSanitize || (v.getCustomfieldTypeKey().toString().compareTo(JiraCustomFieldsType.cfTypeSdCustomerOrganizations.getEnumStr()) == 0);
						doSanitize = doSanitize || (v.getCustomfieldTypeKey().toString().compareTo(JiraCustomFieldsType.cfTypeSdRequestParticipants.getEnumStr()) == 0);
						if (doSanitize) {
							_cfTextContent = _cfTextContent.replace("\r", "");
							_cfTextContent = _cfTextContent.replace("\n", "");
							_cfTextContent = _cfTextContent.replace("\t", "");
							_cfTextContent = _cfTextContent.trim();
						}
					}
				}
				// ~~ Add CF Options if any ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
				TreeMap<Long, PojoCustomFieldOption> _optns = v.getCfOptions();
				if (_optns != null && _optns.size() > 1) {
					JSONArray jsnOptions = new JSONArray();
					for (PojoCustomFieldOption _vl : _optns.values()) {
						jsnOptions.add(_vl.getCustomvalue());
					}
					jsnCustomField.put(JsonCF.value.getEnumStr(), jsnOptions);
				} else {
					// ~~ if it's not an option, then it's likely text field
					if (v.getCfName().compareTo("Customer Request Type") == 0) { // ~~ TODO add series of JSD special custom fields
						// ~~ JSM Special field ~~
						jsnCustomField.put(JsonCF.value.getEnumStr(), v.getDatakey());
					} else {
						// ~~ Standard field value ~~ 
						jsnCustomField.put(JsonCF.value.getEnumStr(), _cfTextContent);
					}
				}
				jsnCustomFields.add(jsnCustomField);
			});

			// ~~ this is different CF type - Checkboxes, not selection, need it's own loop
			if (false) { // ~~ Make all options selected/checked. Add if some doesn't exist yet.
				String[] options = null;
				JSONArray jsnOptions = new JSONArray();
				int _randomBSOptionSelection = (int) (Math.random() * options.length);
				jsnOptions.add(options[_randomBSOptionSelection].trim());
				for (int jj = 0; jj < options.length; jj++) {
					jsnOptions.add(options[jj].trim());
				}
			}

			if (false) { // ~~ Hard coded CF samples -- keep it for reference
				JSONObject jsnCustomField = new JSONObject();
				// ~~ Another custom field CheckBox~~
				jsnCustomField = new JSONObject();
				jsnCustomField.put(JsonCF.fieldName.getEnumStr(), "tvnCheckBox");
				jsnCustomField.put(JsonCF.fieldType.getEnumStr(), JiraCustomFieldsType.cfTypeMultiCheckBoxes.getEnumStr());
				JSONArray jsnOptions = new JSONArray();
				jsnOptions.add("pp3");
				jsnOptions.add("pp6");
				jsnCustomField.put(JsonCF.value.getEnumStr(), jsnOptions);
				jsnCustomFields.add(jsnCustomField);
			}

			// ~~ Finally add all CustomFields to the json Issue ~~
			jsnIssue.put(JsonIssue.customFieldValues.getEnumStr(), jsnCustomFields);
		}

		// ~~ Comments ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		HashMap<String, PojoComment> _cmts = anIssue.getComments();
		if (_cmts != null) {
			JSONArray jsnComments = new JSONArray();
			// ~~ Extra comment with original inherited legacy issue key
			String _addOriginalKeyToComment = UtilsGeneral.iniPref.node(IniKeys.comments.toString()).get(IniKeys.addOriginalKeyToComment.toString(), null);
			if (_addOriginalKeyToComment != null && _addOriginalKeyToComment.length() > 0) {
				if (_addOriginalKeyToComment.compareTo("true") == 0) {
					Date _now = Calendar.getInstance().getTime();
					String _nowStr = UtilsGeneral.dateToBuildJsonForImportString(_now);
					jsnComments.add(buldJsonFragmentComment(UtilsGeneral.iniPref.node(IniKeys.comments.toString()).get(IniKeys.originalKeyDescriptor.toString(), null) + " " + anIssue.getKey(), _nowStr, null));
				}
			}
			// ~~ Iterate existing comments ~~
			_cmts.forEach((k, _cmt) -> {
				if (_cmt.getCommentText() != null) {
					JSONObject jsnCommnt = buldJsonFragmentComment(_cmt.getCommentText(), UtilsGeneral.dateToBuildJsonForImportString(_cmt.getCommentCreated()), null);
					jsnComments.add(jsnCommnt);
				} else {
					// System.out.println("comment=null");
				}
			});
			// ~~ 'Body' Another place for comments? -No
			if (false && anIssue.getBody() != null) {
				JSONObject jsnComment = buldJsonFragmentComment("~~Issue.getBody: " + anIssue.getBody(), UtilsGeneral.dateToBuildJsonForImportString(anIssue.getDateCommented()), null);
				jsnComments.add(jsnComment);
			}
			// ~~ Finally add all comments to the Issue ~~ 
			jsnIssue.put(JsonIssue.comments.getEnumStr(), jsnComments);
		}
		return jsnIssue;
	}

	private final JSONObject buldJsonFragmentCustomFields(HashMap<String, PojoCustomField> aCfds) {
		return null;
	}

	public static TreeMap<Long, PojoCustomFieldOption> buildCfOptions(String[] aListOfOptions) {
		TreeMap<Long, PojoCustomFieldOption> _options = null;
		if (aListOfOptions != null && aListOfOptions.length > 0) {
			_options = new TreeMap<Long, PojoCustomFieldOption>();
			PojoCustomFieldOption _option = null;
			for (Long ii = 0L; ii < aListOfOptions.length; ii++) {
				_option = new PojoCustomFieldOption();
				_option.setId(null);
				_option.setCustomfield(null);
				_option.setCustomfieldconfig(null);
				_option.setSequence(ii);
				_option.setCustomvalue(aListOfOptions[ii.intValue()]);
				_option.setDisabled(null);
				_options.put(_option.getSequence(), _option);
				// System.out.println(_option.toString());
			}
		}
		return _options;
	}

	private final JSONArray buldJsonFragmentComments() {
		JSONArray _comments = new JSONArray();
		JSONObject _comment = buldJsonFragmentComment("aCommentBody", "aCreated", "anAuthor");
		_comments.add(_comment);
		return _comments;
	}

	private final static JSONObject buldJsonFragmentComment(String aCommentBody, String aCreated, String anAuthor) {
		JSONObject _comment = null;
		if (aCommentBody != null) {
			_comment = new JSONObject();
			_comment.put(JsonComment.body.getEnumStr(), aCommentBody);
			if (aCreated != null) {
				_comment.put(JsonComment.created.getEnumStr(), aCreated);
			}
			if (anAuthor != null) {
				_comment.put(JsonComment.author.getEnumStr(), anAuthor);
			}
		}
		return _comment;
	}

}
