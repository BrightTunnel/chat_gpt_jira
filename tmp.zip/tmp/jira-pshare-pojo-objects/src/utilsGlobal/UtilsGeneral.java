package utilsGlobal;

import java.io.File;
import java.io.IOException;
import java.nio.file.attribute.FileTime;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.util.prefs.Preferences;

import org.ini4j.Ini;
import org.ini4j.IniPreferences;
import org.ini4j.InvalidFileFormatException;

public class UtilsGeneral {

	public static Preferences iniPref;

	public static Preferences readPresetIssueElementsAtPath(String iniFilePath) {
		return readPresetIssueElementsPrKeyAtPath(iniFilePath, null);
	}

	public static Preferences readPresetIssueElementsPrKeyAtPath(String iniFilePath, String aProjectKey) {
		Ini ini = null;
		Preferences prefs = null;
		if (aProjectKey == null) {
			///~~ For generating actual issues, provided by SQL QRY, skip this, and use hardcoded Issue Elements Preset below
			try {
				ini = new Ini(new File(iniFilePath));
				prefs = new IniPreferences(ini);
			} catch (InvalidFileFormatException e) {
				e.printStackTrace();
			} catch (IOException e) {
				//e.printStackTrace();
				System.out.print("The system cannot find the file specified");
			}
		} else {
			///~~ For generating actual issues, provided by SQL QRY, use hardcoded Issue Elements Preset below:
			ini = new Ini();
			ini.add("project", "projectType", "service_desk");
			if (aProjectKey != null) {
				ini.add("project", "targetProjectKey", aProjectKey);
			} else {
				ini.add("project", "targetProjectKey", "NULL");
			}
			prefs = new IniPreferences(ini);
		}
		return prefs;
	}

	/// ~~~ Sanitize, String methods ~~~ 	// TODO move to the sanitize package

	public static final String sanitizeStringCustom(String aStr) {
		String _s = aStr;
		if (aStr != null) {
			_s = _s.replace("\t", " ");
			_s = _s.trim().replaceAll(" +", " ");
			// _s = _s.replace("\r", "~~~");
			// _s = _s.replace("\n", "~#~");
		}
		// String[] _scriptLines = aStr.split("\\r?\\n");
		return _s;
	}

	public static final String cleanAmpersandCoding(String aString) {
		///~~ Clean "Ampersand" coding:  &quot; &apos; &lt; &gt; &amp;
		///~~ Also check UrlPercentEncoding
		aString = aString.replace("&quot;", "\"");
		aString = aString.replace("&apos;", "'");
		aString = aString.replace("&lt;", "<");
		aString = aString.replace("&gt;", ">");
		aString = aString.replace("&amp;", "&");
		return aString;
	}

	public static final String sanitazeToBeWindowsPath(String aRawPath) {
		String _subFileName = null;
		if (aRawPath != null && aRawPath.trim().length() > 0) {
			_subFileName = aRawPath.replace("\\", "-");
			_subFileName = _subFileName.replace("/", "-");
			_subFileName = _subFileName.replace(":", "-");
		}
		return _subFileName;
	}

	public static final int countIndents(String aStr) {
		int _indent = 0;
		for (int i = 0; i < aStr.length(); i++) {
			char c = aStr.charAt(i);
			if (c == '{') {
				_indent++;
			} else if (c == '}') {
				_indent--;
			}
		}
		return _indent;
	}

	///~~ DATE / TIME ~~~

	public final Date getDateLong(String aDate) {
		Date sDate = null;
		if (aDate != null && aDate.trim().length() > 5) {
			aDate = aDate.substring(5);
			// DateFormat sdf = new SimpleDateFormat("ddd, d MMM yyyy HH:mm:ss Z");
			DateFormat sdf = new SimpleDateFormat("d MMM yyyy HH:mm:ss Z");
			try {
				sDate = sdf.parse(aDate);
			} catch (ParseException e) {
				System.out.println(aDate + " ~~ERROR: " + e.getMessage());
			}
		}
		return sDate;
	}

	public static final Date getDate(String aDate) {
		DateFormat sdf = new SimpleDateFormat("M/d/yyyy");
		Date sDate = null;
		try {
			sDate = sdf.parse(aDate);
		} catch (ParseException e) {
		}
		return sDate;
	}

	public static final String dateTodMMMyy(Date aDate) {
		DateFormat df = new SimpleDateFormat("d/MMM/yy"); // "MM/dd/yyyy"
		String todayAsString = df.format(aDate);
		return todayAsString;
	}

	public static final String dateToBuildJsonForImportString(Date aDate) {
		String todayAsString = null;
		if (aDate != null) {
			String pattern = "yyyy-MM-dd'T'HH:mm:ssZ"; // ~~ 2012-08-31T15:59:02.161+0100
			DateFormat df = new SimpleDateFormat(pattern);
			todayAsString = df.format(aDate);
		}
		return todayAsString;
	}

	public final long getDifferenceDays(Date aDateBegin, Date aDateEnd) {
		long diff = aDateEnd.getTime() - aDateBegin.getTime();
		if (diff < 0) {
			diff = 0;
		}
		return TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
	}

	public final Date addDays(Date date, int days) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DATE, days); // minus number would decrement the days
		return cal.getTime();
	}

	///~~~ Date Time NOT IN USE ~~~

	private final Date UNUSED_getDateAccessLog(String aDateInString) { // ~~ '04/Jun/2021:00:02:00' ~~
		Date date = null;
		SimpleDateFormat formatterFullDateTime = new SimpleDateFormat("dd/MMM/yyyy:HH:mm:ss");
		try {
			date = formatterFullDateTime.parse(aDateInString);
		} catch (ParseException e) {
			// e.printStackTrace();
		}
		return date;
	}

	private final Date UNUSED_getShiftedDay(int aYearsToShiftto) {
		Calendar cal = Calendar.getInstance();
		Date today = cal.getTime();
		cal.add(Calendar.DAY_OF_YEAR, -aYearsToShiftto);
		Date shiftedDay = cal.getTime();
		return shiftedDay;
	}

	private final Date UNUSED_getDateAtlassianJiraLog(String aDateInString) { // ~~ 2021-03-25 20:26:21,001 ~~
		Date date = null;
		SimpleDateFormat formatterFullDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss,SSS");
		try {
			date = formatterFullDateTime.parse(aDateInString);
		} catch (ParseException e) {
			// e.printStackTrace();
		}
		return date;
	}

	private final String UNUSED_dateAsStringInThePast(int aDaysBack) {
		SimpleDateFormat formatterDate = new SimpleDateFormat("yyyyMMdd");
		Date date = Calendar.getInstance().getTime();
		LocalDateTime ldt = LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault());
		ldt = ldt.minusDays(aDaysBack);
		Date newDate = Date.from(ldt.atZone(ZoneId.systemDefault()).toInstant());
		String dateAsString = formatterDate.format(newDate);
		return dateAsString;
	}

}
