package utilsGlobal;

import java.io.File;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class SysUtils {

	public final boolean isTheFileFound(String aFilePath) {
		if (aFilePath != null && aFilePath.length() > 0) {
			try {
				File fl = new File(aFilePath);
				if (!fl.exists()) {
					//~~ The directory does not exist.
					return false;
				} else if (!fl.isDirectory()) {
					//~~ It is not a directory (i.e. it is a file).
					return true;
				}
			} catch (Exception e) {
			}
		}
		return false;
	}

	public final String calculateMD5HashKey(String anOrigString) {
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			byte[] bytesOfMd5HashKey = md.digest(anOrigString.getBytes());
			StringBuffer sb = new StringBuffer();
			for (int ii = 0; ii < bytesOfMd5HashKey.length; ++ii) {
				sb.append(Integer.toHexString((bytesOfMd5HashKey[ii] & 0xFF) | 0x100).substring(1, 3));
			}
			return sb.toString();
		} catch (NoSuchAlgorithmException e) {
		}
		return null;
	}

}
