package utilsJsonJiraCloud;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Set;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import jiraPojoObjects.PojoApplicationRole;
import jiraPojoObjects.PojoGroup;
import jiraPojoObjects.PojoGroupLabels;
import jiraPojoObjects.PojoPermission;
import jiraPojoObjects.PojoPermissionScheme;
import jiraPojoObjects.PojoPermissionSchemePermissions;
import jiraPojoObjects.PojoPermissionSchemeProjectRole;
import jiraPojoObjects.PojoProject;
import jiraPojoObjects.PojoProjectRole;
import jiraPojoObjects.PojoProjectRoleActor;
import jiraPojoObjects.PojoUser;

public class JsonParseJiraCloudObjects {

	public HashMap<String, PojoProject> jiraRestApiProjects(String anJsonLine) {
		HashMap<String, PojoProject> projects = new HashMap<String, PojoProject>();
		PojoProject project = null;
		JsonElement allElements = new JsonParser().parse(anJsonLine);
		JsonObject fullObect = allElements.getAsJsonObject();
		JsonElement members = fullObect.get("values");
		JsonArray jarray = members.getAsJsonArray();
		//--Loop the list of found projects:
		for (int ii = 0; ii < jarray.size(); ii++) {
			JsonObject obj = jarray.get(ii).getAsJsonObject();
			project = new PojoProject();
			project.setCldId(obj.get("id").toString()); // "id": "10002",
			project.setPkey(obj.get("key").toString()); // "key": "PRKEY",
			project.setPname(obj.get("name").toString()); // "name": "tvn scrum project",
			//-- "projectCategory": {"self": "", "id": "10000", "name": "bt_project_category", "description": ""},
			JsonElement elmProjectCategory = obj.get("projectCategory");
			if (elmProjectCategory != null) {
				JsonObject objProjectCategory = elmProjectCategory.getAsJsonObject();
				project.setProjectCategoryId(objProjectCategory.get("id").toString());
				project.setProjectCategoryName(objProjectCategory.get("name").toString());
				project.setProjectCategoryDescription(objProjectCategory.get("description").toString());
			}
			//--Rest of the project elements:
			project.setProjecttype(obj.get("projectTypeKey").toString()); // "projectTypeKey": {"software","product_discovery",...}
			project.setSimplified(Boolean.parseBoolean(obj.get("simplified").toString())); // "simplified": false
			project.setStyle(obj.get("style").toString()); // "style": ["next-gen", "classic"]
			project.setPrivate(Boolean.parseBoolean(obj.get("isPrivate").toString())); // "isPrivate": false,
			//project.setProperties(obj.get("properties").toString()); //--TODO parse the Json Object "properties": {},
			if (obj.get("entityId") != null) {
				project.setEntityId(obj.get("entityId").toString()); // "entityId": "4cfc5dc1-b75b-45a3-81fc-ebbaf5aa3b30",	
			}
			if (obj.get("uuid") != null) {
				project.setUuid(obj.get("uuid").toString()); // "uuid": "4cfc5dc1-b75b-45a3-81fc-ebbaf5aa3b30"	
			}
			projects.put(project.getPkey(), project);
			//-- This is the example of looping through the members of the JSON object 
			// for (String key : obj.keySet()) {JsonElement value = obj.get(key); JsonObject obje = value.getAsJsonObject();}
		}
		return projects;
	}

	public PojoProject jiraRestApiProjectDetails(String anJsonLine, PojoProject project) {
		JsonElement allElements = new JsonParser().parse(anJsonLine);
		JsonObject fullObect = allElements.getAsJsonObject();
		JsonElement element = fullObect.get("roles");
		JsonObject obj = element.getAsJsonObject(); //--since it's a JsonObject
		Set<Entry<String, JsonElement>> entries = obj.entrySet(); //will return members of your object
		HashMap<String, PojoProjectRole> roles = new HashMap<String, PojoProjectRole>();
		for (HashMap.Entry<String, JsonElement> entry : entries) {
			//System.out.println(entry.getKey() + ": " + entry.getValue());
			PojoProjectRole pojoProjectRole = new PojoProjectRole();
			pojoProjectRole.setName(entry.getKey());
			pojoProjectRole.setRolepath(entry.getValue().getAsString());
			pojoProjectRole.setId(getIDFromThePath(entry.getValue().getAsString()));
			roles.put(entry.getKey(), pojoProjectRole);
		}
		project.setProjectRoles(roles);
		return project;
	}

	public HashMap<Long, PojoProjectRole> jiraRestApiProjectRoles(String anJsonLine) {
		PojoProjectRole pojoProjectRole = null;
		PojoProjectRoleActor pojoProjectRoleActor = null;
		HashMap<Long, PojoProjectRole> roles = new HashMap<Long, PojoProjectRole>();
		HashMap<Long, PojoProjectRoleActor> actors = null;
		JsonElement allElements = new JsonParser().parse(anJsonLine);
		JsonArray jarray = allElements.getAsJsonArray();
		for (int ii = 0; ii < jarray.size(); ii++) {
			JsonObject topics = jarray.get(ii).getAsJsonObject();
			JsonElement elmSelf = topics.get("self");
			JsonElement elmName = topics.get("name");
			JsonElement elmID = topics.get("id");
			JsonElement elmDescription = topics.get("description");
			//--scope { 
			JsonElement elmScope = topics.get("scope");
			JsonElement elmType = null;
			JsonElement elmProjectID = null;
			if (elmScope != null) {
				JsonObject objScope = elmScope.getAsJsonObject();
				elmType = objScope.get("type");
				JsonElement elmProject = objScope.get("project");
				JsonObject objProject = elmProject.getAsJsonObject();
				elmProjectID = objProject.get("id");
			}
			//-- /scope }
			JsonArray arractors = topics.getAsJsonArray("actors");
			pojoProjectRole = new PojoProjectRole();
			//pojoProjectRole.setSelf(elmSelf.getAsString());
			pojoProjectRole.setName(elmName.getAsString());
			pojoProjectRole.setId(elmID.getAsLong());
			pojoProjectRole.setDescription(elmDescription.getAsString());
			if (elmType != null) {
				pojoProjectRole.setScopeType(elmType.getAsString());
			}
			if (elmProjectID != null) {
				pojoProjectRole.setScopeProjectId(elmProjectID.getAsString());
			}
			if (arractors != null) {
				actors = new HashMap<Long, PojoProjectRoleActor>();
				for (int jj = 0; jj < arractors.size(); jj++) {
					JsonObject perm = arractors.get(jj).getAsJsonObject();
					JsonElement permID = perm.get("id");
					JsonElement permDisplayName = perm.get("displayName");
					JsonElement permHldrTyp = perm.get("type");
					JsonElement permElmHldr = perm.get("actorUser");
					pojoProjectRoleActor = new PojoProjectRoleActor();
					if (permElmHldr != null) {
						JsonObject permHldr = permElmHldr.getAsJsonObject();
						JsonElement permActorUserAccountId = permHldr.get("accountId");
						pojoProjectRoleActor.setActorUserAccountId(permActorUserAccountId.getAsString());
					}
					pojoProjectRoleActor.setId(permID.getAsLong());
					pojoProjectRoleActor.setDisplayName(permDisplayName.getAsString());
					pojoProjectRoleActor.setType(permHldrTyp.getAsString());

					actors.put(pojoProjectRoleActor.getId(), pojoProjectRoleActor);
					//System.out.println(permID + "\t" + permHldrTyp + "\t" + permPerm);
				}
			} else {
				actors = null;
			}
			pojoProjectRole.setActors(actors);
			roles.put(pojoProjectRole.getId(), pojoProjectRole);
		}
		return roles;
	}

	public HashMap<Long, PojoPermissionScheme> parseJsonPermissionSchemes(String aJsonPermissionSchemes) {
		HashMap<Long, PojoPermissionScheme> permissionSchemes = new LinkedHashMap<Long, PojoPermissionScheme>();
		JsonElement allElements = new JsonParser().parse(aJsonPermissionSchemes);
		JsonObject fullObect = allElements.getAsJsonObject();
		JsonArray jarray = fullObect.getAsJsonArray("permissionSchemes");
		for (int ii = 0; ii < jarray.size(); ii++) {
			JsonObject objPermissionScheme = jarray.get(ii).getAsJsonObject();
			String aStrPermissionScheme = objPermissionScheme.toString();
			PojoPermissionScheme _permissionScheme = parseJsonPermissionScheme(aStrPermissionScheme);
			permissionSchemes.put(_permissionScheme.getId(), _permissionScheme);
		}
		return permissionSchemes;
	}

	public PojoPermissionScheme parseJsonPermissionScheme(String aStrPermissionScheme) {
		PojoPermissionScheme pojoPermissionScheme = null;
		PojoPermissionSchemePermissions pojoPermissionSchemePermissions = null;
		HashMap<Long, PojoPermissionSchemePermissions> permissions = new LinkedHashMap<Long, PojoPermissionSchemePermissions>();
		JsonElement allPermissionScheme = new JsonParser().parse(aStrPermissionScheme);
		JsonObject objPermissionScheme = allPermissionScheme.getAsJsonObject();
		JsonElement elmExpand = objPermissionScheme.get("expand");
		JsonElement elmID = objPermissionScheme.get("id");
		JsonElement elmSelf = objPermissionScheme.get("self");
		JsonElement elmName = objPermissionScheme.get("name");
		//--scope { 
		JsonElement elmScope = objPermissionScheme.get("scope");
		JsonElement elmType = null;
		JsonElement elmProjectID = null;
		if (elmScope != null) {
			JsonObject objScope = elmScope.getAsJsonObject();
			elmType = objScope.get("type");
			JsonElement elmProject = objScope.get("project");
			JsonObject objProject = elmProject.getAsJsonObject();
			elmProjectID = objProject.get("id");
		}
		//-- /scope }
		JsonElement elmDescription = objPermissionScheme.get("description");
		pojoPermissionScheme = new PojoPermissionScheme();
		pojoPermissionScheme.setExpand(elmExpand.getAsString());
		pojoPermissionScheme.setId(elmID.getAsLong());
		pojoPermissionScheme.setSelf(elmSelf.getAsString());
		pojoPermissionScheme.setName(elmName.getAsString());
		if (elmType != null) {
			pojoPermissionScheme.setScopeType(elmType.getAsString());
		}
		if (elmProjectID != null) {
			pojoPermissionScheme.setScopeProjectId(elmProjectID.getAsString());
		}
		if (elmDescription != null) {
			pojoPermissionScheme.setDescription(elmDescription.getAsString());
		}
		JsonArray arrPermissions = objPermissionScheme.getAsJsonArray("permissions");
		for (int jj = 0; jj < arrPermissions.size(); jj++) {
			JsonObject objPermission = arrPermissions.get(jj).getAsJsonObject();
			JsonElement elmPermID = objPermission.get("id");
			JsonElement elmPermSelf = objPermission.get("self");
			JsonElement elmPermHldr = objPermission.get("holder");
			JsonObject objPermHldr = elmPermHldr.getAsJsonObject();
			JsonElement permHldrTyp = objPermHldr.get("type");
			JsonElement permHldrParam = objPermHldr.get("parameter");
			JsonElement permHldrValue = objPermHldr.get("value");
			JsonElement permHldrProjectRole = objPermHldr.get("projectRole"); // PojoPermissionSchemeProjectRole
			//-- "projectRole": {
			JsonObject objHldrProjectRole = null;
			JsonElement elmPrRoleSelf = null;
			JsonElement elmPrRoleName = null;
			JsonElement elmPrRoleID = null;
			JsonElement elmPrRoleDescription = null;
			JsonElement elmPrRoleScopeType = null;
			JsonElement elmPrRoleScopeID = null;
			if (permHldrProjectRole != null) {
				objHldrProjectRole = permHldrProjectRole.getAsJsonObject();
				elmPrRoleSelf = objHldrProjectRole.get("self");
				elmPrRoleName = objHldrProjectRole.get("name");
				elmPrRoleID = objHldrProjectRole.get("id");
				elmPrRoleDescription = objHldrProjectRole.get("description");
				//--scope { 
				JsonElement elmPrRoleScope = objHldrProjectRole.get("scope");
				if (elmPrRoleScope != null) {
					JsonObject objPrRoleScope = elmPrRoleScope.getAsJsonObject();
					elmPrRoleScopeType = objPrRoleScope.get("type");
					JsonElement elmPrRoleScopeProject = objPrRoleScope.get("project");
					JsonObject objPrRoleScopeProject = elmPrRoleScopeProject.getAsJsonObject();
					elmPrRoleScopeID = objPrRoleScopeProject.get("id");
				}
				//--scope }
			}
			JsonElement permHldrExpand = objPermHldr.get("expand");
			JsonElement elmPermPerm = objPermission.get("permission");
			pojoPermissionSchemePermissions = new PojoPermissionSchemePermissions();
			pojoPermissionSchemePermissions.setId(elmPermID.getAsLong());
			pojoPermissionSchemePermissions.setSelf(elmPermSelf.getAsString());
			pojoPermissionSchemePermissions.setHolderType(permHldrTyp.getAsString());
			if (permHldrParam != null) {
				pojoPermissionSchemePermissions.setHolderParameter(permHldrParam.getAsString());
			}
			if (permHldrValue != null) {
				pojoPermissionSchemePermissions.setHolderValue(permHldrValue.getAsString());
			}
			PojoPermissionSchemeProjectRole prRole = null;
			if (objHldrProjectRole != null) {
				prRole = new PojoPermissionSchemeProjectRole();
				prRole.setSelf(elmPrRoleSelf.getAsString());
				prRole.setName(elmPrRoleName.getAsString());
				prRole.setId(elmPrRoleID.getAsLong());
				prRole.setDescription(elmPrRoleDescription.getAsString());
				if (elmPrRoleScopeType != null) {
					prRole.setScopeType(elmPrRoleScopeType.getAsString());
				}
				if (elmPrRoleScopeID != null) {
					prRole.setScopeProjectId(elmPrRoleScopeID.getAsString());
				}
				pojoPermissionSchemePermissions.setProjectRole(prRole);
			}
			if (permHldrExpand != null) {
				pojoPermissionSchemePermissions.setHolderExpand(permHldrExpand.getAsString());
			}
			pojoPermissionSchemePermissions.setPermission(elmPermPerm.getAsString());
			permissions.put(pojoPermissionSchemePermissions.getId(), pojoPermissionSchemePermissions);
			//System.out.println(permID + "\t" + permHldrTyp + "\t" + permPerm);
		}
		pojoPermissionScheme.setPermissions(permissions);
		return pojoPermissionScheme;
	}

	public HashMap<String, PojoPermission> jiraRestApiPermissions(String anJsonLine) {
		//{"permissions": {"ADD_COMMENTS": {
		//	"key": "ADD_COMMENTS",
		//	"name": "Add Comments",
		//	"type": "PROJECT",
		//	"description": "Ability to comment on issues."
		//	},
		HashMap<String, PojoPermission> permissions = new HashMap<String, PojoPermission>();
		PojoPermission perm = null;
		JsonElement allElements = new JsonParser().parse(anJsonLine);
		JsonObject fullObect = allElements.getAsJsonObject();
		JsonElement members = fullObect.get("permissions");
		JsonObject jsonObject = members.getAsJsonObject(); // Parse the JSON string into a JsonObject
		for (String key : jsonObject.keySet()) { //-- Loop through the members of the JSON object
			JsonElement value = jsonObject.get(key);
			JsonObject obj = value.getAsJsonObject();
			perm = new PojoPermission();
			perm.setRootkey(key);
			perm.setKey(obj.get("key").toString());
			perm.setName(obj.get("name").toString());
			perm.setType(obj.get("type").toString());
			perm.setDescription(obj.get("description").toString());
			permissions.put(key, perm);
			//System.out.println("Key: " + key + ", Value: " + value);
		}
		return permissions;
	}

	//------------------------------------------------------------------------------------------------------
	//------------------------------------------------------------------------------------------------------
	//------------------------------------------------------------------------------------------------------

	public HashMap<String, PojoUser> jiraRestApiUsers(String anJsonLine) {
		//--the function serve two input json format = with root element '"users": [{...' and with no users, just noname aray: '[{...'
		//--compare next two lines: 
		//"users": [{
		//[{
		// "from": "https://brighttunnel.atlassian.net/rest/api/3/user/picker?query={}",
		//	"self": "https://brighttunneldev.atlassian.net/rest/api/2/user?accountId=5a90f92154c8ff39bc24672d",
		//	"accountId": "5a90f92154c8ff39bc24672d",
		//	"accountType": "atlassian",
		//	"html": "Valeri Tikhonov - tikhboda@gmail.com",
		//	"emailAddress": "tikhboda@gmail.com",
		//	"avatarUrls": {
		//		"48x48": "https://secure.gravatar.com/avatar/48e846014a75aa8df418b75b190e6a1d?d=https%3A%2F%2Favatar-management--avatars.us-west-2.prod.public.atl-paas.net%2Finitials%2FVT-0.png",
		//	},
		//	"displayName": "Valeri Tikhonov",
		//	"active": true,
		//	"locale": "en_US"
		//},...
		JsonElement allElements = new JsonParser().parse(anJsonLine);
		JsonArray jarray = null;

		// {"errorMessages":["The group with group ID 'f52c0c36-1fec-441d-8dd0-6eec9c08fb8c' does not exist"],"errors":{}}

		if (allElements.isJsonObject()) {
			JsonObject rootObject = allElements.getAsJsonObject();
			JsonElement error = rootObject.get("errorMessages");
			if (error != null) {
				return null;
			} else {
				JsonElement rootUsers = rootObject.get("users");
				JsonElement rootValues = rootObject.get("values");
				if (rootUsers != null) {
					if (rootUsers.isJsonObject()) {
						allElements = rootUsers;
						JsonObject subRootObject = rootUsers.getAsJsonObject();
						JsonElement subRootUsers = subRootObject.get("users");
						if (subRootUsers != null) {
							jarray = subRootUsers.getAsJsonArray();
						}
					} else {
						jarray = rootUsers.getAsJsonArray();
					}
				}
				if (rootValues != null) {
					if (rootValues.isJsonArray()) {
						jarray = rootValues.getAsJsonArray();
					}
				}
			}
		} else if (allElements.isJsonArray()) {
			jarray = allElements.getAsJsonArray();
		}
		HashMap<String, PojoUser> theusers = new HashMap<String, PojoUser>();
		PojoUser pjUser = null;
		for (int ii = 0; ii < jarray.size(); ii++) {
			pjUser = mapJsonToPojoUser(jarray.get(ii).getAsJsonObject());
			theusers.put(pjUser.getAccountId(), pjUser);
			//System.out.println(pjUser.getAccountId() + "\t" + pjUser.getAccountType() + "\t" + pjUser.getEmailAddress());
		}
		return theusers;
	}

	PojoUser mapJsonToPojoUser(JsonObject perm) {
		PojoUser pjUser = null;
		JsonElement self = perm.get("self");
		JsonElement accountId = perm.get("accountId");
		JsonElement accountType = perm.get("accountType");
		JsonElement emailAddress = perm.get("emailAddress");
		JsonElement html = perm.get("html");
		JsonElement displayName = perm.get("displayName");
		JsonElement active = perm.get("active");
		JsonElement timeZone = perm.get("timeZone");
		JsonElement locale = perm.get("locale");
		pjUser = new PojoUser();
		if (self != null) {
			pjUser.setSelf(self.getAsString());
		}
		pjUser.setAccountId(accountId.getAsString());
		pjUser.setAccountType(accountType.getAsString());
		if (emailAddress != null) {
			pjUser.setEmailAddress(emailAddress.getAsString());
		}
		if (html != null) {
			pjUser.setHtml(html.getAsString());
		}
		if (displayName != null) {
			pjUser.setDisplayName(displayName.getAsString());
		}
		if (active != null) {
			pjUser.setActive(active.getAsBoolean());
		}
		if (locale != null) {
			//pjUser.setLocale(locale.getAsString());
		}
		return pjUser;
	}

	public PojoUser jiraRestApiUserGroupsApplicationRoles(PojoUser pojoUser, String anJsonLine) {
		// "from": "https://brighttunnel.atlassian.net/rest/api/latest/groups/picker",
		PojoGroup pojoUserGroupsApplicationRoles = null;
		PojoGroupLabels pojoGroupLabels = null;
		HashMap<String, PojoGroup> groups = new HashMap<String, PojoGroup>();
		HashMap<String, PojoApplicationRole> applicationRoles = null;
		HashMap<String, PojoGroupLabels> labels = null;
		JsonElement allElements = new JsonParser().parse(anJsonLine);
		JsonArray arrGroups = null;
		JsonArray arrApplicationRoles = null;
		if (allElements.isJsonArray()) {
			arrGroups = allElements.getAsJsonArray();
		} else {
			JsonObject fullObect = allElements.getAsJsonObject();
			if (fullObect.isJsonArray()) {
				arrGroups = fullObect.getAsJsonArray("groups");
			} else {
				JsonElement elmGroups = fullObect.get("groups");
				if (elmGroups != null) {
					if (elmGroups.isJsonArray()) {
						arrGroups = elmGroups.getAsJsonArray();
					} else {
						JsonObject objGroups = elmGroups.getAsJsonObject();
						if (objGroups != null) {
							arrGroups = objGroups.getAsJsonArray("items");
						}
					}
				}
				JsonElement elmValues = fullObect.get("values");
				if (elmValues != null) {
					if (elmValues.isJsonArray()) {
						arrGroups = elmValues.getAsJsonArray();
					} else {
						JsonObject objGroups = elmGroups.getAsJsonObject();
						if (objGroups != null) {
							arrGroups = objGroups.getAsJsonArray("items");
						}
					}
				}
				JsonElement elmApplicationRoles = fullObect.get("applicationRoles");
				if (elmApplicationRoles != null) {
					if (elmApplicationRoles.isJsonArray()) {
						arrApplicationRoles = elmApplicationRoles.getAsJsonArray();
					} else {
						JsonObject objApplicationRoles = elmApplicationRoles.getAsJsonObject();
						if (objApplicationRoles != null) {
							arrApplicationRoles = objApplicationRoles.getAsJsonArray("items");
						}
					}
					applicationRoles = jiraRestApiApplicationRoles(arrApplicationRoles);
				}
			}
		}
		for (int ii = 0; ii < arrGroups.size(); ii++) {
			JsonObject perm = arrGroups.get(ii).getAsJsonObject();
			JsonElement permName = perm.get("name");
			JsonElement permHtml = perm.get("html");
			JsonArray permLabels = perm.getAsJsonArray("labels");
			JsonElement permGroupId = perm.get("groupId");

			pojoUserGroupsApplicationRoles = new PojoGroup();
			if (permName != null) {
				pojoUserGroupsApplicationRoles.setName(permName.getAsString());
			}
			if (permHtml != null) {
				pojoUserGroupsApplicationRoles.setHtml(permHtml.getAsString());
			}
			if (permGroupId != null) {
				pojoUserGroupsApplicationRoles.setGroupId(permGroupId.getAsString());
			}
			if (permLabels != null) {
				labels = new HashMap<String, PojoGroupLabels>();
				for (int jj = 0; jj < permLabels.size(); jj++) {
					JsonObject prm = permLabels.get(jj).getAsJsonObject();
					JsonElement permText = prm.get("text");
					JsonElement permTitle = prm.get("title");
					JsonElement permType = prm.get("type");
					pojoGroupLabels = new PojoGroupLabels();
					pojoGroupLabels.setText(permText.getAsString());
					pojoGroupLabels.setTitle(permTitle.getAsString());
					pojoGroupLabels.setType(permType.getAsString());
					labels.put(pojoGroupLabels.getText(), pojoGroupLabels);
					//System.out.println(permID + "\t" + permHldrTyp + "\t" + permPerm);
				}
			} else {
				labels = null;
			}
			pojoUserGroupsApplicationRoles.setLabels(labels);
			groups.put(pojoUserGroupsApplicationRoles.getGroupId(), pojoUserGroupsApplicationRoles);
			//System.out.println(ii + ": " + permName + " " + permLabels);
		}
		pojoUser.setGroups(groups);
		pojoUser.setApplicationRoles(applicationRoles);
		return pojoUser;
	}

	HashMap<String, PojoApplicationRole> jiraRestApiApplicationRoles(JsonArray arrApplicationRoles) {
		HashMap<String, PojoApplicationRole> pojoApplicationRoles = null;
		if (arrApplicationRoles != null) {
			pojoApplicationRoles = new HashMap<String, PojoApplicationRole>();
			PojoApplicationRole pojoApplicationRole = null;
			for (int ii = 0; ii < arrApplicationRoles.size(); ii++) {
				JsonObject objApplicationRole = arrApplicationRoles.get(ii).getAsJsonObject();
				JsonElement elmKey = objApplicationRole.get("key");
				JsonElement elmName = objApplicationRole.get("name");
				pojoApplicationRole = new PojoApplicationRole();
				if (elmKey != null) {
					pojoApplicationRole.setKey(elmKey.getAsString());
				}
				pojoApplicationRole.setName(elmName.getAsString());
				pojoApplicationRoles.put(pojoApplicationRole.getKey(), pojoApplicationRole);
			}
		}
		return pojoApplicationRoles;
	}

	//------------------------------------------------------------------------------------------------------
	//---Utils-----------------------------------------------------------------------------------------------
	//------------------------------------------------------------------------------------------------------

	Long getIDFromThePath(String aPath) {
		Long id = 0L;
		//--extract 10004 from "https://site.atlassian.net/rest/api/2/project/10000/role/10004",
		String ids = aPath.substring(aPath.lastIndexOf("/") + 1);
		id = Long.parseLong(ids);
		return id;
	}

}
