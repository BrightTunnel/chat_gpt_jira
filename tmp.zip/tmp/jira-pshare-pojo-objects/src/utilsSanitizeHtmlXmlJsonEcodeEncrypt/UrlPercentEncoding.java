package utilsSanitizeHtmlXmlJsonEcodeEncrypt;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;

public class UrlPercentEncoding {
	
	public static final String urlPercentEncoding(String url) {
		///~~ https://www.w3schools.com/tags/ref_urlencode.ASP
		///	space: %20, !: %21, ": %22, #: %23, $: %24, %: %25... 
		//~~~ Also check Ampersand coding:  &quot; &apos; &lt; &gt; &amp;
		boolean ISDEBUG = !true;
		String result = null;
		if (url != null && url.length() > 1) {
			if (url.startsWith("?")) {
				//url = url.substring(1); ///~~ Remove first '?'
			}
			if (url.contains("%")) {
				///~~ Eliminate wrong codes (above %FF) 
				String capsUrl = url.toUpperCase();
				StringBuilder rebuiltUrl = new StringBuilder();
				for (int ii = 0; ii < url.length() - 2; ii++) { //~~~ till last '%' and two characters after
					if (url.substring(ii, ii + 1).compareTo("%") == 0) {
						if (capsUrl.substring(ii + 1, ii + 2).compareTo("F") > 0) {
							rebuiltUrl.append("%25"); //~~ replace % width %25
						} else {
							rebuiltUrl.append("%");
						}
					} else {
						rebuiltUrl.append(url.substring(ii, ii + 1));
					}
				}
				rebuiltUrl.append(url.substring(url.length() - 2, url.length())); // Add last two chars
				url = rebuiltUrl.toString();
				//rebuiltUrl = null;
				try {
					result = java.net.URLDecoder.decode(url, StandardCharsets.UTF_8.name());
					if (result.contains("%2F")) {
						result = result.replaceAll("%2F", "/");
					}
				} catch (UnsupportedEncodingException e) { // sorry, value came from JDK's own StandardCharsets
				} catch (Exception e) { // sorry, value came from JDK's own StandardCharsets
					if (ISDEBUG) System.out.println("~ERROR: Illegal hex characters in escape (%) pattern / Percent Encoding (e.g.: %G', or '%Pr')\n\tin:" + url + "\n\tException:" + e.getMessage());
				} finally {
					// System.out.println("~~URL: " + url + "\n");
				}
			} else {
				return url;
			}
		}
		return result;
	}

}
