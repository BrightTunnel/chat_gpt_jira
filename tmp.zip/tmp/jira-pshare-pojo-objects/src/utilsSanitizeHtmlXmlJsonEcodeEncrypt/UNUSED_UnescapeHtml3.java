package utilsSanitizeHtmlXmlJsonEcodeEncrypt;

import java.io.StringWriter;
import java.util.HashMap;

public class UNUSED_UnescapeHtml3 {
	// https://stackoverflow.com/questions/994331/how-to-unescape-html-character-entities-in-java
	// https://www.npmjs.com/package/html-entities {html-entities, Fastest HTML entities library}

	private static final int MIN_ESCAPE = 2;
	private static final int MAX_ESCAPE = 6;

	private static final String UNUSED_unescapeHtml3(final String input) {
		StringWriter writer = null;
		int len = input.length();
		int i = 1;
		int st = 0;
		while (true) {
			// look for '&'
			while (i < len && input.charAt(i - 1) != '&')
				i++;
			if (i >= len)
				break;
			// found '&', look for ';'
			int j = i;
			while (j < len && j < i + MAX_ESCAPE + 1 && input.charAt(j) != ';')
				j++;
			if (j == len || j < i + MIN_ESCAPE || j == i + MAX_ESCAPE + 1) {
				i++;
				continue;
			}
			// found escape
			if (input.charAt(i) == '#') {
				// numeric escape
				int k = i + 1;
				int radix = 10;
				final char firstChar = input.charAt(k);
				if (firstChar == 'x' || firstChar == 'X') {
					k++;
					radix = 16;
				}
				try {
					int entityValue = Integer.parseInt(input.substring(k, j), radix);
					if (writer == null)
						writer = new StringWriter(input.length());
					writer.append(input.substring(st, i - 1));
					if (entityValue > 0xFFFF) {
						final char[] chrs = Character.toChars(entityValue);
						writer.write(chrs[0]);
						writer.write(chrs[1]);
					} else {
						writer.write(entityValue);
					}
				} catch (NumberFormatException ex) {
					i++;
					continue;
				}
			} else {
				// named escape
				CharSequence value = lookupMap.get(input.substring(i, j));
				if (value == null) {
					i++;
					continue;
				}

				if (writer == null)
					writer = new StringWriter(input.length());
				writer.append(input.substring(st, i - 1));

				writer.append(value);
			}
			// skip escape
			st = j + 1;
			i = st;
		}
		if (writer != null) {
			writer.append(input.substring(st, len));
			return writer.toString();
		}
		return input;
	}

	// Call: String _s = UnescapeHtml3.unescapeHtml3("<p>a&#10;&nbsp;b&lt;p&gt;");

	private static final String[][] ESCAPES = { //
			{" ", "nbsp"}, // space
			{"\"", "quot"}, // " - double-quote
			{"'", "apos"}, // ' Apostrophe 
			{"&", "amp"}, // '&' - Ampersand
			{"<", "lt"}, // < - Less-Than
			{">", "gt"}, // > - Greater-Than
			{"\r", "#10"}, // "\r?\n"
			// &#xd;
			//~~Mapping to escape ISO-8859-1 characters to their named HTML 3.x equivalents.
			{"\u00A0", "nbsp"}, // non-breaking space
			{"\u00A1", "iexcl"}, // inverted exclamation mark
			{"\u00A2", "cent"}, // cent sign
			{"\u00A3", "pound"}, // pound sign
			{"\u00A4", "curren"}, // currency sign
			{"\u00A5", "yen"}, // yen sign = yuan sign
			{"\u00A6", "brvbar"}, // broken bar = broken vertical bar
			{"\u00A7", "sect"}, // section sign
			{"\u00A8", "uml"}, // diaeresis = spacing diaeresis
			{"\u00A9", "copy"}, // � - copyright sign
			{"\u00AA", "ordf"}, // feminine ordinal indicator
			{"\u00AB", "laquo"}, // left-pointing double angle quotation mark = left pointing guillemet
			{"\u00AC", "not"}, // not sign
			{"\u00AD", "shy"}, // soft hyphen = discretionary hyphen
			{"\u00AE", "reg"}, // � - registered trademark sign
			{"\u00AF", "macr"}, // macron = spacing macron = overline = APL overbar
			{"\u00B0", "deg"}, // degree sign
			{"\u00B1", "plusmn"}, // plus-minus sign = plus-or-minus sign
			{"\u00B2", "sup2"}, // superscript two = superscript digit two = squared
			{"\u00B3", "sup3"}, // superscript three = superscript digit three = cubed
			{"\u00B4", "acute"}, // acute accent = spacing acute
			{"\u00B5", "micro"}, // micro sign
			{"\u00B6", "para"}, // pilcrow sign = paragraph sign
			{"\u00B7", "middot"}, // middle dot = Georgian comma = Greek middle dot
			{"\u00B8", "cedil"}, // cedilla = spacing cedilla
			{"\u00B9", "sup1"}, // superscript one = superscript digit one
			{"\u00BA", "ordm"}, // masculine ordinal indicator
			{"\u00BB", "raquo"}, // right-pointing double angle quotation mark = right pointing guillemet
			{"\u00BC", "frac14"}, // vulgar fraction one quarter = fraction one quarter
			{"\u00BD", "frac12"}, // vulgar fraction one half = fraction one half
			{"\u00BE", "frac34"}, // vulgar fraction three quarters = fraction three quarters
			{"\u00BF", "iquest"} // inverted question mark = turned question mark
	};

	private static final HashMap<String, CharSequence> lookupMap;
	static {
		lookupMap = new HashMap<String, CharSequence>();
		for (final CharSequence[] seq : ESCAPES)
			lookupMap.put(seq[1].toString(), seq[0]);
	}
}
