package utilsSanitizeHtmlXmlJsonEcodeEncrypt;

import java.io.IOException;
import java.io.OutputStream;
import java.io.StringReader;
import java.util.HashMap;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import jiraConstants.ConstXmlElementsBackupJira.XmlElemt;
import jiraPojoXml.PojoXmlAttribute;

public class UtilsXml {

	public final static Document convertStringToXMLDocument(String xmlString) {
		// Parser that produces DOM object trees from XML content
		if (xmlString != null) {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			// ~~ API to obtain DOM Document instance
			DocumentBuilder builder = null;
			try {
				// ~~ Create DocumentBuilder with default configuration
				builder = factory.newDocumentBuilder();
				// ~~ Parse the content to Document object
				Document doc = null;
				try {
					xmlString = preprocessToPreventSAXExceptionXmlEntityWasReferencedButNotDeclared(xmlString);
					if (xmlString != null) {
						doc = builder.parse(new InputSource(new StringReader(xmlString)));
					} else {
						return null;
					}
				} catch (Exception e) {
					System.out.println("ErrAkdsfjhp9Z Error parsing xml: " + xmlString);
				}
				return doc;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public final static String preprocessToPreventSAXExceptionXmlEntityWasReferencedButNotDeclared(String anElement) {
		//~~ https://itecnote.com/tecnote/xml-entity-was-referenced-but-not-declared/ ~~Xml - Entity was referenced but not declared
		//~~ To prevent SAXException: 'The entity "ndash" was referenced, but not declared.'
		String ret = anElement;
		final String exclude = "&ndash;";
		if (anElement != null && anElement.length() > exclude.length() && anElement.indexOf(exclude) > -1) {
			ret = anElement.replace(exclude, "-");
		}
		return ret;
	}

	public final static String CleanInvalidXmlChars(String text) {
		//~~ To eliminate Error message when an XML document contains Low-Order ASCII characters (characters below ASCII 32) 'An Invalid character was found in text content.'
		// https://learn.microsoft.com/en-us/previous-versions/troubleshoot/msxml/error-when-xml-contains-low-order-ascii
		// https://stackoverflow.com/questions/730133/what-are-invalid-characters-in-xml
		// https://stackoverflow.com/questions/4237625/removing-invalid-xml-characters-from-a-string-in-java
		// From xml spec valid chars: 
		// #x09 | #x0A | #x0D | [#x20-#xD7FF] | [#xE000-#xFFFD] | [#x10000-#x10FFFF]
		// any Unicode character, excluding the surrogate blocks, FFFE, and FFFF.
		// x09 - ht, tab
		// x0A - nl, lf
		// x0D - cr
		if (null == text || text.isEmpty()) {
			return text;
		}
		final int len = text.length();
		char current = 0;
		int codePoint = 0;
		StringBuilder sb = new StringBuilder();
		for (int ii = 0; ii < len; ii++) {
			current = text.charAt(ii);
			boolean surrogate = false;
			if (Character.isHighSurrogate(current) && ii + 1 < len && Character.isLowSurrogate(text.charAt(ii + 1))) {
				surrogate = true;
				codePoint = text.codePointAt(ii++);
			} else {
				codePoint = current;
			}

			// Error importing data: org.xml.sax.SAXException: com.atlassian.jira.exception.DataAccessException: org.ofbiz.core.entity.GenericEntityException: while inserting:
			// [GenericEntity:Avatar][owner,JIRAUSER14970][fileName,2022-04-06 15_17_40-IMG_9734.jpeg - Photosjrvtg.png][systemAvatar,0][id,18110][avatarType,user][contentType,image/png]
			// (SQL Exception while executing the following:INSERT INTO public.avatar (ID, filename, contenttype, avatartype, owner, systemavatar) VALUES (?, ?, ?, ?, ?, ?)
			// (ERROR: character with byte sequence 0xE2 0x80 0x8E in encoding "UTF8" has no equivalent in encoding "WIN1252")) 
			// LRM

			// https://www.rapidtables.com/code/text/ascii-table.html
			if ((codePoint == 0x9) // 			0x09		&#9; 		HT 	Horizontal Tab
					|| (codePoint == 0xA) // 	0x0A 	&#10; 		LF 	Line Feed
					|| (codePoint == 0xD) //	0x0D	&#13; 		CR 	Carriage Return
					|| ((codePoint >= 0x20) && (codePoint < 0x7F)) // 0x7F DEL 127 	&#127; Delete
					// Exclude all in: [0x80-0xFF] [128-255] e.g: 0xFF &#255; �
					// to avoid: ERROR: character with byte sequence 0xE2 0x80 0x8E in encoding "UTF8" has no equivalent in encoding "WIN1252" (see example above)
					//|| ((codePoint > 0x7F) && (codePoint < 0xA0)) // 0xA0 NBSP 		&#160;
					//|| ((codePoint > 0xA0) && (codePoint < 0xFF)) // 0xFF NBSP		&#255;
					|| ((codePoint > 0xFF) && (codePoint < 0xC2A0)) // Hex 0xC2A0 is UTF8 for non-breaking space NBSP

					//|| ((codePoint >= 0x20) && (codePoint <= 0xD7FF))					
					|| ((codePoint > 0xC2A0) && (codePoint <= 0xD7FF)) //
					|| ((codePoint >= 0xE000) && (codePoint <= 0xFFFD)) //
					|| ((codePoint >= 0x10000) && (codePoint <= 0x10FFFF))) {
				sb.append(current);
				if (surrogate) {
					sb.append(text.charAt(ii));
				}
			} else {
				//System.err.println("ERR: " + codePoint);
			}
		}
		return sb.toString();
	}

	public final static String findXmlElementTagNameOrNull(String aLine) {
		String _elementName = null;
		String _entityFirstLetter;
		int _idxOfNextSpace;
		int _idxOfNextGt;
		int _idxOfTagEnd = -1;
		if (aLine != null) {
			aLine = aLine.trim();
			if (aLine.length() > 3 //
					&& aLine.startsWith("<") //
					&& !aLine.startsWith("</") // closing tag eg: </servicedesk> 
					&& !aLine.startsWith("<?") // eg: <?xml version="1.0" encoding="UTF-8"?>
					&& !aLine.startsWith("<!") // eg: <!DOCTYPE workflow PUBLIC "-//OpenSymphony Group//DTD OSWorkflow 2.8//EN" "http://www.opensymphony.com/osworkflow/workflow_2_8.dtd">
					&& !aLine.startsWith("<!--")) { // comment
				_entityFirstLetter = aLine.substring(1, 2);
				if (true || _entityFirstLetter.matches("[A-Z]{1}")) { //~~ XML Element must be major (first letter - capital)
					_idxOfNextSpace = aLine.indexOf(" ");
					_idxOfNextGt = aLine.indexOf(">");
					if (_idxOfNextSpace == -1) { // ~~ No space found in this line, so likely this is the empty XML Element like: <TagName/>
						if (aLine.endsWith("/>")) {
							_elementName = aLine.substring(1, aLine.length() - 2);
							return _elementName;
						} else if (aLine.endsWith(">")) {
							//~~ just plain opening xml tag like: '<database>'
							_elementName = aLine.substring(1, aLine.length() - 1);
							return _elementName;
						} else {
							System.err.println("ErrXmlGeneric94853049 " + aLine);
						}
					} else {
						if (_idxOfNextSpace > 0 && _idxOfNextGt > 0) {
							_idxOfTagEnd = Math.min(_idxOfNextSpace, _idxOfNextGt);
						} else {
							_idxOfTagEnd = Math.max(_idxOfNextSpace, _idxOfNextGt);
						}
					}
					_elementName = aLine.substring(1, _idxOfTagEnd);
				}
			}
		}
		//System.out.println("~~~Found Element '" + _elementName + "' in line: " + aLine);
		return _elementName;
	}

	public final static HashMap<String, PojoXmlAttribute> extractElementAttributes(String aXmlElement) {
		if (aXmlElement != null) {
			HashMap<String, PojoXmlAttribute> _atrs = null;
			PojoXmlAttribute _atr = null;
			Document dom = convertStringToXMLDocument(aXmlElement);
			if (dom == null) {
				return null;
			}
			NamedNodeMap attributes = dom.getFirstChild().getAttributes();
			if (attributes != null) {
				// System.out.println("== Attributes: " + attributes.getLength());
				for (int a = 0; a < attributes.getLength(); a++) {
					Node theAttribute = attributes.item(a);
					_atr = new PojoXmlAttribute();
					_atr.setAttributeName(theAttribute.getNodeName());
					_atr.setAttributeValue(theAttribute.getNodeValue());
					if (_atrs == null) {
						_atrs = new HashMap<String, PojoXmlAttribute>();
					}
					_atrs.put(_atr.getAttributeName(), _atr);
					// System.out.println(theAttribute.getNodeName() + "=" + theAttribute.getNodeValue());
				}
			}
			return _atrs;
		} else {
			return null;
		}
	}

	public static DocumentBuilder buildDocumentBuilder() {
		DocumentBuilder _dBuilder = null;
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		dbFactory.setNamespaceAware(false);
		try {
			dbFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
			_dBuilder = dbFactory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		}
		return _dBuilder;
	}

	private Document loadXMLFromString(String xml) {
		//~~ this is slow. look at the DocumentBuilder buildDocumentBuilder() above 
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance(); //~~ Instantiate the Factory
		try {
			factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true); // optional, but recommended -- process XML securely, avoid attacks like XML External Entities (XXE)
			DocumentBuilder builder = factory.newDocumentBuilder();
			InputSource is = new InputSource(new StringReader(xml));
			try {
				return builder.parse(is);
			} catch (SAXException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static void writeXml(Document doc, OutputStream output) throws TransformerException {
		//~~ https://mkyong.com/java/how-to-create-xml-file-in-java-dom/ ~~How to write XML file in Java � (DOM Parser)
		//~~ Write XML to a file, write doc to output stream
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(output);
		transformer.transform(source, result);
	}

	private final void UNUSED_extractElementAndAttributesByTagName(String aXmlElement, String anElement) {
		Document dom = convertStringToXMLDocument(aXmlElement);
		anElement = XmlElemt.CustomField.toString();
		NodeList _nodeList = dom.getElementsByTagName(anElement);
		NamedNodeMap attributes;
		// System.out.println("==== TagName: '" + aTagName + "', node list length: " + _nodeList.getLength() + ", Orig: '" + aXmlElement + "'");
		for (int i = 0; i < _nodeList.getLength(); i++) {
			Node _node = _nodeList.item(i);
			if (_node != null) {
				// System.out.println("=== Node [" + i + "] name: " + _node.getNodeName());
				if (_node.getFirstChild() != null) {
					// System.out.println("== First Child: '" + _node.getFirstChild().getNodeName() + "' value: '" + _node.getFirstChild().getNodeValue() + "'");
					// System.out.println("== Next Child: '" + _node.getChildNodes().item(1).getNodeName() + "' value: '" + _node.getChildNodes().item(1) + "'");
				}
				attributes = _node.getAttributes();
				if (attributes != null) {
					// System.out.println("== Attributes: " + attributes.getLength());
					for (int a = 0; a < attributes.getLength(); a++) {
						Node theAttribute = attributes.item(a);
						// System.out.println(theAttribute.getNodeName() + "=" + theAttribute.getNodeValue());
					}
				}
			}
		}
	}

	private final String UNUSED_getElementValue(Node elem) {
		Node kid;
		if (elem != null) {
			if (elem.hasChildNodes()) {
				for (kid = elem.getFirstChild(); kid != null; kid = kid.getNextSibling()) {
					if (kid.getNodeType() == Node.TEXT_NODE) {
						//System.out.println("~~kid: " + kid.getParentNode().getNodeName() + "=" + kid.getTextContent()); // '~~kid: string={summary}' ///
						return kid.getNodeValue();
					}
				}
			}
		}
		return "";
	}

	// ~~ Print out all nodes/elements ~~
	// NodeList nList = doc.getElementsByTagName("*");
	// for (int i = 0; i < nList.getLength(); i++) {
	// Node node = nList.item(i);
	// Element element = (Element) node;
	// System.out.println(element.getNodeName() + ": " + element.getAttribute("name"));
	// }

}
