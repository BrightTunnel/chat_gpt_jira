package utilsSanitizeHtmlXmlJsonEcodeEncrypt;

import java.util.Base64;

import utilsGlobal.UtilsGeneral;

public class Base64EcodingDecoding {
	///~~ https://stackoverflow.com/questions/8571501/how-to-check-whether-a-string-is-base64-encoded-or-not
	private static final String b64 = "YCFg";
	private static final String b64asc = "`!`";

	public static final String decodeB64(String anBase64EncodedString, boolean isClearPrefix) {
		String asciiString = anBase64EncodedString;
		if (anBase64EncodedString != null) {
			if (anBase64EncodedString.startsWith(b64)) {
				anBase64EncodedString = anBase64EncodedString.substring(b64.length());
				byte[] decodedBytes = Base64.getDecoder().decode(anBase64EncodedString);
				String decodedString = new String(decodedBytes);
				decodedString = decodedString.replace("\r", "");
				decodedString = decodedString.replace("\n", "");
				if (isClearPrefix) {
					asciiString = decodedString; //~~ Add `!` as a search key	
				} else {
					asciiString = b64asc + decodedString; //~~ Add `!` as a search key
				}
			}
			asciiString = UtilsGeneral.cleanAmpersandCoding(asciiString);
		}
		return asciiString;
	}
}
