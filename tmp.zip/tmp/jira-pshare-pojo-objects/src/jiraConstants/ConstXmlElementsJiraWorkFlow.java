package jiraConstants;

public class ConstXmlElementsJiraWorkFlow {

	///~~~ elements having 'customfield_':
	///<arg name="field">customfield_10201</arg>
	///<arg name="field.copyFieldDestination1">customfield_10710</arg>
	///<arg name="field.name">customfield_10728</arg>
	///<arg name="field.selected">customfield_10704</arg>
	///<arg name="fields.list">customfield_10710</arg>
	///<arg name="hid.fields.list">customfield_11100@@customfield_10707@@</arg>

	///~~~ elements having Base64 groovy or other script, with prefix 'YCFg' `!`
	///<arg name="FIELD_CONDITION">YCFg...
	///<arg name="FIELD_EMAIL_SUBJECT_TEMPLATE">YCFg..
	///<arg name="FIELD_EMAIL_TEMPLATE">YCFg..
	///<arg name="FIELD_INCLUDE_ATTACHMENTS_CALLBACK">YCFg..
	///<arg name="FIELD_NOTES">YCFg..
	///<arg name="FIELD_SCRIPT_FILE_OR_SCRIPT">YCFg..

	///~~ Use Examples: 
	///<condition type="class">
	///		<arg name="class.name">com.googlecode.jsu.workflow.condition.ValueFieldCondition</arg>
	///</condition>
	///<validator name="" type="class">
	///		<arg name="class.name">com.googlecode.jsu.workflow.validator.FieldsRequiredValidator</arg>
	///</validator>

	///~~Cases:
	/// initial-actions/action/restrict-to/conditions/condition/arg
	/// initial-actions/action/validators/validator/arg
	/// initial-actions/action/results/unconditional-result/post-functions/function/arg
	/// global-actions/action/restrict-to/conditions/condition/arg
	/// global-actions/action/validators/validator/arg
	/// global-actions/action/results/unconditional-result/post-functions/function/arg
	/// common-actions/action/restrict-to/conditions/condition/arg
	/// common-actions/action/validators/validator/arg
	/// common-actions/action/results/unconditional-result/post-functions/function/arg
	/// steps/step/actions/action/restrict-to/conditions/condition/arg
	/// steps/step/actions/action/validators/validator/arg
	/// steps/step/actions/action/results/unconditional-result/post-functions/function/arg

	public static enum XmlWFElemt {
		///~~ WorkFlow xml elements ~~
		workflow("workflow"), //
		///~~ WorkFlow xml elements ~~
		id("id"), //
		name("name"), //
		type("type"), //
		oldStatus("old-status"), //
		status("status"), //

		/// Top level WF XML segments: [meta, initial-actions, global-actions, common-actions, steps]
		meta("meta"), //
		initialActions("initial-actions"), //
		globalActions("global-actions"), //
		commonActions("common-actions"), //
		commonAction("common-action"), //
		steps("steps"), // steps.step.actions
		step("step"), //
		///~~~ Elements
		actions("actions"), //
		action("action"), //
		arg("arg"), //

		///~~ SegmentExecutor: [condition, validator, function], They typically contains active components like JQL, SCRIPT, EMAIL templates, etc
		///	condition: <!-- restrict-to.conditions.condition -->
		restrictTo("restrict-to"), //
		conditions("conditions"), //
		condition("condition"), // <condition type="class">
		validators("validators"), //
		validator("validator"), // <!-- validators.validator -->
		results("results"), //
		unconditionalResult("unconditional-result"), //
		postFunctions("post-functions"), //
		function("function"), //<!-- results.unconditional-result.post-functions.function -->

		lastline("lastline"); //
		private String enumItem;
		XmlWFElemt(String anEnumItem) {
			this.enumItem = anEnumItem;
		}
		public String getEnumStr() {
			return enumItem;
		}
	}

	public static enum xmlWfSection {
		///~~ 'Action' might be one of the listed below: 
		///	condition: <!-- restrict-to.conditions.condition -->
		///	validator: <!-- validators.validator -->
		///	function: <!-- results.unconditional-result.post-functions.function --> 		
		conditions("conditions"), condition("condition"), validator("validator"), function("function");
		private String enumItem;
		xmlWfSection(final String anEnumItem) {
			this.enumItem = anEnumItem;
		}
		public String getEnumStr() {
			return enumItem;
		}
		@Override
		public String toString() {
			return this.getEnumStr();
		}
	}

	public static enum xmlWfNodesFullList {
		///~~ WorkFlow xml attributes values ~~
		//		<post-functions>
		//		<function type="class">
		//			<arg name="FIELD_FUNCTION_ID">7175e6e6-a1b7-46e8-ab19-04309b840a75</arg>
		//			<arg name="FIELD_ACTION">991 Send for AVP Approval</arg>
		//			<arg name="FIELD_NOTES">YCFgQXV0byBzZW5kIGZvciBBVlAgYXBwcm92YWwg</arg>
		//			<arg name="full.module.key">com.onresolve.jira.groovy.groovyrunnerscriptrunner-workflow-function-com.onresolve.scriptrunner.canned.jira.workflow.postfunctions.FasttrackTransition</arg>
		//			<arg name="canned-script">com.onresolve.scriptrunner.canned.jira.workflow.postfunctions.FasttrackTransition</arg>
		//			<arg name="FIELD_CONDITION">YCFgeyJzY3JpcHQiOm51bGwsInNjcmlwdFBhdGgiOiJ3b3JrZmxvd3NcXHBvc3RmdW5jdGlvbnNcXHNpbmdsZVxcYnNzZFxcc29mdHdhcmVBcHByb3ZhbFByb2Nlc3MvQ29uZGl0aW9uRm9yTWFuYWdlckFwcHJvdmFsQW5kQ3VzdG9tZXJSZXF1ZXN0VHlwZUZpZWxkcy5ncm9vdnkiLCJwYXJhbWV0ZXJzIjp7fX0=</arg>
		//			<arg name="class.name">com.onresolve.jira.groovy.GroovyFunctionPlugin</arg>
		//			<arg name="FIELD_TRANSITION_OPTIONS">FIELD_SKIP_PERMISSIONS</arg>
		//			<arg name="events"/>
		//			<arg name="FIELD_ADDITIONAL_SCRIPT"/>
		//		</function>
		//	</post-functions>

		Base64Key("YCFg"), //~~ Very First ASCII Character `!` as a key of the Base64 coded ASCII String
		HTML("HTML"), //~~ <arg name="FIELD_EMAIL_FORMAT">HTML</arg>

		FIELD_("FIELD_"), //~~ Just artificial filter, not present in WF XML file 
		FIELD_ACTION("FIELD_ACTION"), //<arg name="FIELD_ACTION">991 Send for AVP Approval</arg>
		FIELD_ADDITIONAL_SCRIPT("FIELD_ADDITIONAL_SCRIPT"), //
		FIELD_CC_ADDRESSES("FIELD_CC_ADDRESSES"), //
		FIELD_CC_USER_FIELDS("FIELD_CC_USER_FIELDS"), //
		FIELD_COMMENT("FIELD_COMMENT"), //
		FIELD_CONDITION("FIELD_CONDITION"), //<arg name="FIELD_CONDITION">`!`{"script":null,"scriptPath":"workflows\\postfunctions\\single\\bssd\\softwareApprovalProcess/ConditionForManagerApprovalAndCustomerRequestTypeFields.groovy","parameters":{}}</arg>
		FIELD_DISABLE_VALIDATION("FIELD_DISABLE_VALIDATION"), //
		FIELD_EMAIL_FORMAT("FIELD_EMAIL_FORMAT"), //
		FIELD_EMAIL_SUBJECT_TEMPLATE("FIELD_EMAIL_SUBJECT_TEMPLATE"), //<arg name="FIELD_EMAIL_SUBJECT_TEMPLATE">YCFgSXNzdWUgJGlzc3VlIHJlcXVpcmVzIHlvdXIgc2lnbi1vZmY=</arg>
		FIELD_EMAIL_TEMPLATE("FIELD_EMAIL_TEMPLATE"), //
		FIELD_ERROR_MSG("FIELD_ERROR_MSG"), //<arg name="FIELD_ERROR_MSG">Both parent and child fields are mandatory</arg>
		FIELD_FIELD_IDS("FIELD_FIELD_IDS"), //<arg name="FIELD_FIELD_IDS">customfield_13100</arg>
		FIELD_FORM_FIELD("FIELD_FORM_FIELD"), //<arg name="FIELD_FORM_FIELD">customfield_12219</arg>
		FIELD_FROM("FIELD_FROM"), //
		FIELD_FUNCTION_ID("FIELD_FUNCTION_ID"), //<arg name="FIELD_FUNCTION_ID">0205e93b-d6ee-4789-a7ab-0c2ec48a8d05</arg>
		FIELD_INCLUDE_ATTACHMENTS("FIELD_INCLUDE_ATTACHMENTS"), //
		FIELD_INCLUDE_ATTACHMENTS_CALLBACK("FIELD_INCLUDE_ATTACHMENTS_CALLBACK"), //<arg name="FIELD_INCLUDE_ATTACHMENTS_CALLBACK">YCFg</arg> `!`
		FIELD_INTERNAL_COMMENT("FIELD_INTERNAL_COMMENT"), //
		FIELD_JQL_QUERY("FIELD_JQL_QUERY"), //
		FIELD_NOTES("FIELD_NOTES"), // Base64
		FIELD_PREVIEW_ISSUE("FIELD_PREVIEW_ISSUE"), //
		FIELD_REQUIRED_FIELDS("FIELD_REQUIRED_FIELDS"), //<arg name="FIELD_REQUIRED_FIELDS">fixVersions</arg>, <arg name="FIELD_REQUIRED_FIELDS">customfield_10102</arg>
		FIELD_SCRIPT_FILE_OR_SCRIPT("FIELD_SCRIPT_FILE_OR_SCRIPT"), //Base64 <arg name="FIELD_SCRIPT_FILE_OR_SCRIPT">YCFgeyJzY3JpcHQiOm51bGwsInNjcmlwdFBhdGgiOiJ3b3JrZmxvd3NcXHZhbGlkYXRpb25zXFxtdWx0aXBsZS9DaGVja0lmTGlua2VkQ1JUaWNrZXRTdGF0dXNJc0FwcHJvdmVkLmdyb292eSIsInBhcmFtZXRlcnMiOnt9fQ==</arg>
		FIELD_SELECTED_FIELDS("FIELD_SELECTED_FIELDS"), //
		FIELD_SKIP_PERMISSIONS("FIELD_SKIP_PERMISSIONS"), //<arg name="FIELD_TRANSITION_OPTIONS">FIELD_SKIP_PERMISSIONS</arg>
		FIELD_TO_ADDRESSES("FIELD_TO_ADDRESSES"), //<arg name="FIELD_TO_ADDRESSES">Dog@null.com, calvindu@null.com</arg>
		FIELD_TO_USER_FIELDS("FIELD_TO_USER_FIELDS"), //
		FIELD_TRANSITION_OPTIONS("FIELD_TRANSITION_OPTIONS"), //<arg name="FIELD_TRANSITION_OPTIONS">FIELD_SKIP_PERMISSIONS</arg>

		allowUserInField("allowUserInField"), // OkCase
		appendValue("append.value"), //
		approvalActive("approval.active"), // OkCase
		approvalConditionType("approval.condition.type"), // OkCase
		approvalConditionValue("approval.condition.value"), // OkCase
		approvalFieldId("approval.field.id"), //	<meta name="approval.field.id">customfield_11707</meta>
		approvalInsightFieldAttributeName("approval.insight.field.attribute.name"), //
		approvalInsightFieldId("approval.insight.field.id"), //
		approvalTransitionApproved("approval.transition.approved"), //<meta name="approval.transition.approved">1151</meta> OkCase
		approvalTransitionRejected("approval.transition.rejected"), // OkCase
		cannedScript("canned-script"), //<arg name="canned-script">com.onresolve.scriptrunner.canned.jira.workflow.conditions.JqlQueryCondition</arg>, ...
		classDotName("class.name"), // <arg name="class.name">com.atlassian.jira.workflow.function.issue.IssueCreateFunction</arg> OkCase 
		class_("class"), // <condition type="class"><conditions type="AND">
		comparisonType("comparisonType"), // <arg name="comparisonType">1</arg>	OkCase
		concatenateValues("concatenateValues"), //	OkCase
		conditions("conditions"), // Final action OkCase
		conditionList("conditionList"), // <arg name="conditionList">3</arg> OkCase
		conditionValue("conditionValue"), // OkCase
		contextHandling("contextHandling"), //<arg name="contextHandling"></arg> OkCase
		createIssueAsUserUser("createIssueAsUser-user"), // OkCase
		customErrorMessageTextValue("customErrorMessage-textValue"), //<arg name="customErrorMessage-textValue">This field is required.</arg> OkCase
		customMessage("customMessage"), // OkCase
		destinationScopeTarget("destination-scopeTarget"), // OkCase
		disabled("disabled"), // OkCase
		eventTypeId("eventTypeId"), // <arg name="eventTypeId">13</arg> OkCase
		events("events"), // OkCase
		expressionSelected("expressionSelected"), // OkCase
		field("field"), // OkCase
		field2("field2"), // OkCase
		field3("field3"), // OkCase
		field4("field4"), // OkCase
		field5("field5"), // OkCase
		fieldAttachmentEnablingCustomFieldId("field.attachmentEnablingCustomFieldId"), // OkCase
		fieldCopyFieldDestination1("field.copyFieldDestination1"), // OkCase
		fieldCopyFieldDestination2("field.copyFieldDestination2"), // OkCase
		fieldCopyFieldDestination3("field.copyFieldDestination3"), // OkCase
		fieldCopyFieldDestination4("field.copyFieldDestination4"), // OkCase
		fieldCopyFieldDestination5("field.copyFieldDestination5"), // OkCase
		fieldCopyFieldDestination6("field.copyFieldDestination6"), // OkCase
		fieldCopyFieldDestination7("field.copyFieldDestination7"), // OkCase
		fieldCopyFieldMode1("field.copyFieldMode1"), // OkCase
		fieldCopyFieldMode2("field.copyFieldMode2"), // OkCase
		fieldCopyFieldMode3("field.copyFieldMode3"), // OkCase
		fieldCopyFieldMode4("field.copyFieldMode4"), // OkCase
		fieldCopyFieldMode5("field.copyFieldMode5"), // OkCase
		fieldCopyFieldMode6("field.copyFieldMode6"), // OkCase
		fieldCopyFieldMode7("field.copyFieldMode7"), // OkCase
		fieldCopyFieldSeparator1("field.copyFieldSeparator1"), // OkCase
		fieldCopyFieldSeparator2("field.copyFieldSeparator2"), // OkCase
		fieldCopyFieldSeparator3("field.copyFieldSeparator3"), // OkCase
		fieldCopyFieldSeparator4("field.copyFieldSeparator4"), // OkCase
		fieldCopyFieldSeparator5("field.copyFieldSeparator5"), // OkCase
		fieldCopyFieldSeparator6("field.copyFieldSeparator6"), // OkCase
		fieldCopyFieldSeparator7("field.copyFieldSeparator7"), // OkCase
		fieldCopyFieldSource1("field.copyFieldSource1"), // OkCase
		fieldCopyFieldSource2("field.copyFieldSource2"), // OkCase
		fieldCopyFieldSource3("field.copyFieldSource3"), // OkCase
		fieldCopyFieldSource4("field.copyFieldSource4"), // OkCase
		fieldCopyFieldSource5("field.copyFieldSource5"), // OkCase
		fieldCopyFieldSource6("field.copyFieldSource6"), // OkCase
		fieldCopyFieldSource7("field.copyFieldSource7"), // OkCase
		fieldCopyFieldSource8("field.copyFieldSource8"), // OkCase
		fieldCopyTransitionComment("field.copyTransitionComment"), // OkCase
		fieldCreateTargetValue1("field.createTargetValue1"), // OkCase
		fieldCreateTargetValue2("field.createTargetValue2"), // OkCase
		fieldCreateTargetValue3("field.createTargetValue3"), // OkCase
		fieldCreateTargetValue4("field.createTargetValue4"), // OkCase
		fieldCreateTargetValue5("field.createTargetValue5"), // OkCase
		fieldCreateTargetValue6("field.createTargetValue6"), // OkCase
		fieldCreateTargetValue7("field.createTargetValue7"), // OkCase
		fieldEnablingCustomFieldId("field.enablingCustomFieldId"), // OkCase
		fieldExistingAttachmentEnablingCustomFieldId("field.existingAttachmentEnablingCustomFieldId"), // OkCase

		fieldIssueAssignTo("field.issueAssignTo"), //<arg name="field.issueAssignTo">ASSIGN_TO_UNASSIGNED</arg> OkCase
		ASSIGN_TO_UNASSIGNED("ASSIGN_TO_UNASSIGNED"), //<arg name="field.issueAssignTo">ASSIGN_TO_UNASSIGNED</arg>

		fieldName("field.name"), // <arg name="field.name">resolution</arg> OkCase
		fieldDotSelected("field.selected"), //<arg name="field.selected">customfield_10704</arg> OkCase
		fieldSelected("fieldSelected"), // OkCase
		fieldDotValue("field.value"), // <arg name="field.value">%%CURRENT_DATETIME%%</arg> OkCase
		fieldValue("fieldValue"), // <arg name="fieldValue">PMO</arg> OkCase
		fieldsList("fieldsList"), // <arg name="fields.list">customfield_10710</arg> OkCase
		//fieldsList("fields.list"), // <arg name="fields.list">customfield_10710</arg> CheckCase

		fullModuleKey("full.module.key"), // <arg name="full.module.key">com.atlassian.jira.plugin.system.workflowcreatecomment-function</arg> OkCase
		ghVersion("gh.version"), //
		group("group"), // OkCase

		hidFieldsList("hidFieldsList"), //<arg name="hid.fields.list">customfield_11100@@customfield_10707@@</arg> OkCase
		//hidFieldsList("hid.fields.list"), //<arg name="hid.fields.list">customfield_11100@@customfield_10707@@</arg> CheckCase

		hidGroupsList("hidGroupsList"), // OkCase
		hidRolesList("hidRolesList"), // OkCase
		integerValue("integerValue"), // OkCase
		issueTypeId("issueTypeId"), // OkCase

		issuesComparison("issuesComparison"), //<arg name="issuesComparison">MUST_FIND_ISSUES</arg>
		MUST_FIND_ISSUES("MUST_FIND_ISSUES"), //<arg name="issuesComparison">MUST_FIND_ISSUES</arg>
		PARTICULAR_ISSUES("PARTICULAR_ISSUES"), //<arg name="issuesComparison">PARTICULAR_ISSUES</arg>

		jiraDescription("jira.description"), // <meta name="jira.description">Task Management workflow</meta>
		jiraFieldscreenId("jira.fieldscreen.id"), // <meta name="jira.fieldscreen.id">10718</meta> OkCase
		jirai18nDescription("jira.i18n.description"), // OkCase
		jirai18nSubmit("jira.i18n.submit"), // <meta name="jira.i18n.submit">jira.issuetracking.simple.workflow.action.reopen.name</meta> OkCase
		jirai18nTitle("jira.i18n.title"), // OkCase
		jiraIssueEditable("jira.issue.editable"), //
		jiraPermissionCommentUser("jira.permission.comment.user"), //
		jiraProjectroleId("jira.projectrole.id"), // OkCase
		jiraStatusId("jira.status.id"), // <meta name="jira.status.id">10114</meta> OkCase
		jiraUpdateAuthorKey("jira.update.author.key"), // <meta name="jira.update.author.key">JIRAUSER10000</meta> OkCase
		jiraUpdateAuthorName("jira.update.author.name"), //
		jiraUpdatedDate("jira.updated.date"), // <meta name="jira.updated.date">1696639678812</meta> OkCase
		jqlQuery("jqlQuery"), //<arg name="jqlQuery">key = {issue.key} AND ((&quot;ERP Interaction&quot; = No AND Cross-functional = No) OR status = Strategic) </arg> OkCase
		jsuWorkflowParamsVersionTextValue("jsuWorkflowParamsVersion-textValue"), // <arg name="jsuWorkflowParamsVersion-textValue">2.45.0</arg> OkCase
		linkEnd("linkEnd"), // OkCase
		maxAllowedIntegerValue("maxAllowed-integerValue"), // OkCase
		numberChecked("numberChecked"), // OkCase
		numberCheckedOperator("numberCheckedOperator"), // OkCase
		numberExisting("numberExisting"), // OkCase
		numberExistingOperator("numberExistingOperator"), // OkCase
		opsbarSequence("opsbar-sequence"), // OkCase
		performTransitionAsUserUser("performTransitionAsUser-user"), // OkCase
		permission("permission"), // <arg name="permission">Create Issue</arg><arg name="permission">RESOLVE_ISSUES</arg> OkCase
		permissionKey("permissionKey"), // OkCase
		precondition("precondition"), // OkCase
		preconditionAwareFunctionModeTextValue("preconditionAwareFunctionMode-textValue"), // OkCase
		preconditionModeTextValue("preconditionMode-textValue"), // OkCase
		preconditionNegateResultBooleanValue("preconditionNegateResult-booleanValue"), // OkCase
		projectId("projectId"), // OkCase
		rulesData("rulesData"), // OkCase
		runAsUserUser("runAsUser-user"), // OkCase
		scopeDestinationJql("scopeDestination-jql"), //<arg name="scopeDestination-jql">key = {issue.key} AND System in cascadeOption(";Granting";, ";Dynamics";)</arg> OkCase
		scopeDestinationLinkEnd("scopeDestination-linkEnd"), // OkCase
		scopeSourceJql("scopeSource-jql"), // OkCase
		scopeSourceLinkEnd("scopeSource-linkEnd"), // OkCase
		scopeType("scopeType"), // OkCase
		sdResolutionClear("sd.resolution.clear"), //
		sdStepKey("sd.step.key"), //
		sdTourResolveStep("sd.tour.resolve.step"), //
		sdWorkflowKey("sd.workflow.key"), // OkCase
		selectedCustomfieldIds("selectedCustomfieldIds"), // OkCase
		selectedResolutionIds("selectedResolutionIds"), // OkCase
		servicedeskCustomerTransitionActive("servicedesk.customer.transition.active"), //<meta name="servicedesk.customer.transition.active">true</meta> OkCase
		servicedeskCustomerTransitionResolution("servicedesk.customer.transition.resolution"), //
		sourceScopeTarget("source-scopeTarget"), // OkCase
		splitNewline("splitNewline"), // OkCase
		status("status"), // OkCase
		subFunctions("subFunctions"), // OkCase; [{"type":"CopyFieldFromOriginToNew","enabled":true,"config":{"concatenationMode":"OVERWRITE","sourceFieldId":"customfield_12755","destinationFieldId":"summary"}},{"type":"SetField","enabled":true,"config":{"concatenationMode":"APPEND","sourceValue":": Declined : ","destinationFieldId":"summary","separator":" "}},{"type":"SetField","enabled":true,"config":{"concatenationMode":"APPEND","sourceValue":"Update Software Catalogue","destinationFieldId":"summary"}},{"type":"SetField","enabled":true,"config":{"concatenationMode":"OVERWRITE","sourceValue":"Please update software catalogue accordingly. ","destinationFieldId":"description"}},{"type":"SetField","enabled":true,"config":{"concatenationMode":"OVERWRITE","sourceValue":"Software Management","destinationFieldId":"customfield_10800"}},{"type":"CopyFieldFromOriginToNew","enabled":true,"config":{"concatenationMode":"OVERWRITE","sourceFieldId":"customfield_11203","destinationFieldId":"customfield_11203"}}
		targetIssueType("targetIssueType"), // OkCase
		targetIssueTypeDefinedByCfSelection("targetIssueTypeDefinedByCfSelection"), // OkCase
		targetProjectSelectedCustomField("targetProjectSelectedCustomField"), // OkCase
		targetProjectType("targetProjectType"), // OkCase
		textValue("textValue"), // OkCase
		transitionAttachmentsOperation("transitionAttachmentsOperation"), // OkCase
		userKeys("userKeys"), // <arg name="userKeys">JIRAUSER10000</arg> OkCase
		uuid("uuid"), // <arg name="uuid">018d1809-4e92-4a75-a912-89eb9a879e56</arg> OkCase
		validatedItems("validatedItems"), // OkCase
		validationType("validationType"), // OkCase
		workflowNameTextValue("workflowName-textValue"), // OkCase

		lastline("lastline"); //
		private String enumItem;
		///XmlWFValue(final String anEnumItem) {
		xmlWfNodesFullList(String anEnumItem) {
			this.enumItem = anEnumItem;
		}
		public String getEnumStr() {
			return enumItem;
		}
		///@Override
		///public String toString() {return this.getValue();}		
	}

	///~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	public static enum argsToExcludeFromReport {
		FIELD_FUNCTION_ID("FIELD_FUNCTION_ID"), //											
		uuid("uuid"), //
		jsuWorkflowParamsVersionTextValue("jsuWorkflowParamsVersion-textValue"), //
		eventTypeId("eventTypeId"), //
		//classDotName("class.name"), //

		lastline("lastline"); //
		private String enumItem;
		argsToExcludeFromReport(final String anEnumItem) {
			this.enumItem = anEnumItem;
		}
		public String getEnumStr() {
			return enumItem;
		}
		@Override
		public String toString() {
			return this.getEnumStr();
		}
	}

	public static enum metaToExcludeFromReport {
		///~~ This list of nodes <meta>, which are not needed in the report

		approval_active("approval.active"), //<meta name="approval.active">true</meta>
		approval_condition_type("approval.condition.type"), //<meta name="approval.condition.type">percent</meta>
		approval_condition_value("approval.condition.value"), //<meta name="approval.condition.value">100</meta>
		approval_transition_approved("approval.transition.approved"), //<meta name="approval.transition.approved">1151</meta>
		approval_transition_rejected("approval.transition.rejected"), //<meta name="approval.transition.rejected">1111</meta>
		jira_fieldscreen_id("jira.fieldscreen.id"), //<meta name="jira.fieldscreen.id">10718</meta>
		jira_i18n_description("jira.i18n.description"), //<meta name="jira.i18n.description"/>
		jira_i18n_submit("jira.i18n.submit"), //<meta name="jira.i18n.submit"/>
		jira_i18n_title("jira.i18n.title"), //<meta name="jira.i18n.title">common.forms.create</meta>
		jira_status_id("jira.status.id"), //<meta name="jira.status.id">10114</meta>
		jira_update_author_key("jira.update.author.key"), //<meta name="jira.update.author.key">JIRAUSER10000</meta>
		jira_updated_date("jira.updated.date"), //<meta name="jira.updated.date">1694617040777</meta>
		opsbar_sequence("opsbar-sequence"), //<meta name="opsbar-sequence">0</meta>
		sd_workflow_key("sd.workflow.key"), //<meta name="sd.workflow.key">sdItSupport</meta>
		servicedesk_customer_transition_active("servicedesk.customer.transition.active"), //<meta name="servicedesk.customer.transition.active">true</meta>

		lastline("lastline"); //
		private String enumItem;
		metaToExcludeFromReport(final String anEnumItem) {
			this.enumItem = anEnumItem;
		}
		public String getEnumStr() {
			return enumItem;
		}
		@Override
		public String toString() {
			return this.getEnumStr();
		}
	}

}
