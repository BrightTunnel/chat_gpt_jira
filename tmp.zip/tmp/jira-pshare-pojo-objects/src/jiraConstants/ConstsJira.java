package jiraConstants;

import java.util.HashSet;

public class ConstsJira {

	public static enum JiraProjectType {
		software("software"), //
		service_desk("service_desk");

		private String enumItem;
		JiraProjectType(String anEnumItem) {
			this.enumItem = anEnumItem;
		}
		public String getEnumStr() {
			return enumItem;
		}
	}

	public static enum JiraCustomFieldsType {
		// ~~ Custom Field Types
		cfTypeTextfield("com.atlassian.jira.plugin.system.customfieldtypes:textfield"), //
		cfTypeSelect("com.atlassian.jira.plugin.system.customfieldtypes:select"), //
		cfTypeDatepicker("com.atlassian.jira.plugin.system.customfieldtypes:datepicker"), //
		cfTypeMultiuserpicker("com.atlassian.jira.plugin.system.customfieldtypes:multiuserpicker"), //
		cfTypeMultiCheckBoxes("com.atlassian.jira.plugin.system.customfieldtypes:multicheckboxes"), //
		cfTypeFloat("com.atlassian.jira.plugin.system.customfieldtypes:float"), //
		cfTypeTextArea("com.atlassian.jira.plugin.system.customfieldtypes:textarea"), //
		cfTypeCascadingSelect("com.atlassian.jira.plugin.system.customfieldtypes:cascadingselect"), //
		cfTypeDateTime("com.atlassian.jira.plugin.system.customfieldtypes:datetime"), //
		cfTypeProject("com.atlassian.jira.plugin.system.customfieldtypes:project"), //
		cfTypeRadiobuttons("com.atlassian.jira.plugin.system.customfieldtypes:radiobuttons"), //
		cfTypeMultiversion("com.atlassian.jira.plugin.system.customfieldtypes:multiversion"), //
		cfTypeVersion("com.atlassian.jira.plugin.system.customfieldtypes:version"), //
		cfTypeUserpicker("com.atlassian.jira.plugin.system.customfieldtypes:userpicker"), //
		cfTypeUrl("com.atlassian.jira.plugin.system.customfieldtypes:url"), //
		cfTypeMultigrouppicker("com.atlassian.jira.plugin.system.customfieldtypes:multigrouppicker"), //
		cfTypeGrouppicker("com.atlassian.jira.plugin.system.customfieldtypes:grouppicker"), //
		cfTypeReadonlyfield("com.atlassian.jira.plugin.system.customfieldtypes:readonlyfield"), //
		cfTypeLabels("com.atlassian.jira.plugin.system.customfieldtypes:labels"), //
		cfTypeGhSprint("com.pyxis.greenhopper.jira:gh-sprint"), //
		// ~~ Searchers
		cfTypeTextSearcher("com.atlassian.jira.plugin.system.customfieldtypes:textsearcher"), //
		cfTypeDateRange("com.atlassian.jira.plugin.system.customfieldtypes:daterange"), //
		cfTypeMultiSelectSearcher("com.atlassian.jira.plugin.system.customfieldtypes:multiselectsearcher"), //
		// ~~ Service Desk
		cfTypeSdApprovals("com.atlassian.servicedesk.approvals-plugin:sd-approvals"), // Approvals
		cfTypeSdCustomerOrganizations("com.atlassian.servicedesk:sd-customer-organizations"), // Organizations
		cfTypeSdRequestParticipants("com.atlassian.servicedesk:sd-request-participants"), // Request participants
		cfTypeSdSlaField("com.atlassian.servicedesk:sd-sla-field"), //
		cfTypeSdIncidentsLink("com.atlassian.servicedesk.incident-management-plugin:sd-incidents-link"), //
		cfTypeSdRequestFeedback("com.atlassian.servicedesk:sd-request-feedback"), //
		cfTypeSdRequestFeedbackDate("com.atlassian.servicedesk:sd-request-feedback-date"), //
		cfTypeJsdBundledFields("com.intenso.jira.plugins.jsd-extender:jsd-bundled-fields"), //
		cfTypeJqlFunctionsCustomFieldType("com.onresolve.jira.groovy.groovyrunner:jqlFunctionsCustomFieldType"), //
		sdVpOrigin("com.atlassian.servicedesk:vp-origin"), //
		cfTypeIdalkoTableGridCustomFieldKey("tge.cloud:idalko-table-grid-custom-field-key");

		private String enumItem;
		JiraCustomFieldsType(String anEnumItem) {
			this.enumItem = anEnumItem;
		}
		public String getEnumStr() {
			return enumItem;
		}
	}

	// https://support.atlassian.com/jira-cloud-administration/docs/what-are-issue-statuses-priorities-and-resolutions/
	// ~~ What are issue statuses, priorities, and resolutions?

	public static enum JiraIssueStatus {
		// ~~ Workflows can be associated with particular projects and, optionally, specific issue types, by using a workflow scheme.
		// ~~ Jira Issue Statuses
		issueStatusOpen("Open"), // he issue is open and ready for the assignee to start work on it.
		issueStatusInProgress("In Progress"), // This issue is being actively worked on at the moment by the assignee.
		issueStatusDone("Done"), // Work has finished on the issue.
		issueStatusToDo("To Do"), // The issue has been reported and is waiting for the team to action it.
		issueStatusInReview("In Review"), // The assignee has carried out the work needed on the issue, and it needs peer review before being considered done.
		// ... and more
		// ~~ Jira Software statuses ~~
		issueStatusReopened("Reopened"), // This issue was once resolved, but the resolution was deemed incorrect. From here, issues are either marked assigned or resolved.
		issueStatusResolved("Resolved"), // A resolution has been taken, and it is awaiting verification by reporter. From here, issues are either reopened, or are closed.
		issueStatusClosed("Closed"), // The issue is considered finished. The resolution is correct. Issues which are closed can be reopened.
		issueStatusBuilding("Building"), // Source code has been committed, and JIRA is waiting for the code to be built before moving to the next status.
		issueStatusBuildBroken("Build broken"), // The source code committed for this issue has possibly broken the build.
		issueStatusBacklog("Backlog"), // The issue is waiting to be picked up in a future sprint.
		issueStatusSelectedForDevelopment("Selected for Development"), // The issue is verified and has been selected to be worked on in the future.
		// ~~ Jira Service Management statuses ~~
		issueStatusDeclined("Declined"), //
		issueStatusWaitingForSupport("Waiting for support"), //
		issueStatusWaitingForCustomer("Waiting for customer"), //
		issueStatusPending("Pending"), //
		issueStatusCanceled("Canceled"), //
		issueStatusEscalated("Escalated"), //
		issueStatusWaitingForApproval("Waiting for approval"), //
		issueStatusAwaitingCABapproval("Awaiting CAB approval"), //
		issueStatusPlanning("Planning"), //
		issueStatusAwaitingimplementation("Awaiting implementation"), //
		issueStatusImplementing("Implementing"), //
		issueStatusPeerReviewChangeManagerApproval("Peer review / change manager approval"), //
		issueStatusWorkInProgress("Work in progress"), //
		issueStatusCompleted("Completed"), //
		issueStatusUnderInvestigation("Under investigation");

		private String enumItem;
		JiraIssueStatus(String anEnumItem) {
			this.enumItem = anEnumItem;
		}
		public String getEnumStr() {
			return enumItem;
		}
	}

	public static final HashSet<String> fieldNamesToClean = new HashSet<String>() {
		private static final long serialVersionUID = 1L;
		{
			// ~~Table Grid Next Generation, Plugin key: tge.cloud, Developer: iDalko ~~
			//add("DUCKET_NAME"); 
			//add("AUTHENTICATIONREQUIRED");
			//~~ Random fields just to test locally ~~
			add("VALUE");
		}
	};

	private static final HashSet<String> UNUSED_KeyWords = new HashSet<String>() {
		private static final long serialVersionUID = 1L;
		//~~List of the filters to focus on
		{
			add("PKIX");
		}
	};

	// ~~ WORKFLOWS ~~
	// ~~ Jira Software Workflows ~~
	// "issueType": "Task // ~~ Project Management Workflow {Initial status 'TO DO'}
	// "issueType": "Sub-task // ~~ Project Management Workflow {Initial status 'TO DO'}
	// ~~ Jira Service Management Workflows ~~
	// "issueType": "Task // ~~ Jira Service Management default workflow {Initial status 'OPEN'}
	// "issueType": "Sub-task // ~~ Jira Service Management default workflow {Initial status 'OPEN'}
	// "issueType": "Change // ~~ Change Management workflow for Jira Service Management {Initial status 'AWAITING CAB APPROVAL'}
	// "issueType": "Incident // ~~ Incident Management workflow for Jira Service Management {Initial status 'OPEN'}
	// "issueType": "Problem // ~~ Problem Management workflow for Jira Service Management {Initial status 'OPEN'}
	// "issueType": "Service Request // ~~ Service Request Fulfilment workflow for Jira Service Management {Initial status 'WAITING FOR SUPPORT'}
	// "issueType": "Service Request with Approvals // ~~ Service Request Fulfilment with Approvals workflow for Jira Service Management {Initial status 'WAITING FOR SUPPORT'}

	// ~~ Issue priorities ~~
	// "priority": "Low
	// "priority": "Medium
	// "priority": null,
	//
	// "reporter": "user"

	// ~~ Issue resolutions ~~
	// Done ~~ Work has been completed on this issue.
	// Won't do ~~ This issue won't be actioned.
	// Duplicate ~~ The problem is a duplicate of an existing issue.
	// ~~Jira Software resolutions
	// Cannot reproduce ~~ All attempts at reproducing this issue failed, or not enough information was available to reproduce the issue. Reading the code produces no clues as to why this behavior would occur. If more information appears later, please reopen the issue.
	// ~~ Jira Service Management resolutions
	// Known error ~~ The problem has a documented root cause and a work around.
	// Hardware failure
	// Software failure

}
