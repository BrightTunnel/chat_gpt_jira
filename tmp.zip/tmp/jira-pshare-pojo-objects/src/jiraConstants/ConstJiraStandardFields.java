package jiraConstants;

///import java.nio.file.attribute.AclEntryPermission; //-- geo							  
import java.util.HashMap;

public class ConstJiraStandardFields {

	public static HashMap<String, String> missedStandardJiraFields = new HashMap<String, String>();

	// https://www.jirastrategy.com/content/baseline-jira-fields-list
	//	https://innovalog.atlassian.net/wiki/spaces/JMWEC/pages/108200050/Standard+JIRA+fields

	///~~~ HOW TO CALL 
	///	String ss = ConstJiraStandardFields.SJF.fixVersions.toString(); ///~~ Returns: 'fixVersions'  
	///	String ss = ConstJiraStandardFields.SJF.fixVersions.getEnumStr(); ///~~ Returns: 'Fix Version/s' 

	public enum SJF {
		///~~ 'customfield_10500', 'customfield_config', 'comments', 'summary', 'resolution', 'description', etc
		///~~ System Fields from Jira UI: String[] s = {"Summary", "Issue Type", "Priority", "Resolution", "Affects Version/s", "Fix Version/s", "Component/s", "Labels", "Environment", "Linked Issues", "Attachment", "Assignee", "Reporter", "Due Date", "Time Tracking", "Security Level"};	

		///~~ Verified Jira System Field IDs mapping to the Label. Comments in the section below is THE copy from the Jira Export file
		description("Description"), // "description": "Description",
		duedate("Due Date"), // "duedate": "Due Date",
		environment("Environment"), //"environment": "Environment",
		fixVersions("Fix Version/s"), // "fixVersions": "Fix Version/s" ATTN: or may be [FixVersion/s]?
		issuelinks("Linked Issues"), // "issuelinks": "Linked Issues"
		issuetype("Issue Type"), // "issuetype": "Issue Type"
		labels("Labels"), // "labels": "Labels"
		lastViewed("Last Viewed"), // "lastViewed": "Last Viewed"
		Priority("Priority"), // "priority": "Priority"
		progress("Progress"), // "progress": "Progress"  ~~On the “Create” screen
		project("Project"), // "project": "Project"
		reporter("Reporter"), // "reporter": "Reporter"
		resolution("Resolution"), // "resolution": "Resolution"
		resolutiondate("Resolved"), // "resolutiondate": "Resolved" ~~ Resolution Date
		status("Status"), //  "status": "Status" ~~A workflow step
		subtasks("Subtasks"), // "subtasks": "Sub-Tasks"
		summary("Summary"), // "summary": "Summary"
		timeestimate("Remaining Estimate"), // "timeestimate": "Remaining Estimate"
		timeoriginalestimate("Original Estimate"), // "timeoriginalestimate": "Original Estimate"
		timespent("Time Spent"), // "timespent": "Time Spent" ~~Or 'Time spent'?
		timetracking("Time Tracking"), // "timetracking": "Time Tracking" ~~Includes Original Estimate and Remaining Estimate fields ~~Or 'Time tracking'?
		updated("Updated"), // "updated": "Updated"
		versions("Affects Version/s"), //		// "versions": "Affects Version/s"
		votes("Votes"), // "votes": "Votes"
		watches("Watchers"), // "watches": "Watchers"
		worklog("Work log"), // "worklog": "Log Work"
		workratio("Work Ratio"), //"workratio": "Work Ratio"

		/// ~~ Not verified yet --Standard Jira System Fields, Default Fields & Functions ~~
		assignee("Assignee"), //
		attachment("Attachment"), //
		attachments("Attachments"), //
		comments("Comments"), //
		components("Component/s"), //
		created("Created"), //
		creator("Creator"), //
		epiclink("Epic Link"), //(For issues related to Epics)
		epicname("Epic Name"), // (For Epics)
		issuelink1("Issue links"), //~~Note: issuelink is used in verified pair "issuelinks": "Linked Issues"
		key("Key"), //
		logwork("Log Work"), //
		parent("Parent"), //
		securitylevel("Security level"), // ~~System
		sprint("Sprint"), //
		storypoints("Story Points"), //
		SumOriginalEstimate("∑ Original Estimate"), // 
		SumProgress("∑  Progress"), // 
		SumRemainingEstimate("∑ Remaining Estimate"), // 
		SumTimeSpent("∑ Time Spent"), //

		// ~~ From Jira Service Desk 3.12.2. The following fields are added when you create a support-type project and use the “Create sample data” option ~~
		approvals("Approvals"), // (Locked)
		approvers("Approvers"), //
		cab("CAB"), // (Description:  Change Advisory Board members)
		changecompletiondate("Change completion date"), //
		changemanagers("Change managers"), //
		changereason("Change reason"), //
		ChangeRisk("Change risk"), // that and all below were not verified and stays do far in camel notation 
		ChangeStartDate("Change start date"), //
		ChangeType("Change type"), //
		CustomerRequestType("Customer Request Type"), // (Locked)
		Flagged("Flagged"), //
		Impact("Impact"), //
		InvestigationReason("Investigation reason"), //
		OperationalCategorization("Operational categorization"), //
		Organizations("Organizations"), // (Locked)
		ParentLink("Parent Link"), //
		PendingReason("Pending reason"), //
		ProductCategorization("Product categorization"), //
		RequestParticipants("Request participants"), // (Locked)
		RootCause("Root cause"), //
		Satisfaction("Satisfaction"), // (Locked)
		Team("Team"), // (Locked)
		TimeToSpproveNormalChange("Time to approve normal change"), // (Locked)
		TimeToCloseAfterResolution("Time to close after resolution"), // (Locked)
		TimeToFirstResponse("Time to first response"), // (Locked)
		TimeToResolution("Time to resolution"), // (Locked)
		SatisfactionDate("Satisfaction date"), // (Locked)
		Urgency("Urgency"), //
		Workaround("Workaround"),
		// ~~ Unknown
		AAASectionHeader("AAA Section Header"), //
		Source("Source"), //
		IssueFunction("issueFunction"), //
		LinkedMajorIncidents("Linked major incidents"), //

		// ~~ Also (Not Standard Jira Field, and user-defined/invented script variable names) ~~
		Init("init"), // For Jira7 and Jira8. E.g.(Jira7): <init id="__init__" validator-script="import com.atlassian.jira.component.ComponentAccessor&#10;...
		InitUU("__init__"), // 
		Customfield_config("customfield_config"); // Just variable name. e.g.: def customfield_config = customfield.getRelevantConfig(getIssueContext()); 

		private String enumItem;
		SJF(String anEnumItem) {
			this.enumItem = anEnumItem;
		}
		public String getEnumStr() {
			return enumItem;
		}
	}

	public static boolean isItStandardSystemJiraField(String aString) {
		if (aString != null && aString.trim().length() > 0) {
			for (SJF xmlAttributeName : SJF.values()) {
				if (xmlAttributeName.toString().compareTo(aString) == 0 // 'fixVersions'
						|| xmlAttributeName.getEnumStr().compareTo(aString) == 0) { // 'Fix Version/s'
					return true;
				}
			}
			if (!aString.startsWith("customfield_") && !missedStandardJiraFields.containsKey(aString)) {
				missedStandardJiraFields.put(aString, aString);
			}
		}
		return false;
	}

}
