package jiraConstants;

public class ConstIniKeys {

	public enum IniKeys {
		project, //
		targetProjectKey, //
		projectName, //
		projectExternalName, //
		projectDescription, //
		projectType, // ~~ 'software' or 'service_desk'
		issueFirstID, // #~~ issueFirstID = 0 ~~ means Jira will create all issues with the Key next after last available
		// ~~ Issues ~~
		issue, // 
		// ~~ Issue types ~~
		Initiative, // 
		Epic, //
		Story, //
		Task, //
		SubTask, //
		Bug, //
		Incident, //
		// ~~ Issue dates ~~
		created, //
		updated, //
		duedate, //
		begin, //
		end, //
		// ~~
		customFieldTypeTextfield, //
		customFieldTypeSelect, //
		customFieldTypeDatepicker, //

		comments, //
		addOriginalKeyToComment, //
		originalKeyDescriptor,

		// ~~ ImportLostIssuesRecovery ~~
		ImportLostIssuesRecovery, //
		xmlfiletoread, //
		jsonfiletobuild; //
	}

}
