package jiraConstants;

public class ConstXmlElementsExportedJiraIssues {

	public static enum XmlExportElemt {
		///~~ xml elements from the exported Jira issues ~~  
		assignee("assignee"), //
		attachments("attachments"), //
		author("author"), //
		channel("channel"), //
		comment("comment"), //
		comments("comments"), //
		created("created"), //
		customfield("customfield"), //
		customfieldname("customfieldname"), //
		customfields("customfields"), //
		customfieldvalue("customfieldvalue"), //
		customfieldvalues("customfieldvalues"), //
		description("description"), //
		due("due"), //
		environment("environment"), //
		item("item"), //
		key("key"), //
		labels("labels"), //
		link("link"), //
		priority("priority"), //
		project("project"), //
		reporter("reporter"), //
		resolution("resolution"), //
		status("status"), //
		statusCategory("statusCategory"), //
		subtasks("subtasks"), //
		summary("summary"), //
		title("title"), //
		type("type"), //
		updated("updated"), //
		votes("votes"), //
		watches("watches");
		private String enumItem;
		XmlExportElemt(String anEnumItem) {
			this.enumItem = anEnumItem;
		}
		public String getEnumStr() {
			return enumItem;
		}
	}
}
