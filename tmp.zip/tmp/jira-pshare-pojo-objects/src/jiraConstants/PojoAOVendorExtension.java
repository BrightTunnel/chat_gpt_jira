package jiraConstants;

import utilsGlobal.SysUtils;

public class PojoAOVendorExtension {

	private String extensionName; // Adaptavist ScriptRunner for Jira
	private String extensionPluginKey; // com.onresolve.jira.groovy.groovyrunner
	private String extensionVendorDeveloper; // Adaptavist.com Ltd
	private String extensionVersion; // 5.5.7.1-jira8
	private String extensionAoMD5Offered; // AO_4B00E6
	private String extensionAoMD5Calculated; // AO_4B00E6
	//~~ Extra ~~
	private String notesExtension;

	public PojoAOVendorExtension(String anExtensionName, String anExtensionPluginKey, String anExtensionAoMD5Offered) {
		this.extensionName = anExtensionName;
		this.extensionPluginKey = anExtensionPluginKey;
		this.notesExtension = "";
		this.extensionAoMD5Offered = null;
		this.extensionAoMD5Calculated = null;
		SysUtils sysUtils = new SysUtils();
		if (this.extensionPluginKey != null && this.extensionPluginKey.length() > 0) {
			this.extensionAoMD5Offered = sysUtils.calculateMD5HashKey(this.extensionPluginKey);
			if (this.extensionAoMD5Offered != null && this.extensionAoMD5Offered.length() > 6) {
				this.extensionAoMD5Offered = this.extensionAoMD5Offered.substring(this.extensionAoMD5Offered.length() - 6);
				this.extensionAoMD5Offered = "AO_" + this.extensionAoMD5Offered.toUpperCase();
				this.extensionAoMD5Calculated = this.extensionAoMD5Offered;
				if (anExtensionAoMD5Offered != null && anExtensionAoMD5Offered.length() > 0) {
					if (anExtensionAoMD5Offered.compareTo(this.extensionAoMD5Offered) != 0) {
						this.notesExtension = "~~ Offered: " + anExtensionAoMD5Offered + ", Calculated: " + this.extensionAoMD5Offered;
						this.extensionAoMD5Offered = anExtensionAoMD5Offered; // ~~ Use offered, desregard calculated 
					} else {
						//this.notesExtension = "==";
						this.extensionAoMD5Calculated = null; //~~ Also marks that (extensionAoMD5Offered == extensionAoMD5Calculated)
					}
				}
			}
		}
		// this.notesExtension = "~~can't calcualte AO_FFFFFF - empty extensionPluginKey.";
		if (anExtensionAoMD5Offered != null && anExtensionAoMD5Offered.length() > 0) {
			this.extensionAoMD5Offered = anExtensionAoMD5Offered;
		}
	}

	//~~~ Getters / Setters ~~~ 
	public String getExtensionName() {
		return extensionName;
	}

	public String getExtensionVendorDeveloper() {
		return extensionVendorDeveloper;
	}

	public String getExtensionPluginKey() {
		return extensionPluginKey;
	}

	public String getExtensionVersion() {
		return extensionVersion;
	}

	public String getExtensionAoMD5Offered() {
		return extensionAoMD5Offered;
	}

	public String getNotesExtension() {
		return notesExtension;
	}

	public String getExtensionAoMD5Calculated() {
		return extensionAoMD5Calculated;
	}

	public void setExtensionName(String extensionName) {
		this.extensionName = extensionName;
	}

}
