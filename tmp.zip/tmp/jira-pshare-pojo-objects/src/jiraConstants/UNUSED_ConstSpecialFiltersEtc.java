package jiraConstants;

public class UNUSED_ConstSpecialFiltersEtc {

	public static enum UNUSED_JiraWfAndrian {
		software("ANDRIAN"), //
		service_desk("THIS");

		private String enumItem;

		UNUSED_JiraWfAndrian(String anEnumItem) {
			this.enumItem = anEnumItem;
		}

		public String getEnumStr() {
			return enumItem;
		}
	}

}
