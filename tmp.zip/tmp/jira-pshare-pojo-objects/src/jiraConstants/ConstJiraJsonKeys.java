package jiraConstants;

public class ConstJiraJsonKeys {

	public static enum JsonRoot {
		users("users"), //
		links("links"), //
		projects("projects");
		private String enumItem;
		JsonRoot(String anEnumItem) {
			this.enumItem = anEnumItem;
		}
		public String getEnumStr() {
			return enumItem;
		}
	}

	public static enum JsonUsers {
		name("name"), //
		fullname("fullname"), //
		email("email"), //
		groups("groups"), // ["admin", "testers"] 
		active("active");
		private String enumItem;
		JsonUsers(String anEnumItem) {
			this.enumItem = anEnumItem;
		}
		public String getEnumStr() {
			return enumItem;
		}
	}

	public static enum JsonLinks {
		name("name"), //
		sourceId("sourceId"), //
		destinationId("destinationId");
		private String enumItem;
		JsonLinks(String anEnumItem) {
			this.enumItem = anEnumItem;
		}
		public String getEnumStr() {
			return enumItem;
		}
	}

	public static enum JsonComponent {
		name("name"), //
		lead("lead"), //
		description("description");
		private String enumItem;
		JsonComponent(String anEnumItem) {
			this.enumItem = anEnumItem;
		}
		public String getEnumStr() {
			return enumItem;
		}
	}

	public static enum JsonProject {
		key("key"), // SSD
		type("type"), // ~~ Project Type, ProjectType 'software' or 'service_desk'
		name("name"), // ~~ Security Service Desk
		description("description"), //
		externalName("externalName"), // ~~ Security Service Desk
		lead("lead"), //
		assigneeType("assigneeType"), // '3'
		assignee("assignee"), //
		versions("versions"), //
		components("components"), //					  
		issues("issues"); //
		private String enumItem;
		JsonProject(String anEnumItem) {
			this.enumItem = anEnumItem;
		}
		public String getEnumStr() {
			return enumItem;
		}
	}

	public static enum JsonIssue {
		id("id"),
		// pkey("pkey"),
		// issuenum("issuenum"),
		// project("project"),
		reporter("reporter"), //
		assignee("assignee"), //
		creator("creator"), // ~~ Error: {Unrecognized field "author"}
		issueType("issueType"), // ~~ Bug
		summary("summary"), //
		description("description"), //
		environment("environment"), //
		priority("priority"), //
		resolution("resolution"), // ~~ Resolved
		issuestatus("status"), // ~~ 'issuestatus' [Closed,...]
		created("created"), // ~~ "2012-08-31T17:59:02.161+0100",
		updated("updated"), // ~~  "P-1D",
		duedate("duedate"), // Specific for JSON
		resolutiondate("resolutiondate"), //
		votes("votes"), //
		watches("watches"), //
		//timeoriginalestimate("timeoriginalestimate"),
		//timeestimate("timeestimate"),
		//timespent("timespent"),
		workflow_id("workflow_id"), //
		//security("security"),
		//fixfor("fixfor"),
		component("component"), // ~~ ["Component", "AnotherComponent"],
		archived("archived"), //
		archivedby("archivedby"), //
		archiveddate("archiveddate"), //
		attachments("attachments"), //

		///~~~ Not in the db table 'JiraIssue' but may be a part of the XML Jira Issue Element ~~~
		key("key"), //
		// link("link"), //
		labels("labels"), //  [ "impossible", "to", "test"]
		resolved("resolved"), // ~~ Can't modify, set when issue resolved
		fixVersion("fixVersion"), // Specific for JSON
		customFieldValues("customFieldValues"), // ~~ [{}]
		comments("comments"), // ~~ []
		// comment("comment"); //
		externalId("externalId"), //
		affectedVersions("affectedVersions"), // ~~  [ "1.0" ],
		fixedVersions("fixedVersions"), // ~~ [ "1.0", "2.0" ],
		history("history"); //
		//		channel("channel"), //
		//		customfieldname("customfieldname"), //
		//		customfield("customfield"), //
		//		customfields("customfields"), //
		//		customfieldvalue("customfieldvalue"), //
		//		item("item"), //
		//		statusCategory("statusCategory"), //
		//		subtasks("subtasks"), //
		//		title("title"), //

		private String enumItem;
		JsonIssue(String anEnumItem) {
			this.enumItem = anEnumItem;
		}
		public String getEnumStr() {
			return enumItem;
		}
	}

	public static enum JsonCF {
		fieldName("fieldName"), // ~~ "Story Points",
		fieldType("fieldType"), // ~~ "com.atlassian.jira.plugin.system.customfieldtypes:float",
		searcherType("searcherType"), //
		value("value"); // ~~ "15"
		private String enumItem;
		JsonCF(String anEnumItem) {
			this.enumItem = anEnumItem;
		}
		public String getEnumStr() {
			return enumItem;
		}
	}

	public static enum JsonComment {
		body("body"), //
		author("author"), // ~~
		created("created");
		private String enumItem;
		JsonComment(String anEnumItem) {
			this.enumItem = anEnumItem;
		}
		public String getEnumStr() {
			return enumItem;
		}
	}

	public static enum JsonAttachments {
		name("name"), // ~~ "battarang.jpg",
		attacher("attacher"), // ~~ "bob@example.com", 
		uri("uri"), // ~~ "http://optimus-prime/~batman/images/battarang.jpg",
		description("description"), // ~~ "This is optimus prime"
		created("created"); // ~~ "2012-08-31T17:59:02.161+0100",
		private String enumItem;
		JsonAttachments(String anEnumItem) {
			this.enumItem = anEnumItem;
		}
		public String getEnumStr() {
			return enumItem;
		}
	}

	public static enum JsonHistory {
		author("author"), // ~~ 
		created("created"), // ~~ "2012-08-31T17:59:02.161+0100",
		items("items"); // ~~ [
		//        {
		//            "fieldType" : "jira",
		//            "field" : "status",
		//            "from" : "1",
		//            "fromString" : "Open",
		//            "to" : "5",
		//            "toString" : "Resolved"
		//        }]
		private String enumItem;
		JsonHistory(String anEnumItem) {
			this.enumItem = anEnumItem;
		}
		public String getEnumStr() {
			return enumItem;
		}
	}

}
