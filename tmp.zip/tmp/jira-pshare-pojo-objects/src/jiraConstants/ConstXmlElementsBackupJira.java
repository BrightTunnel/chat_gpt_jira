package jiraConstants;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map.Entry;
import java.util.TreeMap;

import jiraPojoXml.PojoXmlAttribute;
import jiraPojoXml.PojoXmlElement;

public class ConstXmlElementsBackupJira {

	// [CDATA[~~]] -- Base64 Coded 
	// <Action id="10100" issue="10400" author="JIRAUSER10000" type="comment" created="2021-10-09 22:56:37.987" updateauthor="JIRAUSER10000" updated="2021-10-09 22:57:05.196"><body><![CDATA[Napa
	// valley Ave l4h 1y7]]></body></Action>
	// <ChangeItem id="10601" group="10601" fieldtype="jira" field="description" oldstring="l4h 1y7" newstring="111 Napa Valley Ave l4h 1y7"/>
	// <ChangeItem id="10601" group="10601" fieldtype="jira" field="description" oldstring="l4h 1y7" newstring="111 Napa Valley Ave l4h 1y7"/>
	// <ChangeItem id="10603" group="10603" fieldtype="custom" field="tvnDevinitiBundledField" oldvalue="" oldstring="subfield02: ms6, subfield01: s6" newvalue="" newstring="subfield02: ms6,
	// subfield01: L4H 1Y7"/>
	// <CustomFieldValue id="11000" issue="10400" customfield="10500" updated="1633834711008"
	// textvalue="{&quot;configurationId&quot;:1,&quot;baseGroupId&quot;:{&quot;fields&quot;:[{&quot;id&quot;:&quot;ec1d3433-342e-4008-bf94-d6dd800ba67f&quot;,&quot;originId&quot;:&quot;ec1d3433-342e-4008-bf94-d6dd800ba67f&quot;,&quot;value&quot;:&quot;L4H
	// 1Y7&quot;},{&quot;id&quot;:&quot;bd8a1bb7-648e-42fb-8b32-88e564f3ac74&quot;,&quot;originId&quot;:&quot;bd8a1bb7-648e-42fb-8b32-88e564f3ac74&quot;,&quot;value&quot;:&quot;ms6&quot;}],&quot;order&quot;:0}}"/>
	// <Issue id="10400" key="PR-54" number="54" project="10000" reporter="JIRAUSER10000" assignee="JIRAUSER10000" creator="JIRAUSER10000" type="10005" summary="s6" description="111 Napa Valley
	// Ave l4h 1y7" priority="3" status="1" created="2021-09-28 08:11:50.019" updated="2021-10-09 22:58:31.06" votes="0" watches="1" workflowId="10400" archived="N"/>

	/// ~~ entities.xml ~~

	public final static HashMap<String, PojoXmlAttribute> listOfUniqueKnownHardcodedAttributesAndChildren = new HashMap<String, PojoXmlAttribute>(); // ~~ Attributes ~~

	public enum XmlAtrb {
		///~~ Jira Backup Xml Attributes ~~
		assignee("assignee"), //
		author("author"), //
		body("body"), //
		colorName("colorName"), //
		comment("comment"), //
		config("config"), //
		created("created"), //
		customfieldsearcherkey("customfieldsearcherkey"), //
		customfieldtypekey("customfieldtypekey"), //
		datakey("data-key"), //
		dataremainingtime("data-remaining-time"), //
		description("description"), //
		disabled("disabled"), //
		duedate("duedate"), //
		environment("environment"), //
		guideWorkflow("guideWorkflow"), //
		hidden("hidden"), //
		iconUrl("iconUrl"), //
		id("id"), //
		issueType("issueType"), //
		issuesWithValue("issuesWithValue"), //
		key("key"), //
		name("name"), //
		newstring("newstring"), //
		oldstring("oldstring"), //
		parameters("parameters"), //
		priority("priority"), //
		readonly("readonly"), //
		reporter("reporter"), //
		request("request"), //
		required("required"), //
		resolved("resolved"), //
		script("script"), //
		scriptPath("scriptPath"), //
		status("status"), //
		summary("summary"), //
		textvalue("textvalue"), //
		updated("updated"), //
		username("username"), //
		usevalidatorplugin("use-validator-plugin"), //
		validator("validator"), //
		validatorScript("validator-script"); //
		private String enumItem;
		XmlAtrb(String anEnumItem) {
			this.enumItem = anEnumItem;
		}
		public String getEnumStr() {
			return enumItem;
		}
	}

	public static enum XmlElemt {
		///~~~ Jira Backup Xml Elements ~~~
		///~~~Jira 7 vs Jira 8  Xml Elements ~~~
		init("init"), // 	Jira8 Behaviour's <init validator="server">																																											<validator-script><script>// System.out.println("~~~Initialiser");...
		field("field"), //	Jira8 Behaviour's <field id="customfield_10500" readonly="false" hidden="false" required="false" name="CarMakers" validator="server">	<validator-script><script>// System.out.println("~~~CarMakers customfield_10500");...
		//						Jira7 Behaviour's <field id="customfield_10500" readonly="null" hidden="null" required="null" validator="server" validator-class="" validator-script="// System.out.println("~");...
		//						Jira7 Behaviour's <init id="__init__" validator-script="import com.atlassian.jira.security.JiraAuthenticationContext&#10;...
		///~~~Regular Xml Elements ~~~
		Action("Action"), //
		Application("Application"), //
		ApplicationUser("ApplicationUser"), //
		AuditChangedValue("AuditChangedValue"), //
		AuditItem("AuditItem"), //
		AuditLog("AuditLog"), //
		Avatar("Avatar"), //
		ChangeGroup("ChangeGroup"), //
		ChangeItem("ChangeItem"), //
		ClusteredJob("ClusteredJob"), //
		ClusteredNode("ClusteredNode"), //
		ColumnLayout("ColumnLayout"), //
		ColumnLayoutItem("ColumnLayoutItem"), //
		CommentVersion("CommentVersion"), //
		Component("Component"), //
		ConfigurationContext("ConfigurationContext"), //
		CustomField("CustomField"), //
		CustomFieldOption("CustomFieldOption"), //
		CustomFieldValue("CustomFieldValue"), //
		Directory("Directory"), //
		DirectoryAttribute("DirectoryAttribute"), //
		DirectoryOperation("DirectoryOperation"), //
		DraftWorkflow("DraftWorkflow"), //
		DraftWorkflowScheme("DraftWorkflowScheme"), //
		DraftWorkflowSchemeEntity("DraftWorkflowSchemeEntity"), //
		EntityProperty("EntityProperty"), //
		EventType("EventType"), //
		FavouriteAssociations("FavouriteAssociations"), //
		Feature("Feature"), //
		FieldConfigScheme("FieldConfigScheme"), //
		FieldConfigSchemeIssueType("FieldConfigSchemeIssueType"), //
		FieldConfiguration("FieldConfiguration"), //
		FieldLayout("FieldLayout"), //
		FieldLayoutItem("FieldLayoutItem"), //
		FieldLayoutScheme("FieldLayoutScheme"), //
		FieldLayoutSchemeEntity("FieldLayoutSchemeEntity"), //
		FieldScreen("FieldScreen"), //
		FieldScreenLayoutItem("FieldScreenLayoutItem"), //
		FieldScreenScheme("FieldScreenScheme"), //
		FieldScreenSchemeItem("FieldScreenSchemeItem"), //
		FieldScreenTab("FieldScreenTab"), //
		FileAttachment("FileAttachment"), //
		GadgetUserPreference("GadgetUserPreference"), //
		GenericConfiguration("GenericConfiguration"), //
		GlobalPermissionEntry("GlobalPermissionEntry"), //
		Group("Group"), //
		Issue("Issue"), //
		IssueLink("IssueLink"), //
		IssueLinkType("IssueLinkType"), //
		IssueSecurityScheme("IssueSecurityScheme"), //
		IssueType("IssueType"), //
		IssueTypeScreenScheme("IssueTypeScreenScheme"), //
		IssueTypeScreenSchemeEntity("IssueTypeScreenSchemeEntity"), //
		IssueVersion("IssueVersion"), //
		JQRTZLocks("JQRTZLocks"), //
		Label("Label"), //
		LicenseRoleDefault("LicenseRoleDefault"), //
		LicenseRoleGroup("LicenseRoleGroup"), //
		ListenerConfig("ListenerConfig"), //
		MailServer("MailServer"), //
		ManagedConfigurationItem("ManagedConfigurationItem"), //
		Membership("Membership"), //
		MovedIssueKey("MovedIssueKey"), //
		NodeAssociation("NodeAssociation"), //
		Notification("Notification"), //
		NotificationInstance("NotificationInstance"), //
		NotificationScheme("NotificationScheme"), //
		OAuthConsumer("OAuthConsumer"), //
		OSCurrentStep("OSCurrentStep"), //
		OSCurrentStepPrev("OSCurrentStepPrev"), //
		OSHistoryStep("OSHistoryStep"), //
		OSHistoryStepPrev("OSHistoryStepPrev"), //
		OSPropertyDate("OSPropertyDate"), //
		OSPropertyEntry("OSPropertyEntry"), //
		OSPropertyNumber("OSPropertyNumber"), //
		OSPropertyString("OSPropertyString"), //
		OSPropertyText("OSPropertyText"), //
		OSWorkflowEntry("OSWorkflowEntry"), //
		OptionConfiguration("OptionConfiguration"), //
		PermissionScheme("PermissionScheme"), //
		PluginState("PluginState"), //
		PluginVersion("PluginVersion"), //
		PortalPage("PortalPage"), //
		PortletConfiguration("PortletConfiguration"), //
		Priority("Priority"), //
		ProductLicense("ProductLicense"), //
		Project("Project"), //
		ProjectKey("ProjectKey"), //
		ProjectRole("ProjectRole"), //
		ProjectRoleActor("ProjectRoleActor"), //
		ReindexComponent("ReindexComponent"), //
		ReindexRequest("ReindexRequest"), //
		RememberMeToken("RememberMeToken"), //
		Resolution("Resolution"), //
		RunDetails("RunDetails"), //
		SchemeIssueSecurities("SchemeIssueSecurities"), //
		SchemeIssueSecurityLevels("SchemeIssueSecurityLevels"), //
		SchemePermissions("SchemePermissions"), //
		SearchRequest("SearchRequest"), //
		SequenceValueItem("SequenceValueItem"), //
		ServiceConfig("ServiceConfig"), //
		SharePermissions("SharePermissions"), //
		Status("Status"), //
		TempAttachmentsMonitor("TempAttachmentsMonitor"), //
		UpgradeHistory("UpgradeHistory"), //
		UpgradeTaskHistory("UpgradeTaskHistory"), //
		UpgradeTaskHistoryAuditLog("UpgradeTaskHistoryAuditLog"), //
		UpgradeVersionHistory("UpgradeVersionHistory"), //
		User("User"), //
		UserAssociation("UserAssociation"), //
		UserAttribute("UserAttribute"), //
		UserHistoryItem("UserHistoryItem"), //
		Version("Version"), //
		Workflow("Workflow"), //
		WorkflowScheme("WorkflowScheme"), //
		WorkflowSchemeEntity("WorkflowSchemeEntity"), //
		Worklog("Worklog"), //
		WorklogVersion("WorklogVersion");
		private String enumItem;
		XmlElemt(String anEnumItem) {
			this.enumItem = anEnumItem;
		}
		public String getEnumStr() {
			return enumItem;
		}
	}

	public final static HashSet<String> ListOfAoTablesSubjectToClean = new HashSet<String>() {
		///~~ Hardcoded List of Jira DBase AO_ Tables to be cleaned ~~
		// private final long serialVersionUID = 1L;
		{
			///~~ Table Grid Next Generation, Plugin key: tge.cloud, Developer: iDalko, Version: 1.3.0-jira8 ~~
			///~~ Table Grid Next Generation, Plugin key: tge.cloud, Developer: iDalko
			///~~-TD Cleaner
			add("AO_E115BF_CHANGE_DETAILS"); // [300,190] -- Subject to clean
			//add("AO_E115BF_DUCKET_CHANGE"); // [300,190] -- MetaData - holds tables headers, column names
			//add("AO_E115BF_DATA_SOURCE_CONFIG"); //  [2]
			//add("AO_E115BF_DRIVING_TABLE_ENTITY"); // [0]
			//add("AO_E115BF_DRIVING_TABLE_INFO"); // [0]
			//add("AO_E115BF_DUCKET_CONFIG"); // [6]
			//add("AO_E115BF_DUCKET_FIELD_INFO"); // [6]
			//add("AO_E115BF_USER_ONBOARD"); // [0]
			//add("AO_E115BF_VIEW_FIELD_INFO"); // [0]
			//add("AO_FFFFFF_TEST"); //~~ Random table just to test locally ~~
		}
	};

	public static enum ElemKind { // ~~ Binary map ~~ ElemKind
		///~~ Jira Backup Xml Entities ~~
		// ~~ null, set to -1 (include all types)
		Exclude(0), // ~~ 0 - Do not include 
		WithInlineCode(1), // ~~ 1 - May contain Script 
		WithPii(2), // ~~ 2 - May contain Personal pii data 
		// ~~ 3 - May contain both - Script and Personal data
		IssueParts(4), // ~~
		ScreenLayout(5); // ~~
		private int enumItem;
		ElemKind(int anEnumItem) {
			this.enumItem = anEnumItem;
		}
		public int getEnumInt() {
			return enumItem;
		}
	}

	///~~~ Methods ~~~ 

	public final static TreeMap<String, PojoXmlElement> populateHardcodedListOfElements(HashMap<Long, String> aCollectNumbers) {
		///~~ Jira Backup Xml Entities ~~
		TreeMap<String, PojoXmlElement> listOfUniqueKnownHardcodedElements = new TreeMap<String, PojoXmlElement>();
		EnumSet.allOf(XmlElemt.class).forEach(xmlAttributeName -> {
			if (isAttributeNameAllowed(xmlAttributeName.enumItem, aCollectNumbers)) {
				PojoXmlElement _at = new PojoXmlElement();
				int elementKind = 0;
				switch (xmlAttributeName) {
					case Issue :
						elementKind = ElemKind.IssueParts.getEnumInt() + ElemKind.WithPii.getEnumInt();
						break;
					case CustomField :
						elementKind = ElemKind.IssueParts.getEnumInt() + ElemKind.WithInlineCode.getEnumInt();
						break;
					case CustomFieldValue :
						elementKind = ElemKind.IssueParts.getEnumInt() + ElemKind.WithPii.getEnumInt();
						break;
					case CustomFieldOption :
						elementKind = ElemKind.IssueParts.getEnumInt();
						break;
					case IssueLink :
						elementKind = ElemKind.IssueParts.getEnumInt();
						break;
					case IssueLinkType :
						elementKind = ElemKind.IssueParts.getEnumInt();
						break;
					case IssueSecurityScheme :
						elementKind = ElemKind.IssueParts.getEnumInt();
						break;
					case IssueType :
						elementKind = ElemKind.IssueParts.getEnumInt();
						break;
					case IssueTypeScreenScheme :
						elementKind = ElemKind.IssueParts.getEnumInt();
						break;
					case IssueTypeScreenSchemeEntity :
						elementKind = ElemKind.IssueParts.getEnumInt();
						break;
					case IssueVersion :
						elementKind = ElemKind.IssueParts.getEnumInt();
						break;
					case Workflow :
						elementKind = ElemKind.WithInlineCode.getEnumInt();
						break;
					case SearchRequest :
						elementKind = ElemKind.WithInlineCode.getEnumInt();
						break;

					case FieldScreen :
						elementKind = ElemKind.ScreenLayout.getEnumInt();
						break;
					case FieldScreenTab :
						elementKind = ElemKind.ScreenLayout.getEnumInt();
						break;
					case FieldScreenLayoutItem :
						elementKind = ElemKind.ScreenLayout.getEnumInt();
						break;

					case OSPropertyText :
						elementKind = ElemKind.WithInlineCode.getEnumInt();
						break;
					case OSPropertyString :
						elementKind = ElemKind.WithInlineCode.getEnumInt();
						break;
					case Action :
						elementKind = ElemKind.WithPii.getEnumInt();
						break;
					case ChangeItem :
						elementKind = ElemKind.WithPii.getEnumInt();
						break;
				}
				// ~~ Add to the Dictionary all known Xml Entities:
				_at.setElementKind(elementKind);
				_at.setXmlElementName(xmlAttributeName.getEnumStr());
				listOfUniqueKnownHardcodedElements.put(xmlAttributeName.getEnumStr(), _at);
			}
		});
		return listOfUniqueKnownHardcodedElements;
	}

	public final static void populateHardcodedListOfAttributesAndChildren() {
		EnumSet.allOf(XmlAtrb.class).forEach(xmlAttributeName -> {
			PojoXmlAttribute _at = new PojoXmlAttribute();
			_at.setAttributeName(xmlAttributeName.getEnumStr());
			// _at.setAttributeValue(xmlAttributeName.getEnumStr());
			listOfUniqueKnownHardcodedAttributesAndChildren.put(xmlAttributeName.getEnumStr(), _at);
			// EntryPoint.DictXmlElements.put(xmlAttributeName.getEnumStr(), _at);
			// EntryPoint.DictXmlAttributesAndChildren.put(xmlAttributeName.getEnumStr(), _at);
			// System.out.println(xmlAttributeName.getEnumStr());
		});
	}

	private final static boolean isAttributeNameAllowed(String aParameter, HashMap<Long, String> aCollectNumbers) {
		if (aCollectNumbers != null) {
			for (Entry<Long, String> ff : aCollectNumbers.entrySet()) {
				if (aParameter.compareTo(ff.getValue()) == 0) {
					return true;
				}
			}
		}
		return false;
	}

}
