package jiraPojoTgNgAccounting;

import java.util.Date;

public class PojoTgngTransactionHistoryTable {

	Date transaction_Date;
	String transaction_Type;
	Long transaction_Check_No;
	Double amount;
	String transaction_Status;
	String transaction_Paid_Acct;

	public Date getTransaction_Date() {
		return transaction_Date;
	}

	public void setTransaction_Date(Date transaction_Date) {
		this.transaction_Date = transaction_Date;
	}

	public String getTransaction_Type() {
		return transaction_Type;
	}

	public void setTransaction_Type(String transaction_Type) {
		this.transaction_Type = transaction_Type;
	}

	public Long getTransaction_Check_No() {
		return transaction_Check_No;
	}

	public void setTransaction_Check_No(Long transaction_Check_No) {
		this.transaction_Check_No = transaction_Check_No;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getTransaction_Status() {
		return transaction_Status;
	}

	public void setTransaction_Status(String transaction_Status) {
		this.transaction_Status = transaction_Status;
	}

	public String getTransaction_Paid_Acct() {
		return transaction_Paid_Acct;
	}

	public void setTransaction_Paid_Acct(String transaction_Paid_Acct) {
		this.transaction_Paid_Acct = transaction_Paid_Acct;
	}

}
