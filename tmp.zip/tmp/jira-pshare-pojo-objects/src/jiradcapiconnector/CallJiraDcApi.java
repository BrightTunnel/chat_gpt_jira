package jiradcapiconnector;
///package aiMidware;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Date;
import java.util.TreeMap;

import org.json.simple.JSONObject;

import aiUtils.PojoPrefs;
import aiUtils.ReadPrefs;
import jiraPojoObjects.PojoComment;
import utilsJsonJiraDc.ParseJiraDcJsonComments;

public class CallJiraDcApi {

	final TreeMap<Date, PojoComment> callJiraDcApi(String aProfile, String anIssueKey, int aJiraInstance) {
		TreeMap<Date, PojoComment> parsedComments = null;
		PojoPrefs pojoPrefs = new ReadPrefs().parceJsonStringPrefs(aProfile);
		String urlString = pojoPrefs.getEndpoint() + pojoPrefs.getApiVersion() + pojoPrefs.getApiPath();
		if (anIssueKey != null) {
			urlString += "/" + anIssueKey;
		}
		URL url = null;
		try {
			url = new URL(urlString);
		} catch (MalformedURLException e1) {
		}
		///--Jira Credentials (Basic (depreciated on Cloud) or OAuth2 Authentication)
		String username = "localadmin";
		String apiToken = pojoPrefs.getApiToken(); //  "your-api-token"; // Use a Personal Access Token (PAT) if needed
		String auth = username + ":" + apiToken; // credentials for Basic Authentication
		auth = apiToken; //-- apiToken only for OAuth2
		///-- Build requestData:
		JSONObject requestData = new JSONObject();
		requestData.put("Authorization", apiToken);
		String requestBody = requestData.toJSONString();
		///--Encode Authorization:
		///String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes(StandardCharsets.UTF_8)); ///
		String encodedAuth = Base64.getEncoder().encodeToString(requestBody.getBytes(StandardCharsets.UTF_8));

		try {
			///-- https://forum.jmix.io/t/how-to-authenticate-in-rest-from-java-code/1525 --How to authenticate in REST from Java code
			///-- 1. Basic Authentication (Deprecated for Cloud, Still Works for Server/DC). Uses an email and an API token instead of a password.
			///-- HttpRequest requestBasicDepreciated = HttpRequest.newBuilder().uri(URI.create(urlString)).header("Authorization", "Basic " + encodedAuth).header("Accept", "application/json").GET().build();
			///-- 2. OAuth or Personal Access Token (PAT) Authentication. Recommended for Jira Cloud.
			HttpRequest requestOAuth = HttpRequest.newBuilder().uri(URI.create(urlString)).header("Authorization", "Bearer " + apiToken).header("Content-Type", "application/json").header("Accept", "application/json").GET().build();
			///-- Or: .POST(HttpRequest.BodyPublishers.ofString(jsonPayload))
			HttpClient client = HttpClient.newHttpClient(); // Create HTTP client
			HttpResponse<String> response = client.send(requestOAuth, HttpResponse.BodyHandlers.ofString());
			///--Print response details:
			///System.out.println("Status Code: " + response.statusCode());
			///System.out.println("Response Body: " + response.body());

			///--Parse Jira DC Issue Comments
			///System.out.println("~~CallJiraDcApi.Issue: " + anIssueKey); ///
			if (response.statusCode() == HttpURLConnection.HTTP_OK) {
				///--Check if login was successful
				parsedComments = new ParseJiraDcJsonComments().mapJsonArgumentCommentsToTree(response.body(), aJiraInstance);
			} else {
				///System.err.println("Error: Login to Jira DC failed."); ///
			}

			///===============================================================================================
			///			//--Alternative way -- Tested OK
			///			// Create HttpClient
			///			HttpClient client = HttpClient.newHttpClient();
			///			// Create HttpRequest
			///			urlString = "http://localhost:8080/secure/Dashboard.jspa";
			///			urlString = "http://localhost:8080/rest/api/latest/project";
			///			Builder httpRequestBuilder = HttpRequest.newBuilder().uri(URI.create(urlString));
			///			// httpRequestBuilder.header("Authorization", getBasicAuthHeader(client, secret)).header("Content-Type", "application/x-www-form-urlencoded");
			///			httpRequestBuilder.headers("Authorization", encodedAuth).header("Content-Type", "application/json");
			///			// HttpRequest request = HttpRequest.newBuilder().uri(URI.create(urlString)).headers("Authorization", encodedAuth).build();
			///			HttpRequest request = httpRequestBuilder.build();
			///			// Send request asynchronously
			///			CompletableFuture<HttpResponse<String>> future = client.sendAsync(request, HttpResponse.BodyHandlers.ofString());
			///			// Process response
			///			future.thenApply(HttpResponse::body).thenAccept(System.out::println).join();
			///===============================================================================================

		} catch (Exception e) {
			System.err.println("Error: Can't connect Jira DC");
		}
		return parsedComments;
	}
}
