package jiradcapiconnector;

import java.net.MalformedURLException;
import java.net.URL;

import jiraPojoObjects.PojoJiraIssue;
import utilsJsonJiraDc.ParseJiraDcWorkItem;

public class JiraDCApiCalls {

	ParseJiraDcWorkItem parseJiraDcWorkItem = new ParseJiraDcWorkItem();

	/// ------------------------------------------------------------------------------------------------------------------------------------------------------
	/// ---REST API GET from JIRA ------------------------------------------------------------------------------------------------------------------
	/// ------------------------------------------------------------------------------------------------------------------------------------------------------

	public PojoJiraIssue getWorkitemByApiCall(String baseUrl, String login, boolean ISBASICLOGIN, String anWiKey) {
		PojoJiraIssue jiraWI = null;
		try {
			/// http://localhost:8080/rest/api/2/issue/10900?expand=names,renderedFields
			URL jiraURL = new URL(baseUrl + "/rest/api/latest/issue/" + anWiKey);
			String wiString = new JiraDCApiConnector().jiraRestApiGet(jiraURL, login, ISBASICLOGIN);
			if (wiString == null) {
				System.err.print("\n~ERROR: No connection, check if Jira up and running. Exit 001");
				System.exit(0);
			}
			jiraWI = parseJiraDcWorkItem.parseWorkItem(wiString);
		} catch (MalformedURLException e) {
			/// System.err.print("");
		}
		return jiraWI;
	}

	public void getWorkItemChildren(String baseUrl, String login, boolean ISBASICLOGIN, boolean GETTASKS, PojoJiraIssue anEpicAboveGround) {
		/// ---Read WorkItems on the bottom of Jira hierarchy (Tasks, Bugs, etc)
		/// -- 'anEpicAboveGround' -- Epic, having children (e.g. Tasks, Bugs, etc)
		if (GETTASKS) {
			try {
				/// -- http://localhost:8080/rest/api/2/search?jql="Epic Link"=PRKEY-2
				URL jiraURL = new URL(baseUrl + "/rest/api/2/search?jql=\"Epic%20Link\"=" + anEpicAboveGround.getKey());
				String workItemChildren = new JiraDCApiConnector().jiraRestApiGet(jiraURL, login, ISBASICLOGIN);
				if (workItemChildren == null) {
					System.err.print("\n~ERROR-No-Access-To:\n\t" + jiraURL); //DEBUGPRINT
					///System.exit(0);
				} else {
					///System.out.print("\n~" + aWorkItemAboveGround.getIssueType() + ":" + aWorkItemAboveGround.getKey()); //DEBUGPRINT
					parseJiraDcWorkItem.parseEpicLinksToChildTasks(workItemChildren, anEpicAboveGround);
				}
			} catch (MalformedURLException e) {
			}
		}
	}

}
