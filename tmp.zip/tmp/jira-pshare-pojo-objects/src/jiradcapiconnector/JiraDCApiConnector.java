package jiradcapiconnector;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class JiraDCApiConnector {
	/// ~~ Reads Jira Issue using REST API call ~~
	/// ~~ https://community.atlassian.com/t5/Answers-Developer-Questions/Using-JIRA-REST-API-within-Java-project-with-cURL/qaq-p/485712

	public static StringBuilder diagnosticBuffer = new StringBuilder();
	///-- work around of the HTTP 429 status code, "Too Many Requests":
	static int exponentialBackoff = 1000;
	///--'ResponseCode400' -- Used as exceptional Filter ID, indicating that such Filter is not present in the Jira Instance (dbase):
	///-- So that EP URL will be saved in separate file to avoid calling this URL during next scans; 
	public static final String respCode400 = "ResponseCode400";

	public final String jiraRestApiGet(URL aFullUrlAndPath, String aLoginKey, boolean isBasicLogin) {
		/// System.out.print("\n~~HttpURLConnection:'" + aFullUrlAndPath.toString() + "',basicLogin:" + isBasicLogin + ",'" + aLoginKey + "'"); //DEBUGPRINT
		diagnosticBuffer.append("\n~GET:" + aFullUrlAndPath.getFile());
		String responseString = null;
		/// String jsonJiraIssue = "";
		HttpURLConnection connection = null;
		///StringBuilder response = new StringBuilder();
		try {
			UnsafeSSL.disableCertificateValidation();
			String data = "";
			///byte[] dataBytes = data.getBytes("UTF-8");
			final byte[] authBytes = aLoginKey.getBytes(StandardCharsets.UTF_8);
			String encodedLoginKey = Base64.getEncoder().withoutPadding().encodeToString(authBytes);
			/// ~~ Establish connection and request properties
			connection = (HttpURLConnection) aFullUrlAndPath.openConnection();
			connection.setRequestMethod("GET");
			connection.setRequestProperty("Accept", "application/json");
			connection.setRequestProperty("Content-Type", "application/json");
			if (isBasicLogin) {
				connection.setRequestProperty("Authorization", "Basic " + encodedLoginKey);
			} else {
				/// PAT as Bearer
				connection.setRequestProperty("Authorization", "Bearer " + aLoginKey);
			}
			connection.setUseCaches(false);
			connection.setDoInput(true);
			/// Set the timeout values (optional)
			connection.setConnectTimeout(2000); // 5 sec
			connection.setReadTimeout(2000); // 5 sec
			connection.connect();
			/// --Dump the raw input stream to avoid the first byte loss.
			try (InputStream is = connection.getInputStream()) {
				/// -- Read all raw bytes
				byte[] bytes = is.readAllBytes();
				/// System.out.println("First byte value: " + (bytes.length > 0 ? bytes[0] & 0xFF : "EMPTY")); //DEBUGPRINT
				/// Convert properly
				responseString = new String(bytes, StandardCharsets.UTF_8);
			} catch (Exception e) {
				///-- e.getMessage(): 'Read timed out'
				///-- e.getMessage(): 'Server returned HTTP response code: 400 for URL: https://...' //--Meaning: This EP doesn't exist 
				///-- e.getMessage(): 'Server returned HTTP response code: 429 for URL: https://...' //--Meaning: Too Many Requests
				//DEBUGPRINT
				///System.err.print("\n~Exception-000-access-to:\n\t~" + aFullUrlAndPath + "\n\t~" + e.getMessage()); //DEBUGPRINT
				///System.out.print("\n~Resp_400: " + aFullUrlAndPath);
			}
			///System.out.println(responseString); //DEBUGPRINT
			///System.out.print(diagnosticBuffer); //DEBUGPRINT
			int responseCode = connection.getResponseCode();
			if (responseCode == 200) {
				exponentialBackoff = 1000;
				return responseString;
			} else if (responseCode == 400) {
				///System.out.print("\n\t~1~ResponseCode400"); //DEBUGPRINT
				exponentialBackoff = 1000;
				///DEBUGPRINT
				System.out.print("\n~E400 Bad Request to " + aFullUrlAndPath);
				return respCode400;
			} else if (responseCode == 429) {
				//DEBUGPRINT
				System.out.print("\n~E429 Too Many Requests, pause for " + (exponentialBackoff / 1000) + "s.");
				try {
					Thread.sleep(exponentialBackoff);
				} catch (InterruptedException e) {
					System.out.print(" ~~ERR:Sleep was interrupted"); //DEBUGPRINT
				}
				exponentialBackoff = exponentialBackoff * 2;
				return null;
			} else {
				///-- for https://qa-jira.zebra.com/rest/api/2/filter/99003 :
				///--'The selected filter is not available to you, perhaps it has been deleted or had its permissions changed''
				diagnosticBuffer.append("\n~responseCode:" + responseCode + ", N/A endpoint: " + aFullUrlAndPath.getPath());
				/// System.err.print(diagnosticBuffer); //DEBUGPRINT
				exponentialBackoff = 1000;
				return null;
			}
		} catch (MalformedURLException e) {
			diagnosticBuffer.append("\n~MalformedURLException: " + e.getMessage());
			///System.err.println("\n~MalformedURLException: " + e.getMessage()); //DEBUGPRINT
		} catch (IOException e) {
			diagnosticBuffer.append("\n~IOException:" + e.getMessage());
			System.err.println("\n~IOException: " + e.getMessage());
			if (connection != null) {
				try {
					diagnosticBuffer.append("\n~Err:" + connection.getResponseMessage());
					System.out.println(connection.getResponseMessage());
					InputStream errorStream = connection.getErrorStream(); //DEBUGPRINT
					if (errorStream != null) { //DEBUGPRINT
						Reader in = new BufferedReader(new InputStreamReader(errorStream)); //DEBUGPRINT
						for (int c; (c = in.read()) >= 0; System.out.print((char) c)) //DEBUGPRINT
							; //DEBUGPRINT
					} //DEBUGPRINT
				} catch (IOException e2) {
					diagnosticBuffer.append("\n~IOException2:" + e2.getMessage());
				}
			}
		} catch (Exception e) {
			diagnosticBuffer.append("\n~Exception : " + e.getMessage());
			///System.err.println("\n~Exception : " + e.getMessage()); //DEBUGPRINT
			///e.printStackTrace();
		}
		/// System.out.println(response.toString()); //DEBUGPRINT
		return responseString;
	}

	public final JSONObject jiraRestApiPost(String aFullUrlAndPath, String aLogin, String aJsonPayload) {
		/// ~~ Json object ready. Push it as payload to the Jira REST API ~~
		JSONObject json = null;
		try {
			byte[] dataBytes = aJsonPayload.getBytes("UTF-8");
			final byte[] authBytes = aLogin.getBytes(StandardCharsets.UTF_8);
			String encoded = Base64.getEncoder().withoutPadding().encodeToString(authBytes);
			HttpURLConnection connection = null;
			URL jiraURL;
			/// jiraURL = new URL("http://localhost:8080/rest/servicedeskapi/request/");
			/// jiraURL = new URL("http://localhost:8080/rest/api/2/issue/");
			try {
				jiraURL = new URL(aFullUrlAndPath);
				/// ~~ Establish connection and request properties
				connection = (HttpURLConnection) jiraURL.openConnection();
				connection.setRequestMethod("POST");
				connection.setRequestProperty("Accept", "*/*");
				connection.setRequestProperty("Content-Type", "application/json");
				connection.setRequestProperty("Authorization", "Basic " + encoded);
				connection.setUseCaches(false);
				connection.setDoOutput(true);
				connection.setDoInput(true);
				connection.connect();
				DataOutputStream wr = new DataOutputStream(connection.getOutputStream());
				wr.write(dataBytes);
				wr.flush();
				wr.close();
				System.out.println("Created Issue:"); //DEBUGPRINT
				Reader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
				StringBuilder createdIssue = new StringBuilder();
				for (int c; (c = in.read()) >= 0; createdIssue.append((char) c))
					;
				System.out.print(createdIssue); //DEBUGPRINT
				try {
					/// --Converting Json String to JSONObject, no parsing
					JSONParser parser = new JSONParser();
					json = (JSONObject) parser.parse(createdIssue.toString());
				} catch (ParseException e) {
				}
			} catch (MalformedURLException e) {
				System.err.println("MalformedURLException: " + e.getMessage()); //DEBUGPRINT
			} catch (IOException e) {
				System.err.println("IOException: " + e.getMessage()); //DEBUGPRINT
				if (connection != null) {
					try { //DEBUGPRINT
						System.out.println(connection.getResponseMessage()); //DEBUGPRINT
					} catch (IOException e1) { //DEBUGPRINT
					} //DEBUGPRINT
					InputStream errorStream = connection.getErrorStream();
					if (errorStream != null) {
						Reader in = new BufferedReader(new InputStreamReader(errorStream)); //DEBUGPRINT
						try { //DEBUGPRINT
							for (int c; (c = in.read()) >= 0; System.out.print((char) c)) //DEBUGPRINT
								; //DEBUGPRINT
						} catch (IOException e1) { //DEBUGPRINT
						} //DEBUGPRINT
					}
				}
			}
		} catch (UnsupportedEncodingException e1) {
		}
		return json;
	}
}
