package jiraPojoObjects;

public class PojoComponent {
	private Integer id; // 10128 //--Jira DC Long ID
	private String idString; //--cloud.components.id: "10128"
	private Integer project; // 10128 --cloud.components.projectId: 10002
	private String projectKey; //--cloud.components.project: "PRKEY"
	private String cname; //--cloud.components.name: "Intranet"
	private String description; //--cloud.components.name: "Issues related to the intranet. Created by Jira Service Management."
	private String url;
	private String lead;
	private Integer assigneetype; // api: "assigneeType": "PROJECT_LEAD"; dbase: "assigneetype": 3, numeric(18)
	private String archived; // api: "archived": false; dbase: "archived": "N" varchat(10)
	private String deleted; // api: "deleted": false; dbase: "deleted": "Y" varchat(10)
	private String self; //--
	private String leadSelf;//--"cloud.components.lead.self": "https://brighttunneljsm.atlassian.net/rest/api/2/component/10032"
	private String leadAccountId;//--"cloud.components.lead.accountId": "712020:32eedafd-8926-4481-a731-2d4ad0529164"
	private String leadAccountType;//--"cloud.components.lead.accountType": "atlassian",
	private String leadDisplayName;//--"cloud.components.lead.displayName": "dcuser"
	private String leadActive;//--"cloud.components.lead.active": false
	private String assigneeType; //--cloud.components.assigneeType": "UNASSIGNED",
	private String realAssigneeType; //--cloud.components.realAssigneeType": "UNASSIGNED",
	private boolean isAssigneeTypeValid; //--cloud.components.isAssigneeTypeValid": true,

	//~~Setters
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getProject() {
		return project;
	}
	public void setProject(Integer project) {
		this.project = project;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getLead() {
		return lead;
	}
	public void setLead(String lead) {
		this.lead = lead;
	}
	public Integer getAssigneetype() {
		return assigneetype;
	}
	public void setAssigneetype(Integer assigneetype) {
		this.assigneetype = assigneetype;
	}
	public String getIdString() {
		return idString;
	}
	public void setIdString(String idString) {
		this.idString = idString;
	}
	public String getProjectKey() {
		return projectKey;
	}
	public void setProjectKey(String projectKey) {
		this.projectKey = projectKey;
	}
	public String getLeadSelf() {
		return leadSelf;
	}
	public void setLeadSelf(String leadSelf) {
		this.leadSelf = leadSelf;
	}
	public String getLeadAccountId() {
		return leadAccountId;
	}
	public void setLeadAccountId(String leadAccountId) {
		this.leadAccountId = leadAccountId;
	}
	public String getLeadAccountType() {
		return leadAccountType;
	}
	public void setLeadAccountType(String leadAccountType) {
		this.leadAccountType = leadAccountType;
	}
	public String getLeadDisplayName() {
		return leadDisplayName;
	}
	public void setLeadDisplayName(String leadDisplayName) {
		this.leadDisplayName = leadDisplayName;
	}
	public String getLeadActive() {
		return leadActive;
	}
	public void setLeadActive(String leadActive) {
		this.leadActive = leadActive;
	}
	public String getAssigneeType() {
		return assigneeType;
	}
	public void setAssigneeType(String assigneeType) {
		this.assigneeType = assigneeType;
	}
	public String getRealAssigneeType() {
		return realAssigneeType;
	}
	public void setRealAssigneeType(String realAssigneeType) {
		this.realAssigneeType = realAssigneeType;
	}
	public boolean isAssigneeTypeValid() {
		return isAssigneeTypeValid;
	}
	public void setAssigneeTypeValid(boolean isAssigneeTypeValid) {
		this.isAssigneeTypeValid = isAssigneeTypeValid;
	}
	public String getSelf() {
		return self;
	}
	public void setSelf(String self) {
		this.self = self;
	}
	public String getArchived() {
		return archived;
	}
	public void setArchived(String archived) {
		this.archived = archived;
	}
	public String getDeleted() {
		return deleted;
	}
	public void setDeleted(String deleted) {
		this.deleted = deleted;
	}

}
