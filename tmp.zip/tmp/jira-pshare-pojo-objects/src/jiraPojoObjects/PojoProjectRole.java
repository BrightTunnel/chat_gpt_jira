package jiraPojoObjects;

import java.util.HashMap;

public class PojoProjectRole {

	//--JiraCloud--:
	//[{
	//	"self": "https://brighttunneldev.atlassian.net/rest/api/2/role/10002",
	//	"name": "Administrators",
	//	"id": 10002,
	//	"description": "A project role that represents administrators in a project"
	//}, {
	//	"self": "https://brighttunneldev.atlassian.net/rest/api/2/role/10003",
	//	"name": "atlassian-addons-project-access",
	//	"id": 10003,
	//	"description": "A project role that represents Connect add-ons declaring a scope that requires more than read issue permissions",
	//	"scope": {
	//		"type": "PROJECT",
	//		"project": {
	//			"id": "10003"
	//		}
	//	}	
	//	"actors": [{
	//			"id": 10006,
	//			"displayName": "Slack",
	//			"type": "atlassian-user-role-actor",
	//			"actorUser": {
	//				"accountId": "557058:0867a421-a9ee-4659-801a-bc0ee4a4487e"
	//			}
	//		},...

	//private String self; //--e.g.: "https://brighttunneldev.atlassian.net/rest/api/2/role/10003",
	private String name; //--e.g.: ["Administrators", "Service Desk Customers", "Service Desk Team", "atlassian-addons-project-access"] (DC, JiraCloud)
	private String rolepath; //--e.g.:  "Service Desk Customers": "https://site.atlassian.net/rest/api/2/project/10000/role/10004"
	private Long id; //--e.g.: [10002,...10005] (DC, JiraCloud)
	private String description; //--e.g.: "A project role that represents Connect add-ons declaring a scope that requires more than read issue permissions", (DC, JiraCloud)
	//private String scope; //--e.g.: {
	private String scopeType; //--e.g.: "scope": {"type": "PROJECT",
	//private String scopeProject; //--e.g.: {
	private String scopeProjectId; //--e.g.: "scope": {"type": "PROJECT", "project": {"id": "10003"}
	private HashMap<Long, PojoProjectRoleActor> actors; //--e.g.: [{

	//---

	public HashMap<Long, PojoProjectRoleActor> getActors() {
		return actors;
	}
	public void setActors(HashMap<Long, PojoProjectRoleActor> actors) {
		this.actors = actors;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getScopeType() {
		return scopeType;
	}
	public void setScopeType(String scopeType) {
		this.scopeType = scopeType;
	}
	public String getScopeProjectId() {
		return scopeProjectId;
	}
	public void setScopeProjectId(String scopeProjectId) {
		this.scopeProjectId = scopeProjectId;
	}
	public String getRolepath() {
		return rolepath;
	}
	public void setRolepath(String rolepath) {
		this.rolepath = rolepath;
	}

}
