package jiraPojoObjects;

import java.util.Date;

public class PojoCwd_user {
	///~~ db table 'cwd_user': [id,directory_id,user_name,lower_user_name,active,created_date,updated_date,first_name,lower_first_name,last_name,lower_last_name,display_name,lower_display_name,email_address,lower_email_address,credential,deleted_externally,external_id]
	private Long id;
	private Long directory_id;
	private String user_name;
	private String lower_user_name;
	private Long active;
	private Date created_date;
	private Date updated_date;
	private String first_name;
	private String lower_first_name;
	private String last_name;
	private String lower_last_name;
	private String display_name;
	private String lower_display_name;
	private String email_address;
	private String lower_email_address;
	private String credential;
	private Long deleted_externally;
	private String external_id;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getDirectory_id() {
		return directory_id;
	}

	public void setDirectory_id(Long directory_id) {
		this.directory_id = directory_id;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getLower_user_name() {
		return lower_user_name;
	}

	public void setLower_user_name(String lower_user_name) {
		this.lower_user_name = lower_user_name;
	}

	public Long getActive() {
		return active;
	}

	public void setActive(Long active) {
		this.active = active;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}

	public Date getUpdated_date() {
		return updated_date;
	}

	public void setUpdated_date(Date updated_date) {
		this.updated_date = updated_date;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLower_first_name() {
		return lower_first_name;
	}

	public void setLower_first_name(String lower_first_name) {
		this.lower_first_name = lower_first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getLower_last_name() {
		return lower_last_name;
	}

	public void setLower_last_name(String lower_last_name) {
		this.lower_last_name = lower_last_name;
	}

	public String getDisplay_name() {
		return display_name;
	}

	public void setDisplay_name(String display_name) {
		this.display_name = display_name;
	}

	public String getLower_display_name() {
		return lower_display_name;
	}

	public void setLower_display_name(String lower_display_name) {
		this.lower_display_name = lower_display_name;
	}

	public String getEmail_address() {
		return email_address;
	}

	public void setEmail_address(String email_address) {
		this.email_address = email_address;
	}

	public String getLower_email_address() {
		return lower_email_address;
	}

	public void setLower_email_address(String lower_email_address) {
		this.lower_email_address = lower_email_address;
	}

	public String getCredential() {
		return credential;
	}

	public void setCredential(String credential) {
		this.credential = credential;
	}

	public Long getDeleted_externally() {
		return deleted_externally;
	}

	public void setDeleted_externally(Long deleted_externally) {
		this.deleted_externally = deleted_externally;
	}

	public String getExternal_id() {
		return external_id;
	}

	public void setExternal_id(String external_id) {
		this.external_id = external_id;
	}

}
