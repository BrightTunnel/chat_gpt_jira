package jiraPojoObjects;

public class PojoWorkflowscheme {
	///~~ SELECT id, "name", description 	FROM public.workflowscheme
	//	10000	classic	classic
	//	10201	WFScheme01 Inactive	WFScheme01 Inactive Descr
	//	10100	PM: Project Management Workflow Scheme Active	
	//	10300	BP: Process Management Workflow Scheme		

	private Long id; // 10000
	private String name;
	private String description;

	///~~ Getters / Setters
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

}
