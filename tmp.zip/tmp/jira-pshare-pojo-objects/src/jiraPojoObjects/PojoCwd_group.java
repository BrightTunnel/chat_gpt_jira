package jiraPojoObjects;

public class PojoCwd_group {

	private Long id;
	private String group_name;
	private String lower_group_name;
	private String active;
	private String local;
	private String created_date;
	private String updated_date;
	private String description;
	private String lower_description;
	private String group_type;
	private String directory_id;
	private String external_id;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getGroup_name() {
		return group_name;
	}

	public void setGroup_name(String group_name) {
		this.group_name = group_name;
	}

	public String getLower_group_name() {
		return lower_group_name;
	}

	public void setLower_group_name(String lower_group_name) {
		this.lower_group_name = lower_group_name;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getLocal() {
		return local;
	}

	public void setLocal(String local) {
		this.local = local;
	}

	public String getCreated_date() {
		return created_date;
	}

	public void setCreated_date(String created_date) {
		this.created_date = created_date;
	}

	public String getUpdated_date() {
		return updated_date;
	}

	public void setUpdated_date(String updated_date) {
		this.updated_date = updated_date;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLower_description() {
		return lower_description;
	}

	public void setLower_description(String lower_description) {
		this.lower_description = lower_description;
	}

	public String getGroup_type() {
		return group_type;
	}

	public void setGroup_type(String group_type) {
		this.group_type = group_type;
	}

	public String getDirectory_id() {
		return directory_id;
	}

	public void setDirectory_id(String directory_id) {
		this.directory_id = directory_id;
	}

	public String getExternal_id() {
		return external_id;
	}

	public void setExternal_id(String external_id) {
		this.external_id = external_id;
	}

}
