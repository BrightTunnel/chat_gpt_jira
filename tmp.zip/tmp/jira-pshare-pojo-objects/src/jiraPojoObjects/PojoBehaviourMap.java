package jiraPojoObjects;

import java.util.HashMap;

public class PojoBehaviourMap {

	//private String behaviourItemKey;
	private HashMap<String, PojoBehaviourMapItem> mapBehaviourConfigurationItem;

	// ~~ Extra 
	public void doAddItem(PojoBehaviourMapItem _behaviourMapItem) {
		// this.behaviourItemKey = _behaviourMapItem.getBehaviourItemKey();
		if (this.mapBehaviourConfigurationItem == null) {
			this.mapBehaviourConfigurationItem = new HashMap<String, PojoBehaviourMapItem>();
		}
		this.mapBehaviourConfigurationItem.put(_behaviourMapItem.getBehaviourItemKey(), _behaviourMapItem);
	}

	// ~~~ Getters/Setters ~~~

	public HashMap<String, PojoBehaviourMapItem> getMapBehaviourConfigurationItem() {
		return mapBehaviourConfigurationItem;
	}

	public void setMapBehaviourConfigurationItem(HashMap<String, PojoBehaviourMapItem> mapBehaviourConfigurationItem) {
		this.mapBehaviourConfigurationItem = mapBehaviourConfigurationItem;
	}

}
