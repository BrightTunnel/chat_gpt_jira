package jiraPojoObjects;

import java.util.HashMap;

public class PojoGroup {
	//--JiraCloud--
	//"header": "Showing 16 of 16 matching groups",
	//"total": 16,
	//"groups": [{
	//		"name": "atlassian-addons-admin",
	//		"html": "atlassian-addons-admin",
	//		"labels": [{
	//				"text": "Admin",
	//				"title": "Users added to this group will be given administrative access",
	//				"type": "ADMIN"
	//			}, {
	//				"text": "Multi-App-Access",
	//				"title": "Users added to this group will be given access to <strong>Jira Service Desk</strong>, <strong>Jira Software</strong> and <strong>Jira Core</strong>",
	//				"type": "MULTIPLE"
	//			}
	//		],
	//		"groupId": "dee3c498-ff48-4143-a979-71e66c3e7c43"
	//	}, {
	//		"name": "confluence-admins-brighttunneldev",
	//		"html": "confluence-admins-brighttunneldev",
	//		"labels": [],
	//		"groupId": "f5eb174a-1785-4078-9fca-a51d91048171"
	//	}, {

	private String groupId; //--e.g.: ["106bafec-1db8-4fdb-b08e-194c7ff789a3"
	private String name; //--e.g.: ["confluence-user-access-admins-brighttunneldev",
	private String html; //--e.g.: ["confluence-user-access-admins-brighttunneldev",
	private HashMap<String, PojoGroupLabels> labels; //--e.g.: "labels": [{"text": "Admin","title": "Users added to this group will be given administrative access","type": "ADMIN"}, {...}]
	//private String self; //--e.g.:  "self": "https://brighttunnel.atlassian.net/rest/api/3/group?groupId=6ae82f8f-f4a7-4ea8-a14c-5418451f9647"
	private HashMap<String, PojoUser> groupMember; // group-member: {AccountID, AccountType, Email, DisplayName, Active}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getHtml() {
		return html;
	}
	public void setHtml(String html) {
		this.html = html;
	}
	public HashMap<String, PojoGroupLabels> getLabels() {
		return labels;
	}
	public void setLabels(HashMap<String, PojoGroupLabels> labels) {
		this.labels = labels;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public HashMap<String, PojoUser> getGroupMember() {
		return groupMember;
	}
	public void setGroupMember(HashMap<String, PojoUser> groupMember) {
		this.groupMember = groupMember;
	}

}
