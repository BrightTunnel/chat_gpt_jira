package jiraPojoObjects;

public class PojoPermission {

	//--Jira Cloud--:
	//"permissions": {
	//	"ADD_COMMENTS": {
	//		"key": "ADD_COMMENTS",
	//		"name": "Add Comments",
	//		"type": "PROJECT",
	//		"description": "Ability to comment on issues."
	//	},
	//	"ADMINISTER": {
	//		"key": "ADMINISTER",
	//		"name": "Administer Jira",
	//		"type": "GLOBAL",
	//		"description": "Create and administer projects, issue types, fields, workflows, and schemes for all projects. Users with this permission can perform most administration tasks, except: managing users, importing data, and editing system email settings."
	//	},

	private String rootkey; //--e.g.: 'ADD_COMMENTS'
	private String key; //--e.g.: 'ADD_COMMENTS'
	private String name; //--e.g.: 'Add Comments'
	private String type; //--e.g.: 'PROJECT'
	private String description; //--e.g.: 'Ability to comment on issues.'

	//~~~ Getters/Setters ~~
	public String getRootkey() {
		return rootkey;
	}
	public void setRootkey(String rootkey) {
		this.rootkey = rootkey;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

}
