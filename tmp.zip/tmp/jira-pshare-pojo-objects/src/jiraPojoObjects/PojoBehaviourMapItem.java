package jiraPojoObjects;

public class PojoBehaviourMapItem {

	private String behaviourItemKey; // behaviourConfigurationIdLong + projectId + issuetypeId
	private Long projectId; // -1 All Projects/ Service Desks. <project  pid="10301" configuration="3"/> OR <servicedesk servicedeskid="3" configuration="34"/>
	private Long issuetypeId; // -1 All Issue/Request Types. <issuetype id="10100" configuration="2"/> OR <requesttype id="101" configuration="20"/>
	private boolean isIssuetypeOrRequesttype;

	//~~ Duplicated for easy use, will be the same value for the set, which belongs to the parent behaviourConfiguration with the same behaviourConfigurationIdLong     
	private Long behaviourConfigurationIdLong; // The Behaviour_1 Configuration ID <config id="1"/> == Key Behaviour_1

	//~~ Specials ~~
	public void setBehaviourItemKey() {
		this.behaviourItemKey = behaviourConfigurationIdLong + " " + projectId + " " + issuetypeId;
	}

	// ~~~ Getters/Setters ~~~
	public Long getProjectId() {
		return projectId;
	}
	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}
	public Long getIssuetypeId() {
		return issuetypeId;
	}
	public void setIssuetypeId(Long issuetypeId) {
		this.issuetypeId = issuetypeId;
	}
	public String getBehaviourItemKey() {
		return behaviourItemKey;
	}
	public void setBehaviourItemKey(String behaviourItemKey) {
		this.behaviourItemKey = behaviourItemKey;
	}
	public Long getBehaviourConfigurationIdLong() {
		return behaviourConfigurationIdLong;
	}
	public void setBehaviourConfigurationIdLong(Long behaviourConfigurationIdLong) {
		this.behaviourConfigurationIdLong = behaviourConfigurationIdLong;
	}

	public boolean isIssuetypeOrRequesttype() {
		return isIssuetypeOrRequesttype;
	}

	public void setIssuetypeOrRequesttype(boolean isIssuetypeOrRequesttype) {
		this.isIssuetypeOrRequesttype = isIssuetypeOrRequesttype;
	}

}
