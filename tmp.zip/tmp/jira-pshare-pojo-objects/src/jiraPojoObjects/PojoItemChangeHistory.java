package jiraPojoObjects;
import java.util.Date;

public class PojoItemChangeHistory {
	private String customvalue;
	private Date changeTime;

	public String getCustomvalue() {
		return customvalue;
	}
	public void setCustomvalue(String customvalue) {
		this.customvalue = customvalue;
	}

	public Date getChangeTime() {
		return changeTime;
	}
	public void setChangeTime(Date changeTime) {
		this.changeTime = changeTime;
	}

	@Override
	public String toString() {
		return changeTime + " " + customvalue;
	}

}
