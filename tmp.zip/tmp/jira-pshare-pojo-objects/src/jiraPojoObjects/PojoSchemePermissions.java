package jiraPojoObjects;

public class PojoSchemePermissions {

	private Long id;
	private Long scheme;
	private Long permission;
	private String perm_type;
	private String perm_parameter;
	private String permission_key;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getScheme() {
		return scheme;
	}

	public void setScheme(Long scheme) {
		this.scheme = scheme;
	}

	public Long getPermission() {
		return permission;
	}

	public void setPermission(Long permission) {
		this.permission = permission;
	}

	public String getPerm_type() {
		return perm_type;
	}

	public void setPerm_type(String perm_type) {
		this.perm_type = perm_type;
	}

	public String getPerm_parameter() {
		return perm_parameter;
	}

	public void setPerm_parameter(String perm_parameter) {
		this.perm_parameter = perm_parameter;
	}

	public String getPermission_key() {
		return permission_key;
	}

	public void setPermission_key(String permission_key) {
		this.permission_key = permission_key;
	}

}
