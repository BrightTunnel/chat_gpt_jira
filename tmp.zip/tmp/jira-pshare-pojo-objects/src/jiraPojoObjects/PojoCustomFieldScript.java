package jiraPojoObjects;

import java.util.TreeMap;

import jiraPojoXml.PojoXmlElementInitOrField;

public class PojoCustomFieldScript {
	private PojoXmlElementInitOrField xmlElementInitOrField; // ~~ From script-runner behaviour server-side <validator-script> ~~
	// ~~ Extra
	private String scriptCFKeyNameAndID; // ~~ combined CF Name and short numeric CFID to keep the Dictionary Key Unique in case we have two or more same CF names
	private TreeMap<String, PojoCustomField> scriptCalledCustomFields; // ~~ List of all custom fields used (called) in the script.
	private int serialCFNumberInBehaviour; //~~ Index of the Behaviour custom fields with possible server-side script to build the Decision table matrix  

	// ~~~ Getters/Setters ~~~
	public String getScriptCFKeyNameAndID() {
		return scriptCFKeyNameAndID;
	}

	public void setScriptCFKeyNameAndID(String cfKeyNameAndID) {
		this.scriptCFKeyNameAndID = cfKeyNameAndID;
	}

	public TreeMap<String, PojoCustomField> getScriptCalledCustomFields() {
		return scriptCalledCustomFields;
	}

	public void setScriptCalledCustomFields(TreeMap<String, PojoCustomField> scriptCalledCustomFields) {
		this.scriptCalledCustomFields = scriptCalledCustomFields;
	}

	public int getSerialCFNumberInBehaviour() {
		return serialCFNumberInBehaviour;
	}

	public void setSerialCFNumberInBehaviour(int idx) {
		this.serialCFNumberInBehaviour = idx;
	}

	public PojoXmlElementInitOrField getXmlElementInitOrField() {
		return xmlElementInitOrField;
	}

	public void setXmlElementInitOrField(PojoXmlElementInitOrField xmlElementInitOrField) {
		this.xmlElementInitOrField = xmlElementInitOrField;
	}

}
