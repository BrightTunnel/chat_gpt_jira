package jiraPojoObjects;

public class PojoFixVersion {

	// {"self": "http://localhost:8080/rest/api/2/version/10100",
	// "id": "10100",
	// "name": "Version-01",
	// "archived": false,
	// "released": false,
	// "projectId": 10300}

	private String self; // {"self": "http://localhost:8080/rest/api/2/version/10100",
	private String id; // "id": "10100",
	private String name; // "name": "Version-01",
	private boolean archived; // "archived": false,
	private boolean released; // "released": false,
	private Integer projectId; // "projectId": 10300}

	//~~Getters / Setters
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isArchived() {
		return archived;
	}
	public void setArchived(boolean archived) {
		this.archived = archived;
	}
	public boolean isReleased() {
		return released;
	}
	public void setReleased(boolean released) {
		this.released = released;
	}
	public Integer getProjectId() {
		return projectId;
	}
	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}
	public String getSelf() {
		return self;
	}
	public void setSelf(String self) {
		this.self = self;
	}

}
