package jiraPojoObjects;

import java.util.LinkedHashMap;

public class PojoWorkflowAction {
	///~~ This represents Node '<action id="11" name="Start Progress">' of the WF XML Object
	///~~ There is no related Jira DB table.  

	private Long actionId; // <action id="11" name="Start Progress">
	private String actionName; // <action id="11" name="Start Progress"> ~~ This 'Start Progress' will be visible on an transition arrow in Jira WF UI
	private String actionMetaJiraDescription; // <meta name="jira.description"/>
	private String actionMetaJiraFieldscreenID; //~~ <meta name="jira.fieldscreen.id"></meta>
	private String actionTransitionTargetStepID; // <unconditional-result old-status="Finished" status="Open" step="8"> ~~ step="8" will be pointion to the Transition Target WF Step e.g. step/status "Rejected": <step id="8" name="Rejected"> 	 

	private String terminalActionKind; //~~ might be one of the listed below kinds: ~~Breadcrumbs 
	///	condition: <!-- restrict-to.conditions.condition --> //  <conditions type="OR"> <condition type="class"> 
	///	validator: <!-- validators.validator -->
	///	function: <!-- results.unconditional-result.post-functions.function --> //<unconditional-result old-status="Finished" status="Open" step="8"><function type="class"> 	
	private String terminalActionName; // <validator name="" type="class">
	private String terminalActionType; // <validator name="" type="class">

	///~~ Arguments for <function type="class">:
	private LinkedHashMap<String, String> args; // All Found Arguments

	//	private String argClassName; //<arg name="class.name">com.onresolve.jira.groovy.GroovyFunctionPlugin</arg>
	//	private String argPermission; //<arg name="permission">Create Issue</arg>
	//	private String argFullModuleKey; //<arg name="full.module.key">com.onresolve.jira.groovy.groovyrunnerscriptrunner-workflow-function-com.onresolve.scriptrunner.canned.jira.workflow.postfunctions.FasttrackTransition</arg>
	//	private String argCannedScript; //<arg name="canned-script">com.onresolve.scriptrunner.canned.jira.workflow.postfunctions.FasttrackTransition</arg>
	//	private String argEvents; //<arg name="events"/>
	//	private String argFIELD_FUNCTION_ID; //<arg name="FIELD_FUNCTION_ID">06130458-eec7-49c8-958c-bd041de215cb</arg>
	//	private String argFIELD_ACTION; //<arg name="FIELD_ACTION">1031 Send to Legal</arg>
	//	private String argFIELD_NOTESBase64; //<arg name="FIELD_NOTES">YCFgVHJpZ2dlciB0cmFuc2l0aW9uIGludG8gTGVnYWwgUmV2aWV3IHN0YXR1cw==</arg>
	//	private String argFIELD_NOTESAscii; //<arg name="FIELD_NOTES">`!`Trigger transition into Legal Review status</arg>
	//	private String argFIELD_COMMENTAscii;
	// private String argFIELD_CONDITIONBase64; //<arg name="FIELD_CONDITION">YCFgeyJzY3JpcHQiOm51bGwsInNjcmlwdFBhdGgiOiJ3b3JrZmxvd3NcXHBvc3RmdW5jdGlvbnNcXHNpbmdsZVxcYnNzZFxcc29mdHdhcmVBcHByb3ZhbFByb2Nlc3MvQ29uZGl0aW9uRm9yTGVnYWxSZXZpZXdTdGF0dXNGb3JBdXRvVHJhbnNpdGlvbi5ncm9vdnkiLCJwYXJhbWV0ZXJzIjp7fX0=</arg>
	//	private String argFIELD_CONDITIONAscii; //<arg name="FIELD_CONDITION">`!`{"script":null,"scriptPath":"workflows\\postfunctions\\single\\bssd\\softwareApprovalProcess/ConditionForLegalReviewStatusForAutoTransition.groovy","parameters":{}}</arg>
	//	//private String argFIELD_SCRIPT_FILE_OR_SCRIPTBase64;
	//	private String argFIELD_SCRIPT_FILE_OR_SCRIPTAscii;
	//	private String argFIELD_TRANSITION_OPTIONS; //<arg name="FIELD_TRANSITION_OPTIONS">FIELD_SKIP_PERMISSIONS</arg>
	//	private String argFIELD_ADDITIONAL_SCRIPT; //<arg name="FIELD_ADDITIONAL_SCRIPT"/>
	//	private String argFIELD_JQL_QUERY; // <arg name="FIELD_JQL_QUERY">project = "Business Systems Service Desk" AND issuetype in (Improvement, Bug, Vulnerability, Support)</arg>
	//	private String argjqlQuery;// <arg name="jqlQuery">key = {issue.key} AND !(issuetype in (Improvement, Bug)</arg>

	///~~~ Getters / Setters 
	public Long getActionId() {
		return actionId;
	}

	public void setActionId(Long actionId) {
		this.actionId = actionId;
	}

	public String getActionName() {
		return actionName;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

	public String getActionMetaJiraDescription() {
		return actionMetaJiraDescription;
	}

	public void setActionMetaJiraDescription(String actionMetaJiraDescription) {
		this.actionMetaJiraDescription = actionMetaJiraDescription;
	}

	public String getTerminalActionKind() {
		return terminalActionKind;
	}

	public void setTerminalActionKind(String terminalActionKind) {
		this.terminalActionKind = terminalActionKind;
	}

	public String getTerminalActionName() {
		return terminalActionName;
	}

	public void setTerminalActionName(String terminalActionName) {
		this.terminalActionName = terminalActionName;
	}

	public String getTerminalActionType() {
		return terminalActionType;
	}

	public void setTerminalActionType(String terminalActionType) {
		this.terminalActionType = terminalActionType;
	}

	public String getActionMetaJiraFieldscreenID() {
		return actionMetaJiraFieldscreenID;
	}

	public void setActionMetaJiraFieldscreenID(String actionMetaJiraFieldscreenID) {
		this.actionMetaJiraFieldscreenID = actionMetaJiraFieldscreenID;
	}

	public String getActionTransitionTargetStepID() {
		return actionTransitionTargetStepID;
	}

	public void setActionTransitionTargetStepID(String actionTransitionTargetStepID) {
		this.actionTransitionTargetStepID = actionTransitionTargetStepID;
	}

	public LinkedHashMap<String, String> getArgs() {
		return args;
	}

	public void setArgs(LinkedHashMap<String, String> args) {
		this.args = args;
	}

}
