package jiraPojoObjects;

public class PojoFieldScreenLayoutItem {

	//	<FieldScreenLayoutItem	id="11700"	fieldidentifier="customfield_11000"	sequence="1"	fieldscreentab="10400"/>
	//	<FieldScreenLayoutItem	id="11401"	fieldidentifier="customfield_10552"	sequence="2"	fieldscreentab="10400"/>
	//	<FieldScreenLayoutItem	id="11500"	fieldidentifier="customfield_10800"	sequence="3"	fieldscreentab="10400"/>
	//	<FieldScreenLayoutItem	id="11402"	fieldidentifier="customfield_10551"	sequence="6"	fieldscreentab="10400"/>
	//	<FieldScreenLayoutItem	id="11501"	fieldidentifier="components"				sequence="4"	fieldscreentab="10400"/>
	//	<FieldScreenLayoutItem	id="11502"	fieldidentifier="customfield_10801"	sequence="0"	fieldscreentab="10400"/>
	//	<FieldScreenLayoutItem	id="11403"	fieldidentifier="description"				sequence="7"	fieldscreentab="10400"/>
	//	<FieldScreenLayoutItem	id="11405"	fieldidentifier="issuetype"					sequence="9"	fieldscreentab="10400"/>
	//	<FieldScreenLayoutItem	id="11404"	fieldidentifier="summary"					sequence="8"	fieldscreentab="10400"/>
	//	<FieldScreenLayoutItem	id="11406"	fieldidentifier="customfield_10700"	sequence="5"	fieldscreentab="10400"/>
	//	<FieldScreenLayoutItem	id="11407"	fieldidentifier="fixVersions"				sequence="10"	fieldscreentab="10400"/>

	private Long fieldScreenLayoutItemId; // 10100
	private String fieldidentifier; // customfield_10128, "issuetype", "summary",...
	private int sequence; // 1, 2, 3, ... Position on the screen
	private Long fieldscreentab; // 10400

	//~~~ Extra 
	private Long jiraCustomId; // 10100 - Extracted from fieldidentifier; {customfield_10128}

	public void setFieldidentifier(String aFieldidentifier) {
		this.fieldidentifier = aFieldidentifier;
		Long _cfIdLong = null; // ~~ it's not a custom field or system field
		if (aFieldidentifier != null) { // ~~ customfield_10128, "issuetype", "summary",...
			String _customfieldID = aFieldidentifier.trim();
			if (_customfieldID.length() == "customfield_10128".length()) {
				try {
					_cfIdLong = Long.parseLong(_customfieldID.replace("customfield_", ""));
				} catch (NumberFormatException e) {
				}
			}
		}
		setJiraCustomId(_cfIdLong);
	}

	private void setJiraCustomId(Long jiraCustomId) {
		this.jiraCustomId = jiraCustomId;
	}

	// ~~~ Getters/Setters ~~~

	public Long getFieldScreenLayoutItemId() {
		return fieldScreenLayoutItemId;
	}

	public void setFieldScreenLayoutItemId(Long fieldScreenLayoutItemId) {
		this.fieldScreenLayoutItemId = fieldScreenLayoutItemId;
	}

	public String getFieldidentifier() {
		return fieldidentifier;
	}

	public int getSequence() {
		return sequence;
	}

	public void setSequence(int sequence) {
		this.sequence = sequence;
	}

	public void setFieldscreentab(Long fieldscreentab) {
		this.fieldscreentab = fieldscreentab;
	}

	public Long getFieldscreentab() {
		return fieldscreentab;
	}

	public Long getJiraCustomId() {
		return jiraCustomId;
	}

}
