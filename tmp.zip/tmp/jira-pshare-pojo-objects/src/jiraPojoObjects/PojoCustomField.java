package jiraPojoObjects;

import java.util.TreeMap;

public class PojoCustomField {
	///~~ Jira DB Table 'customfield' fields: 
	// private Long id;
	// private String cfkey;
	// private String customfieldtypekey;
	// private String customfieldsearcherkey;
	// private String cfname;
	// private String description;
	// private String defaultvalue;
	// private Long fieldtype;
	// private Long project;
	// private String issuetype;
	// private Long issueswithvalue;
	// private DateTime lastvalueupdate;

	private Long customFieldIDLong; // ~~ Short CF ID eg: '10500'
	private String customfieldSearcherKey; // {json="searcherType"} "com.atlassian.jira.plugin.system.customfieldtypes:textsearcher"
	private String cfName; // ~~ actual human readable cf name
	private String cfDescription;
	private String customfieldTypeKey; // {json="fieldType"} "com.atlassian.jira.plugin.system.customfieldtypes:textfield"
	private String cfTextContent;
	private boolean cfDisabled;

	//~~ <customfieldvalue Attributes> 
	private String datakey; // ~~ <customfieldvalue data-key="pr/getithelp"><![CDATA[ Get IT help ]]></customfieldvalue>
	private String dataremainingtime; // ~~ <customfieldvalue data-remaining-time="8:00"> 1d</customfieldvalue>

	// ~~ Additional for customfieldtypes:select
	// ~~ {<CustomField id="10500" customfieldtypekey="com.atlassian.jira.plugin.system.customfieldtypes:select" customfieldsearcherkey="com.atlassian.jira.plugin.system.customfieldtypes:multiselectsearcher" name="Impact" issuesWithValue="0"/>}

	//	"customFieldValues": [{
	//			"fieldName": "My text field",
	//			"searcherType": "com.atlassian.jira.plugin.system.customfieldtypes:textsearcher",
	//			"fieldType": "com.atlassian.jira.plugin.system.customfieldtypes:textfield",
	//			"value": "This is the text."},

	private String cfOptionSetDefaultValue;
	private String issuesWithValue; // ~~ May be number as well
	private TreeMap<Long, PojoCustomFieldOption> cfOptions; // ~~ <key>: optionSequence

	// ~~ Extra
	private String cfKeyNameAndID; // ~~ combined CF Name and short numeric CFID to keep the Dictionary Key Unique in case we have two or more same CF names
	private int cfNameRepeatedTimes;
	private String fullElementXmlStringCfOrig; // ~~ Full line from the source file to be parsed to this xml element
	private TreeMap<String, PojoCustomFieldScript> mapOfCFScript;
	private int cfOperation; // ~~  [Mandatory: Required/Optional,  Writable/Readonly,  Hidden/Shown], e.g.: cf.setRequired(true); cf.setHidden(false); cf.setReadOnly()
	private boolean cfInternalForTheBehaviour; // ~~ true - cf is part of the Behaviour in question; false cf is external (not part of the Behaviour)

	@Override
	public String toString() {
		StringBuilder _sb = new StringBuilder();
		_sb.append("'" + cfName + "'");
		_sb.append(" CustomField_" + customFieldIDLong);
		if (cfDescription != null && cfDescription.trim().length() > 0)
			_sb.append(", '" + cfDescription + "'");
		if (customfieldTypeKey != null && customfieldTypeKey.trim().length() > 0)
			_sb.append(", TypeKey: '" + customfieldTypeKey + "'");
		if (customfieldSearcherKey != null && customfieldSearcherKey.trim().length() > 0)
			_sb.append(", SearcherKey: '" + customfieldSearcherKey + "'");
		return _sb.toString();
	}

	// ~~ Getters/Setters ~~
	public Long getCustomFieldIDLong() {
		return customFieldIDLong;
	}

	public void setCustomFieldIDLong(Long customFieldIDLong) {
		this.customFieldIDLong = customFieldIDLong;
	}

	public String getCfName() {
		return cfName;
	}

	public void setCfName(String cfName) {
		this.cfName = cfName;
	}

	public String getCfDescription() {
		return cfDescription;
	}

	public void setCfDescription(String cfDescription) {
		this.cfDescription = cfDescription;
	}

	public String getCustomfieldTypeKey() {
		return customfieldTypeKey;
	}

	public void setCustomfieldTypeKey(String customfieldTypeKey) {
		this.customfieldTypeKey = customfieldTypeKey;
	}

	public String getCustomfieldSearcherKey() {
		return customfieldSearcherKey;
	}

	public void setCustomfieldSearcherKey(String customfieldSearcherKey) {
		this.customfieldSearcherKey = customfieldSearcherKey;
	}

	public TreeMap<String, PojoCustomFieldScript> getMapOfCFScript() {
		return mapOfCFScript;
	}

	public void setMapOfCFScript(TreeMap<String, PojoCustomFieldScript> mapOfCFScript) {
		this.mapOfCFScript = mapOfCFScript;
	}

	public String getFullElementXmlStringOrig() {
		return fullElementXmlStringCfOrig;
	}

	public void setFullElementXmlStringOrig(String fullElementXmlStringCfOrig) {
		this.fullElementXmlStringCfOrig = fullElementXmlStringCfOrig;
	}

	public String getCfKeyNameAndID() {
		return cfKeyNameAndID;
	}

	public void setCfKeyNameAndID(String cfKeyNameAndID) {
		this.cfKeyNameAndID = cfKeyNameAndID;
	}

	public int getCfNameRepeatedTimes() {
		return cfNameRepeatedTimes;
	}

	public void setCfNameRepeatedTimes(int cfNameRepeatedTimes) {
		this.cfNameRepeatedTimes = cfNameRepeatedTimes;
	}

	public String getCfOptionSetDefaultValue() {
		return cfOptionSetDefaultValue;
	}

	public void setCfOptionSetDefaultValue(String cfOptionSetDefaultValue) {
		this.cfOptionSetDefaultValue = cfOptionSetDefaultValue;
	}

	public String getIssuesWithValue() {
		return issuesWithValue;
	}

	public void setIssuesWithValue(String issuesWithValue) {
		this.issuesWithValue = issuesWithValue;
	}

	public TreeMap<Long, PojoCustomFieldOption> getCfOptions() {
		return cfOptions;
	}

	public void setCfOptions(TreeMap<Long, PojoCustomFieldOption> cfOptions) {
		this.cfOptions = cfOptions;
	}

	public String getCfTextContent() {
		return cfTextContent;
	}

	public void setCfTextContent(String cfTextContent) {
		this.cfTextContent = cfTextContent;
	}

	public boolean isCfDisabled() {
		return cfDisabled;
	}

	public void setCfDisabled(boolean cfDisabled) {
		this.cfDisabled = cfDisabled;
	}

	public String getDatakey() {
		return datakey;
	}

	public void setDatakey(String datakey) {
		this.datakey = datakey;
	}

	public String getDataremainingtime() {
		return dataremainingtime;
	}

	public void setDataremainingtime(String dataremainingtime) {
		this.dataremainingtime = dataremainingtime;
	}

	public int getCfOperation() {
		return cfOperation;
	}

	public void setCfOperation(int cfOperation) {
		this.cfOperation = cfOperation;
	}

	public boolean isCfInternalForTheBehaviour() {
		return cfInternalForTheBehaviour;
	}

	public void setCfInternalForTheBehaviour(boolean cfInternalForTheBehaviour) {
		this.cfInternalForTheBehaviour = cfInternalForTheBehaviour;
	}

}
