package jiraPojoObjects;

import java.util.HashMap;

public class PojoIssueStatus {
	///~~ table 'public.issuestatus' 
	///~~ Similar to the class 'PojoWorkflowStep' - it reflects XML object only. 

	//	SELECT id, "sequence", pname, description, iconurl, statuscategory FROM issuestatus
	//	1	1	Open	The issue is open and ready for the assignee to start work on it.	/images/icons/statuses/open.png	2
	//	3	3	In Progress	This issue is being actively worked on at the moment by the assignee.	/images/icons/statuses/inprogress.png	4
	//	4	4	Reopened	This issue was once resolved, but the resolution was deemed incorrect. From here issues are either marked assigned or resolved.	/images/icons/statuses/reopened.png	2
	//	5	5	Resolved	A resolution has been taken, and it is awaiting verification by reporter. From here issues are either reopened, or are closed.	/images/icons/statuses/resolved.png	3
	//	6	6	Closed	The issue is considered finished, the resolution is correct. Issues which are closed can be reopened.	/images/icons/statuses/closed.png	3
	//	10000	7	To Do		/images/icons/status_generic.gif	2
	//	10001	8	Done		/images/icons/status_generic.gif	3
	//	10100	9	wfStatus01		/images/icons/statuses/generic.png	4

	private String id; // 1, 3, 10001,... for: [Open, In Progress, Done,...]
	private Long sequence; // 1, 2,...
	private String pname; //~~ Second level Step's pName: [In Progress, Reopened, Resolved, Closed, Declined, Waiting for support, Waiting for customer, Pending, Canceled, Escalated, Waiting for approval, Work in progress, Done, Open, customStep]
	private String description;
	private String iconurl;
	private Long statuscategory; //~~ First level -- StatusCategory: [2='To Do', 3='Done', 4='In Progress']

	///~~ Extra
	public static HashMap<Long, String> statuscategoryEnum = new HashMap<Long, String>();
	public PojoIssueStatus() {
		statuscategoryEnum.put(2L, "todo"); //~~ [2='To Do', 3='Done', 4='In Progress']
		statuscategoryEnum.put(3L, "done"); //~~ [2='To Do', 3='Done', 4='In Progress']
		statuscategoryEnum.put(4L, "wip"); //~~ [2='To Do', 3='Done', 4='In Progress']
	}

	///~~ Getters / Setters 
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Long getSequence() {
		return sequence;
	}
	public void setSequence(Long sequence) {
		this.sequence = sequence;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getIconurl() {
		return iconurl;
	}
	public void setIconurl(String iconurl) {
		this.iconurl = iconurl;
	}
	public Long getStatuscategory() {
		return statuscategory;
	}
	public void setStatuscategory(Long statuscategory) {
		this.statuscategory = statuscategory;
	}

}
