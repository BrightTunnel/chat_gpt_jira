package jiraPojoObjects;

import java.util.HashMap;

public class PojoFieldScreenTab {

	//	<FieldScreenTab	id="10000"	name="Field	Tab"	sequence="0"	fieldscreen="1"/>
	//	<FieldScreenTab	id="10001"	name="Field	Tab"	sequence="0"	fieldscreen="2"/>
	//	<FieldScreenTab	id="10002"	name="Field	Tab"	sequence="0"	fieldscreen="3"/>
	//	<FieldScreenTab	id="10109"	name="Field	Tab"	sequence="0"	fieldscreen="10009"/>
	//	<FieldScreenTab	id="10110"	name="Field	Tab"	sequence="0"	fieldscreen="10010"/>
	//	<FieldScreenTab	id="10112"	name="Field	Tab"	sequence="0"	fieldscreen="10012"/>

	private Long fieldScreenTabId; // 10100
	private String name; //"Field Tab" or "Default"
	private int sequence; // 0 (the only tab)
	private Long fieldscreen;

	// ~~ Extra ~~
	private HashMap<Long, PojoFieldScreenLayoutItem> fieldScreenLayoutItems;

	// ~~~ Getters/Setters ~~~

	public Long getFieldScreenTabId() {
		return fieldScreenTabId;
	}
	public void setFieldScreenTabId(Long fieldScreenTabId) {
		this.fieldScreenTabId = fieldScreenTabId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSequence() {
		return sequence;
	}
	public void setSequence(int sequence) {
		this.sequence = sequence;
	}
	public Long getFieldscreen() {
		return fieldscreen;
	}
	public void setFieldscreen(Long fieldscreen) {
		this.fieldscreen = fieldscreen;
	}
	public HashMap<Long, PojoFieldScreenLayoutItem> getFieldScreenLayoutItems() {
		return fieldScreenLayoutItems;
	}
	public void setFieldScreenLayoutItems(HashMap<Long, PojoFieldScreenLayoutItem> fieldScreenLayoutItems) {
		this.fieldScreenLayoutItems = fieldScreenLayoutItems;
	}

}
