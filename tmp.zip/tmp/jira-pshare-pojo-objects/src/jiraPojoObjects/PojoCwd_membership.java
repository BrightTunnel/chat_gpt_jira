package jiraPojoObjects;

public class PojoCwd_membership {

	private Long id;
	private String parent_id;
	private String child_id;
	private String membership_type;
	private String group_type;
	private String parent_name;
	private String lower_parent_name;
	private String child_name;
	private String lower_child_name;
	private String directory_id;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getParent_id() {
		return parent_id;
	}

	public void setParent_id(String parent_id) {
		this.parent_id = parent_id;
	}

	public String getChild_id() {
		return child_id;
	}

	public void setChild_id(String child_id) {
		this.child_id = child_id;
	}

	public String getMembership_type() {
		return membership_type;
	}

	public void setMembership_type(String membership_type) {
		this.membership_type = membership_type;
	}

	public String getGroup_type() {
		return group_type;
	}

	public void setGroup_type(String group_type) {
		this.group_type = group_type;
	}

	public String getParent_name() {
		return parent_name;
	}

	public void setParent_name(String parent_name) {
		this.parent_name = parent_name;
	}

	public String getLower_parent_name() {
		return lower_parent_name;
	}

	public void setLower_parent_name(String lower_parent_name) {
		this.lower_parent_name = lower_parent_name;
	}

	public String getChild_name() {
		return child_name;
	}

	public void setChild_name(String child_name) {
		this.child_name = child_name;
	}

	public String getLower_child_name() {
		return lower_child_name;
	}

	public void setLower_child_name(String lower_child_name) {
		this.lower_child_name = lower_child_name;
	}

	public String getDirectory_id() {
		return directory_id;
	}

	public void setDirectory_id(String directory_id) {
		this.directory_id = directory_id;
	}

}
