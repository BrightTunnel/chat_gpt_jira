package jiraPojoObjects;

import java.util.ArrayList;
import java.util.Date;
///import com.atlassian.jira.issue.comments.Comment;

public class PojoComment {
	private String commentHostIssueKey; //--e.g.: "key": "PRKEY-1"
	private Long commentID; //--e.g.: 10400
	private String commentIDString; //--e.g.: "10400"
	private Date commentCreated; //--e.g.: "created": "2027-02-14T19:35:14.421-0500"
	private Date commentUpdated; //--e.g.: "updated": "2027-02-14T19:35:14.421-0500"
	private String commentAuthor; //--e.g.: "author.name": "localadmin", "author.key": "localadmin"
	private String commentAuthorEmail; //--e.g.: "author.emailAddress": "localadmin@gmail.to"
	private String commentText; //--e.g.: "body": "Comment 1"
	private Boolean commentActive; //--e.g.: "active": true
	///~~ Extra
	///private Comment commentObj; //Groovy Jira object 'Comment'
	private Long commentCreatedDaysAgo; //--e.g.: 
	private ArrayList<String> userCalled; //~~ All users mentioned in the comment
	private boolean commentResponded; //--e.g.: 

	/// ~~ Getters/Setters ~~

	public Long getCommentID() {
		return commentID;
	}
	public void setCommentID(Long commentID) {
		this.commentID = commentID;
	}
	public Date getCommentCreated() {
		return commentCreated;
	}
	public void setCommentCreated(Date commentCreated) {
		this.commentCreated = commentCreated;
	}
	public String getCommentAuthor() {
		return commentAuthor;
	}
	public void setCommentAuthor(String commentAuthor) {
		this.commentAuthor = commentAuthor;
	}
	public String getCommentAuthorEmail() {
		return commentAuthorEmail;
	}
	public void setCommentAuthorEmail(String commentAuthorEmail) {
		this.commentAuthorEmail = commentAuthorEmail;
	}
	public String getCommentText() {
		return commentText;
	}
	public void setCommentText(String commentText) {
		this.commentText = commentText;
	}
	public String getCommentHostIssueKey() {
		return commentHostIssueKey;
	}
	public void setCommentHostIssueKey(String commentHostIssueKey) {
		this.commentHostIssueKey = commentHostIssueKey;
	}
	///	public Comment getCommentObj() {
	///		return commentObj;
	///	}
	///	public void setCommentObj(Comment commentObj) {
	///		this.commentObj = commentObj;
	///	}
	public Long getCommentCreatedDaysAgo() {
		return commentCreatedDaysAgo;
	}
	public void setCommentCreatedDaysAgo(Long commentCreatedDaysAgo) {
		this.commentCreatedDaysAgo = commentCreatedDaysAgo;
	}
	public ArrayList<String> getUserCalled() {
		return userCalled;
	}
	public void setUserCalled(ArrayList<String> userCalled) {
		this.userCalled = userCalled;
	}
	public boolean isCommentResponded() {
		return commentResponded;
	}
	public void setCommentResponded(boolean commentResponded) {
		this.commentResponded = commentResponded;
	}
	public String getCommentIDString() {
		return commentIDString;
	}
	public void setCommentIDString(String commentIDString) {
		this.commentIDString = commentIDString;
	}
	public Date getCommentUpdated() {
		return commentUpdated;
	}
	public void setCommentUpdated(Date commentUpdated) {
		this.commentUpdated = commentUpdated;
	}
	public Boolean getCommentActive() {
		return commentActive;
	}
	public void setCommentActive(Boolean commentActive) {
		this.commentActive = commentActive;
	}

}
