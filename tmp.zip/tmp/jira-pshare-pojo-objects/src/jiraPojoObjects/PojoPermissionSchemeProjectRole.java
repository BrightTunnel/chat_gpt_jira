package jiraPojoObjects;

public class PojoPermissionSchemeProjectRole {
	//--Jira Cloud--:
	//"permissions": [{
	//	"id": 10769,
	//	"self": "https://brighttunnel.atlassian.net/rest/api/2/permissionscheme/10003/permission/10769",
	//	"holder": {
	//		"type": "projectRole",
	//		"parameter": "10010",
	//		"value": "10010",
	//		"projectRole": {
	//			"self": "https://brighttunnel.atlassian.net/rest/api/2/role/10010",
	//			"name": "Viewer",
	//			"id": 10010,
	//			"description": "Viewers can search through, view, and comment on your team's work, but not much else.",
	//			"scope": {
	//				"type": "PROJECT",
	//				"project": {
	//					"id": "10003"
	//				}
	//			}
	//		},
	//		"expand": "projectRole"
	//	},
	//	"permission": "BROWSE_PROJECTS"	
	//},.. 

	private String self; //--e.g.: "https://brighttunnel.atlassian.net/rest/api/2/role/10010",
	private String name; //--e.g.: ["Viewer",...]
	private Long id; //--e.g.: [10010,...]
	private String description; //--e.g.: "Viewers can search through, view, and comment on your team's work, but not much else.",
	//private String scope; //--e.g.: {
	private String scopeType; //--e.g.: "scope": {"type": "PROJECT",
	//private String scopeProject; //--e.g.: {
	private String scopeProjectId; //--e.g.: "scope": {"type": "PROJECT", "project": {"id": "10003"}

	public String getSelf() {
		return self;
	}
	public void setSelf(String self) {
		this.self = self;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getScopeType() {
		return scopeType;
	}
	public void setScopeType(String scopeType) {
		this.scopeType = scopeType;
	}
	public String getScopeProjectId() {
		return scopeProjectId;
	}
	public void setScopeProjectId(String scopeProjectId) {
		this.scopeProjectId = scopeProjectId;
	}

}
