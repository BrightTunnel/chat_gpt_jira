package jiraPojoObjects;

import java.util.HashMap;
import java.util.LinkedHashMap;

public class PojoWorkflow {
	///~~ db table 'jiraworkflows': [id,workflowname,creatorname,"descriptor",islocked]
	private Long id; // 10200
	private String workflowname; // 'classic default workflow'
	private String creatorname;
	private String descriptor; // <?xml...>
	private String islocked;

	///~~ db table 'os_wfentry' [id,name,initialized,state]
	private Long id_os_wfentry;
	private String name; ///'JSMB: Service Request Fulfilment workflow for Jira Service Management', ...
	private Long initialized; ///[NULL]
	private Long state; ///[1,1,2,...]

	///~~~ xml export/backup <workflow>
	///~~ XML Second Level after root <workflow>
	private String metaJiraDescription; //<meta name="jira.description">Copy from ITSD</meta>
	private String metaJirai18nDescription; //<meta name="jira.i18n.description"/>
	private String metaJiraUpdateAuthorKey; //<meta name="jira.update.author.key">JIRAUSER14642</meta>
	private String metaJiraUpdatedDate; //<meta name="jira.updated.date">1694617040950</meta>
	private String metaSdWorkflowKey; //<meta name="sd.workflow.key">sdItSupport</meta>

	//	private String wfTopSegment; //~~WF Top level XML segments: [meta, initial-actions, global-actions, common-actions, steps] DELETE
	private LinkedHashMap<String, LinkedHashMap<String, PojoWorkflowStep>> wfTopXmlSegments; //~~WF Top level XML segments keys: [meta, initial-actions, global-actions, common-actions, steps]
	///~~ 1. Segment Key, one of the Strings: [meta, initial-actions, global-actions, common-actions, steps]
	///~~ 2. Step Key: 'AVP Approval Pending' from: <step id="32" name="AVP Approval Pending">

	///~~~Calculated/Extracted form XML WF object  
	private boolean isGroovyScript;
	private boolean isJiraAutomation;
	private boolean isJSUAutomation;

	///~~~ Extra from linked dbase foreign tables ~~~
	private Long frgnWorkflowSchemeID;
	private Long frgnProjectID;
	private String frgnProjectName;
	private HashMap<String, PojoIssueType> frgnIssueTypes; // WF may have one or more IssueTypes  

	///~~ Historical data from 'changeitem'+'changegroup'
	private String chngitemOldvalue; // 'IssueStatus.id': '10000'
	private String chngitemOldstring; // 'IssueStatus.pname': 'To Do' 
	private String chngitemNewvalue; // 'IssueStatus.id': '3'
	private String chngitemNewstring; // 'IssueStatus.pname': 'In Progress'
	private Long chngitemCount; //~~ Count a number of occurencies of that transition from OLD to NEW per 'WF' && 'issueType'   

	///~~ Table 'issuestatus'
	// id	sequence	pname	statuscategory
	//	1	1	Open
	//	3	3	In Progress
	//	4	4	Reopened
	//	5	5	Resolved
	//	6	6	Closed
	//	10000	7	To Do
	//	10001	8	Done
	//	10100	9	wfStatus01

	//@Override
	//public String toString() {
	//  String _str = "'" + workflowname + "'";
	//  if (field_notes != null) {_str += "\r\n\t\t\'" + field_notes + "'";}
	//  if (field_script_file_or_script != null) {_str += ", '" + field_script_file_or_script + "'";}
	//  return _str;
	//}

	//~~~ Getters/Setters ~~~

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getWorkflowname() {
		return workflowname;
	}

	public void setWorkflowname(String workflowname) {
		this.workflowname = workflowname;
	}

	public String getCreatorname() {
		return creatorname;
	}

	public void setCreatorname(String creatorname) {
		this.creatorname = creatorname;
	}

	public String getDescriptor() {
		return descriptor;
	}

	public void setDescriptor(String descriptor) {
		this.descriptor = descriptor;
	}

	public String getIslocked() {
		return islocked;
	}

	public void setIslocked(String islocked) {
		this.islocked = islocked;
	}

	public Long getId_os_wfentry() {
		return id_os_wfentry;
	}

	public void setId_os_wfentry(Long id_os_wfentry) {
		this.id_os_wfentry = id_os_wfentry;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getInitialized() {
		return initialized;
	}

	public void setInitialized(Long initialized) {
		this.initialized = initialized;
	}

	public Long getState() {
		return state;
	}

	public void setState(Long state) {
		this.state = state;
	}

	public String getMetaJiraDescription() {
		return metaJiraDescription;
	}

	public void setMetaJiraDescription(String metaJiraDescription) {
		this.metaJiraDescription = metaJiraDescription;
	}

	public String getMetaJirai18nDescription() {
		return metaJirai18nDescription;
	}

	public void setMetaJirai18nDescription(String metaJirai18nDescription) {
		this.metaJirai18nDescription = metaJirai18nDescription;
	}

	public String getMetaJiraUpdateAuthorKey() {
		return metaJiraUpdateAuthorKey;
	}

	public void setMetaJiraUpdateAuthorKey(String metaJiraUpdateAuthorKey) {
		this.metaJiraUpdateAuthorKey = metaJiraUpdateAuthorKey;
	}

	public String getMetaJiraUpdatedDate() {
		return metaJiraUpdatedDate;
	}

	public void setMetaJiraUpdatedDate(String metaJiraUpdatedDate) {
		this.metaJiraUpdatedDate = metaJiraUpdatedDate;
	}

	public String getMetaSdWorkflowKey() {
		return metaSdWorkflowKey;
	}

	public void setMetaSdWorkflowKey(String metaSdWorkflowKey) {
		this.metaSdWorkflowKey = metaSdWorkflowKey;
	}

	public boolean isGroovyScript() {
		return isGroovyScript;
	}

	public void setGroovyScript(boolean isGroovyScript) {
		this.isGroovyScript = isGroovyScript;
	}

	public boolean isJiraAutomation() {
		return isJiraAutomation;
	}

	public void setJiraAutomation(boolean isJiraAutomation) {
		this.isJiraAutomation = isJiraAutomation;
	}

	public boolean isJSUAutomation() {
		return isJSUAutomation;
	}

	public void setJSUAutomation(boolean isJSUAutomation) {
		this.isJSUAutomation = isJSUAutomation;
	}

	public Long getFrgnWorkflowSchemeID() {
		return frgnWorkflowSchemeID;
	}

	public void setFrgnWorkflowSchemeID(Long frgnWorkflowSchemeID) {
		this.frgnWorkflowSchemeID = frgnWorkflowSchemeID;
	}

	public Long getFrgnProjectID() {
		return frgnProjectID;
	}

	public void setFrgnProjectID(Long frgnProjectID) {
		this.frgnProjectID = frgnProjectID;
	}

	public String getFrgnProjectName() {
		return frgnProjectName;
	}

	public void setFrgnProjectName(String frgnProjectName) {
		this.frgnProjectName = frgnProjectName;
	}

	public HashMap<String, PojoIssueType> getFrgnIssueTypes() {
		return frgnIssueTypes;
	}

	public void setFrgnIssueTypes(HashMap<String, PojoIssueType> frgnIssueTypes) {
		this.frgnIssueTypes = frgnIssueTypes;
	}

	public String getChngitemOldstring() {
		return chngitemOldstring;
	}

	public void setChngitemOldstring(String chngitemOldstring) {
		this.chngitemOldstring = chngitemOldstring;
	}

	public String getChngitemNewstring() {
		return chngitemNewstring;
	}

	public void setChngitemNewstring(String chngitemNewstring) {
		this.chngitemNewstring = chngitemNewstring;
	}

	public String getChngitemOldvalue() {
		return chngitemOldvalue;
	}

	public void setChngitemOldvalue(String chngitemOldvalue) {
		this.chngitemOldvalue = chngitemOldvalue;
	}

	public String getChngitemNewvalue() {
		return chngitemNewvalue;
	}

	public void setChngitemNewvalue(String chngitemNewvalue) {
		this.chngitemNewvalue = chngitemNewvalue;
	}

	public Long getChngitemCount() {
		return chngitemCount;
	}

	public void setChngitemCount(Long chngitemCount) {
		this.chngitemCount = chngitemCount;
	}

	public LinkedHashMap<String, LinkedHashMap<String, PojoWorkflowStep>> getWfTopXmlSegments() {
		return wfTopXmlSegments;
	}

	public void setWfTopXmlSegments(LinkedHashMap<String, LinkedHashMap<String, PojoWorkflowStep>> wfTopXmlSegments) {
		this.wfTopXmlSegments = wfTopXmlSegments;
	}

}