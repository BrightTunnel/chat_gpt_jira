package jiraPojoObjects;

public class PojoSearchRequest {

	//    <SearchRequest id="10000" name="Open and unassigned (BSS)" author="JIRAUSER10000" user="JIRAUSER10000" request="project = 10100 and statusCategory != Done and assignee = EMPTY ORDER BY priority desc" favCount="0" nameLower="open and unassigned (bss)"/>
	//    <SearchRequest id="10001" name="Due this week (BSS)" author="JIRAUSER10000" user="JIRAUSER10000" request="project = 10100 and duedate &gt;= startOfWeek() and duedate &lt;= endOfWeek() ORDER BY priority desc" favCount="0" nameLower="due this week (bss)"/>
	//    <SearchRequest id="10002" name="Overdue (BSS)" author="JIRAUSER10000" user="JIRAUSER10000" request="project = 10100 and statusCategory != Done and duedate &lt; now() ORDER BY duedate desc" favCount="0" nameLower="overdue (bss)"/>
	//    <SearchRequest id="10100" name="Highest priority and open (TM)" author="JIRAUSER10000" user="JIRAUSER10000" request="project = 10200 and statusCategory != Done and priority = 1 ORDER BY duedate desc, priority desc" favCount="0" nameLower="highest priority and open (tm)"/>
	//    <SearchRequest id="10101" name="Due this week (TM)" author="JIRAUSER10000" user="JIRAUSER10000" request="project = 10200 and duedate &gt;= startOfWeek() and duedate &lt;= endOfWeek() ORDER BY priority desc" favCount="0" nameLower="due this week (tm)"/>
	//    <SearchRequest id="10102" name="Open and unassigned (PM)" author="JIRAUSER10000" user="JIRAUSER10000" request="project = 10201 and statusCategory != Done and assignee = EMPTY ORDER BY priority desc" favCount="0" nameLower="open and unassigned (pm)"/>
	//    <SearchRequest id="10103" name="Due this week (PM)" author="JIRAUSER10000" user="JIRAUSER10000" request="project = 10201 and duedate &gt;= startOfWeek() and duedate &lt;= endOfWeek() ORDER BY priority desc" favCount="0" nameLower="due this week (pm)"/>
	//    <SearchRequest id="10104" name="Overdue (PM)" author="JIRAUSER10000" user="JIRAUSER10000" request="project = 10201 and statusCategory != Done and duedate &lt; now() ORDER BY duedate desc" favCount="0" nameLower="overdue (pm)"/>
	//    <SearchRequest id="10105" name="Ready for review (PCM)" author="JIRAUSER10000" user="JIRAUSER10000" request="project = 10202 and status = &quot;Under Review&quot; ORDER BY priority desc" favCount="0" nameLower="ready for review (pcm)"/>
	//    <SearchRequest id="10106" name="Approved (PCM)" author="JIRAUSER10000" user="JIRAUSER10000" request="project = 10202 and status = &quot;Approved&quot; ORDER BY updated desc" favCount="0" nameLower="approved (pcm)"/>
	//    <SearchRequest id="10107" name="Rejected (PCM)" author="JIRAUSER10000" user="JIRAUSER10000" request="project = 10202 and status = &quot;Rejected&quot; ORDER BY updated desc" favCount="0" nameLower="rejected (pcm)"/>

	private Long id; //ex:'searchRequestIdLong'
	private String filtername; // ex:'searchRequestName'
	private String authorname;
	private String description;
	private String username;
	private String groupname;
	private Long projectid;
	private String reqcontent; // ex:'searchRequestReqcontent'
	private Long fav_count;
	private String filtername_lower;

	// ~~ Extra ~~
	private String searchRequestFullXmlString;
	private Long convertJiraIdToLong(String anIDAsString) {
		Long _lng = null;
		if (anIDAsString != null && anIDAsString.length() >= "10128".length()) {
			try {
				_lng = Long.parseLong(anIDAsString);
			} catch (NumberFormatException e) {
			}
		}
		return _lng;
	}

	public void setSearchRequestIdLong(String searchRequestIdLong) {
		Long _lng = convertJiraIdToLong(searchRequestIdLong);
		this.id = _lng;
	}

	// ~~ Getters/Setters ~~
	public Long getId() {
		return id;
	}
	public String getFiltername() {
		return filtername;
	}
	public void setFiltername(String searchRequestName) {
		this.filtername = searchRequestName;
	}
	public String getAuthorname() {
		return authorname;
	}
	public void setAuthorname(String searchRequestAuthor) {
		this.authorname = searchRequestAuthor;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String searchRequestUser) {
		this.username = searchRequestUser;
	}
	public Long getFav_count() {
		return fav_count;
	}
	public void setFav_count(Long searchRequestFavCount) {
		this.fav_count = searchRequestFavCount;
	}
	public String getFiltername_lower() {
		return filtername_lower;
	}
	public void setFiltername_lower(String searchRequestNameLower) {
		this.filtername_lower = searchRequestNameLower;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String searchRequestDescription) {
		this.description = searchRequestDescription;
	}
	public String getGroupname() {
		return groupname;
	}
	public void setGroupname(String searchRequestGroupName) {
		this.groupname = searchRequestGroupName;
	}
	public Long getProjectid() {
		return projectid;
	}
	public void setProjectid(Long searchRequestProject) {
		this.projectid = searchRequestProject;
	}
	public String getReqcontent() {
		return reqcontent;
	}
	public void setReqcontent(String searchRequestReqcontent) {
		this.reqcontent = searchRequestReqcontent;
	}
	public void setId(Long searchRequestIdLong) {
		this.id = searchRequestIdLong;
	}
	public String getSearchRequestFullXmlString() {
		return searchRequestFullXmlString;
	}
	public void setSearchRequestFullXmlString(String searchRequestFullXmlString) {
		this.searchRequestFullXmlString = searchRequestFullXmlString;
	}
}
