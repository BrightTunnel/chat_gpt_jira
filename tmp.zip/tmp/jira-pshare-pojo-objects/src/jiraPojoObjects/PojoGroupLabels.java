package jiraPojoObjects;

public class PojoGroupLabels {

	//"header": "Showing 16 of 16 matching groups",
	//"total": 16,
	//"groups": [{
	//		"name": "atlassian-addons-admin",
	//		"html": "atlassian-addons-admin",
	//		"labels": [{
	//				"text": "Admin",
	//				"title": "Users added to this group will be given administrative access",
	//				"type": "ADMIN"
	//			}, {
	//				"text": "Multi-App-Access",
	//				"title": "Users added to this group will be given access to <strong>Jira Service Desk</strong>, <strong>Jira Software</strong> and <strong>Jira Core</strong>",
	//				"type": "MULTIPLE"
	//			}
	//		],

	private String text; //--e.g.: ["Admin",]
	private String title; //--e.g.: ["Users added to this group will be given administrative access",]
	private String type; //--e.g.: ["ADMIN"]
	
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}

}
