package jiraPojoObjects;

public class PojoIssueType {
	/// db table 'issueType': [id,"sequence",pname,pstyle,description,iconurl,avatar]
	private String id; // "10128"
	private Long sequence; // 1, 2,...
	private String pname; // issueTypeName: [Task, Sub-task, CustomIssueType01,...]
	private String pstyle;
	private String description;
	private String iconurl;
	private Long avatar;

	///~~Extra Attributes
	private String issueTypeFullXmlString;

	// ~~~ Getters/Setters ~~~
	public String getPname() {
		return pname;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPstyle() {
		return pstyle;
	}
	public void setPstyle(String pstyle) {
		this.pstyle = pstyle;
	}
	public Long getAvatar() {
		return avatar;
	}
	public void setAvatar(Long avatar) {
		this.avatar = avatar;
	}
	public String getIssueTypeFullXmlString() {
		return issueTypeFullXmlString;
	}
	public void setIssueTypeFullXmlString(String issueTypeFullXmlString) {
		this.issueTypeFullXmlString = issueTypeFullXmlString;
	}
	public Long getSequence() {
		return sequence;
	}
	public void setSequence(Long sequence) {
		this.sequence = sequence;
	}
	public String getIconurl() {
		return iconurl;
	}
	public void setIconurl(String iconurl) {
		this.iconurl = iconurl;
	}

}
