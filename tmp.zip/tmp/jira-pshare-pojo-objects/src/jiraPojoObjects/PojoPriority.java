package jiraPojoObjects;

public class PojoPriority {
	/// db table 'priority': [id,"sequence",pname,description,iconurl,status_color]
	private String id; // 10128
	private Long sequence; // 1, 2,...
	private String pname; //
	private String description;
	private String iconurl;
	private String status_color;

	//~~Setters 
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Long getSequence() {
		return sequence;
	}
	public void setSequence(Long sequence) {
		this.sequence = sequence;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getIconurl() {
		return iconurl;
	}
	public void setIconurl(String iconurl) {
		this.iconurl = iconurl;
	}
	public String getStatus_color() {
		return status_color;
	}
	public void setStatus_color(String status_color) {
		this.status_color = status_color;
	}

}
