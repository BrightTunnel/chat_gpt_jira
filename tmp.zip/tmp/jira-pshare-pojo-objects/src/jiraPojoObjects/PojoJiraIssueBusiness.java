package jiraPojoObjects;

import java.util.LinkedHashSet;
import java.util.TreeSet;

public class PojoJiraIssueBusiness {
	/// private String key; // ~~ 'PRKEY-123'
	private LinkedHashSet<String> metaDataOrigSummary; // --Extra to keep business Meta Data Keys
	private LinkedHashSet<String> metaDataMoldedSummary; // --Extra to keep Rectified and Ordered business Meta Data Keys
	private LinkedHashSet<String> metaDataMoldedMappedComponents; // --Extra to keep Rectified and Ordered business Meta Data Keys
	private LinkedHashSet<String> scenarios; // --Extra to keep Exact and Probable WI Scenarios
	private String notesAndBusinessErrors; // --Not Part of Any Jira DC or Cloud, Just a place to keep developer's notes, and collect business and syntax/semantic errors errors, discovered during parsing, etc
	private TreeSet<String> businessErrorCategory; // --Attempt to categorize the business Errors (extracted from 'notesAndBusinessErrors')
	///--CustomFields dedicated to the Business logic (Additionally to the  Labels, Components, FixVersions, etc.)
	private String epicOwner; // --Not Part of Any Jira DC or Cloud, Client-specific cf
	private String team; // --Not Part of Any Jira DC or Cloud, Client-specific cf
	private String teamName; // --Not Part of Any Jira DC or Cloud, Client-specific cf

	///--Getters and Setters

	public LinkedHashSet<String> getMetaDataOrigSummary() {
		return metaDataOrigSummary;
	}

	public void setMetaDataOrigSummary(LinkedHashSet<String> metaDataOrigSummary) {
		this.metaDataOrigSummary = metaDataOrigSummary;
	}

	public LinkedHashSet<String> getMetaDataMoldedSummary() {
		return metaDataMoldedSummary;
	}

	public void setMetaDataMoldedSummary(LinkedHashSet<String> metaDataMoldedSummary) {
		this.metaDataMoldedSummary = metaDataMoldedSummary;
	}

	public LinkedHashSet<String> getMetaDataMoldedMappedComponents() {
		return metaDataMoldedMappedComponents;
	}

	public void setMetaDataMoldedMappedComponents(LinkedHashSet<String> metaDataMoldedMappedComponents) {
		this.metaDataMoldedMappedComponents = metaDataMoldedMappedComponents;
	}

	public LinkedHashSet<String> getScenarios() {
		return scenarios;
	}

	public void setScenarios(LinkedHashSet<String> scenarios) {
		this.scenarios = scenarios;
	}

	public String getNotesAndBusinessErrors() {
		return notesAndBusinessErrors;
	}

	public void setNotesAndBusinessErrors(String notesAndBusinessErrors) {
		this.notesAndBusinessErrors = notesAndBusinessErrors;
	}

	public String getEpicOwner() {
		return epicOwner;
	}

	public void setEpicOwner(String epicOwner) {
		this.epicOwner = epicOwner;
	}

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	public TreeSet<String> getBusinessErrorCategory() {
		if (businessErrorCategory == null) {
			return new TreeSet<String>();
		} else {
			return businessErrorCategory;
		}
	}

	public void setBusinessErrorCategory(TreeSet<String> businessErrorCategory) {

		this.businessErrorCategory = businessErrorCategory;
	}

}
