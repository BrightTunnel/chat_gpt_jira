package jiraPojoObjects;

public class PojoApplicationRole {
	//--JiraCloud
	// "from": "https://brighttunnel.atlassian.net/rest/api/3/user?accountId=5a90f92154c8ff39bc24672d&expand=groups,applicationRoles",
	//"applicationRoles": {
	//	"size": 2,
	//	"items": [{
	//			"key": "jira-product-discovery",
	//			"name": "Jira Product Discovery"
	//		}, {
	//			"key": "jira-software",
	//			"name": "Jira Software"
	//		}
	//	]
	//},

	private String key; //--e.g.: "key": "jira-product-discovery",
	private String name;//	--e.g.: "name": "Jira Product Discovery"

	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

}
