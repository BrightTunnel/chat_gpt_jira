package jiraPojoObjects;

public class PojoCustomFieldOption {
	///~~ <CustomFieldOption id="10012" customfield="10106" customfieldconfig="10308" sequence="1" value="Upgrade" disabled="N"/>	
	private Long id; //~~ Option ID
	private Long customfield; // ~~ Parent CF ID
	private Long customfieldconfig; // ~~ Rarely used
	private Long parentoptionid;
	private Long sequence; // Rank
	private String customvalue; // Option value (option label, name) e.g. 'Red'
	private String optiontype;
	private String disabled;
	//~~Extra~~
	private String customfieldName; //~~ get from another table for information

	// ~~~ Getters/Setters ~~~
	public Long getId() {
		return id;
	}
	public void setId(Long customFieldOptionId) {
		this.id = customFieldOptionId;
	}
	public Long getCustomfieldconfig() {
		return customfieldconfig;
	}
	public void setCustomfieldconfig(Long customfieldconfig) {
		this.customfieldconfig = customfieldconfig;
	}
	public Long getSequence() {
		return sequence;
	}
	public void setSequence(Long optionSequence) {
		this.sequence = optionSequence;
	}
	public String getCustomvalue() {
		return customvalue;
	}
	public void setCustomvalue(String optionValue) {
		this.customvalue = optionValue;
	}
	public String getDisabled() {
		return disabled;
	}
	public void setDisabled(String disabled) {
		this.disabled = disabled;
	}
	public Long getCustomfield() {
		return customfield;
	}
	public void setCustomfield(Long customfieldId) {
		this.customfield = customfieldId;
	}
	public Long getParentoptionid() {
		return parentoptionid;
	}
	public void setParentoptionid(Long parentoptionid) {
		this.parentoptionid = parentoptionid;
	}
	public String getOptiontype() {
		return optiontype;
	}
	public void setOptiontype(String optiontype) {
		this.optiontype = optiontype;
	}
	public String getCustomfieldName() {
		return customfieldName;
	}
	public void setCustomfieldName(String customfieldName) {
		this.customfieldName = customfieldName;
	}
	@Override
	public String toString() {
		return "PojoCustomFieldOption [id=" + id + ", customfield=" + customfield + ", customfieldconfig=" + customfieldconfig + ", sequence=" + sequence + ", customvalue=" + customvalue + ", disabled=" + disabled + "]";
	}

}
