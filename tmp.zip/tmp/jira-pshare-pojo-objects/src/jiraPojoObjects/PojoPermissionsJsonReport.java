package jiraPojoObjects;
import org.json.simple.JSONObject;

public class PojoPermissionsJsonReport {
	private String accountId; //--User ID, Group ID
	private String group; //--Parent Group Name or ID
	private String permissionScope;
	private String permissionId;
	private String permissionName;
	private String permissionDescription;
	private String permissionCategory;
	private String permissionScheme;
	private String projectRole;
	private String projectId;
	private String projectName;
	private String projectDescription;

	// Constructor, getters, and setters
	public PojoPermissionsJsonReport(String accountId, String group, String permissionScope, String permissionId, String permissionName, String permissionDescription, String permissionCategory, String permissionScheme, String projectRole, String projectId, String projectName, String projectDescription) {
		this.accountId = accountId;
		this.group = group;
		this.permissionScope = permissionScope;
		this.permissionId = permissionId;
		this.permissionName = permissionName;
		this.permissionDescription = permissionDescription;
		this.permissionCategory = permissionCategory;
		this.permissionScheme = permissionScheme;
		this.projectRole = projectRole;
		this.projectId = projectId;
		this.projectName = projectName;
		this.projectDescription = projectDescription;
	}

	// Method to convert PojoPermissionsJsonReport to JSONObject
	public JSONObject toJson() {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("accountId", this.accountId);
		jsonObject.put("group", this.group);
		jsonObject.put("permissionScope", this.permissionScope);
		jsonObject.put("permissionId", this.permissionId);
		jsonObject.put("permissionName", this.permissionName);
		jsonObject.put("permissionDescription", this.permissionDescription);
		jsonObject.put("permissionCategory", this.permissionCategory);
		jsonObject.put("permissionScheme", this.permissionScheme);
		jsonObject.put("projectRole", this.projectRole);
		jsonObject.put("projectId", this.projectId);
		jsonObject.put("projectName", this.projectName);
		jsonObject.put("projectDescription", this.projectDescription);
		return jsonObject;
	}

	public static void main(String[] args) {
		// Create a PojoPermissionsJsonReport instance
		PojoPermissionsJsonReport report = new PojoPermissionsJsonReport("12345", "Admin Group", "Read-Write", "P001", "Read Access", "Allows read access to project", "Security", "Scheme A", "Admin", "PRJ001", "Project X", "This is a description of Project X");

		// Convert the report to JSON
		JSONObject jsonReport = report.toJson();

		// Print the JSON object
		System.out.println(jsonReport.toJSONString());
	}

	// Getters and Setters
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}

	public String getPermissionScope() {
		return permissionScope;
	}
	public void setPermissionScope(String permissionScope) {
		this.permissionScope = permissionScope;
	}

	public String getPermissionId() {
		return permissionId;
	}
	public void setPermissionId(String permissionId) {
		this.permissionId = permissionId;
	}

	public String getPermissionName() {
		return permissionName;
	}
	public void setPermissionName(String permissionName) {
		this.permissionName = permissionName;
	}

	public String getPermissionDescription() {
		return permissionDescription;
	}
	public void setPermissionDescription(String permissionDescription) {
		this.permissionDescription = permissionDescription;
	}

	public String getPermissionCategory() {
		return permissionCategory;
	}
	public void setPermissionCategory(String permissionCategory) {
		this.permissionCategory = permissionCategory;
	}

	public String getPermissionScheme() {
		return permissionScheme;
	}
	public void setPermissionScheme(String permissionScheme) {
		this.permissionScheme = permissionScheme;
	}

	public String getProjectRole() {
		return projectRole;
	}
	public void setProjectRole(String projectRole) {
		this.projectRole = projectRole;
	}

	public String getProjectId() {
		return projectId;
	}
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getProjectDescription() {
		return projectDescription;
	}
	public void setProjectDescription(String projectDescription) {
		this.projectDescription = projectDescription;
	}
}
