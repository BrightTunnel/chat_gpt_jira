package jiraPojoObjects;

import java.util.HashMap;

public class PojoFieldScreen {

	// <FieldScreen id="1" name="Default Screen" 				description="Allows to update all system fields."/>
	// <FieldScreen id="2" name="Workflow Screen" 			description="This screen is used in the workflow and enables you to assign issues"/>
	// <FieldScreen id="3" name="Resolve Issue Screen" 	description="Allows to set resolution, change fix versions and assign an issue."/>
	// <FieldScreen id="10009" name="Jira Service Management Resolve Issue Screen" 	description="Allows to set resolution and linked issues"/>

	private Long fieldScreenId; // 10100
	private String name; // "Default Screen", "Workflow Screen", ... 
	private int description;

	// ~~ Extra ~~
	private HashMap<Long, PojoFieldScreenTab> fieldScreenTabs;

	// ~~~ Getters/Setters ~~~

	public Long getFieldScreenId() {
		return fieldScreenId;
	}
	public void setFieldScreenId(Long fieldScreenId) {
		this.fieldScreenId = fieldScreenId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getDescription() {
		return description;
	}
	public void setDescription(int description) {
		this.description = description;
	}
	public HashMap<Long, PojoFieldScreenTab> getFieldScreenTabs() {
		return fieldScreenTabs;
	}
	public void setFieldScreenTabs(HashMap<Long, PojoFieldScreenTab> fieldScreenTabs) {
		this.fieldScreenTabs = fieldScreenTabs;
	}

}
