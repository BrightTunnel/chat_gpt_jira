package jiraPojoObjects;

import java.util.LinkedHashMap;

public class PojoFilter {
	///-- Jira DC Filter
	private String self; //"self": "http://localhost:8080/rest/api/2/filter/10000",
	private String id; //"id": "10000",
	private String name; // 'filtername' "name": "filter-name"
	///private String UNUSED_filtername_lower; // 'filtername_lower'
	private String ownerKey; //"owner": {"key": "localadmin",
	private String ownerName; // 'authorname' "name": "localadmin",
	private String ownerDisplayName; //"displayName": "localadmin",
	private Boolean ownerActive; //"active": true
	private String description; // 'description'
	private Long projectid; // 'projectid': [NULL], 10100
	private String jql; // 'reqcontent', "jql": "project = 10000 and statusCategory != Done and assignee=    EMPTY ORDER BY priority desc",
	private String jqlFixed; //--Extra field: fixed JQL (unwound nested JQL calls): "project = 10000 and statusCategory != Done and assignee = EMPTY ORDER BY priority desc", jqlFixed
	///private Date auditingFiltersUpdated; //--Extra field, from: "http://localhost:8080/rest/api/2/auditing/record?filter=filters" file 'dc-auditing-filters.json'
	private String viewUrl; //"viewUrl": "http://localhost:8080/issues/?filter=10000",
	private String searchUrl; //"searchUrl": "http://localhost:8080/rest/api/2/search?jql=project+%3D+10000+and+statusCategory+!%3D+Done+and+assignee+%3D+EMPTY+ORDER+BY+priority+desc",
	private Boolean favourite; //"favourite": false,
	///private Long UNUSED_fav_count; // 'fav_count': 1
	///private String UNUSED_sharePermissions; //"sharePermissions": [{
	private Boolean editable; // "editable": true,
	///private String UNUSED_sharedUsers; //"sharedUsers": {"size": 0,"items": [],"max-results": 1000,"start-index": 0,"end-index": 0},
	///private String UNUSED_subscriptions; //"subscriptions": {"size": 0,"items": [],"max-results": 1000,"start-index": 0,"end-index": 0}

///-- Jira DC DataBase: select * from searchrequest;
///--Header: 	id, filtername, authorname, description, username, groupname, projectid, reqcontent, fav_count, filtername_lower
///--Data: 10,003, fltr-10003, admin, [NULL], admin, [NULL], [NULL], assignee=admin, 1, fltr-10003

	
///	{"self": "http://localhost:8080/rest/api/2/filter/10000",
///	"id": "10000",
///	"name": "Open and unassigned (PM)",
///	"owner": {
///	    "key": "localadmin",
///	    "name": "localadmin",
///	    "avatarUrls": {},
///	    "displayName": "localadmin",
///	    "active": true
///	},
///	"jql": "project = 10000 and statusCategory != Done and assignee = EMPTY ORDER BY priority desc",
///	"viewUrl": "http://localhost:8080/issues/?filter=10000",
///	"searchUrl": "http://localhost:8080/rest/api/2/search?jql=project+%3D+10000+and+statusCategory+!%3D+Done+and+assignee+%3D+EMPTY+ORDER+BY+priority+desc",
///	"favourite": false,
///	"sharePermissions": [{"id": 10100, "type": "project", "project": {
///	            "self": "http://localhost:8080/rest/api/2/project/10000",
///	            "id": "10000", "key": "PM","assigneeType": "PROJECT_LEAD","name": "PM","roles": {},"avatarUrls": {},"projectTypeKey": "business"},
///	        "view": true, "edit": false
///	    }
///	],
///	"editable": true,
///	"sharedUsers": {"size": 0, "items": [], "max-results": 1000, "start-index": 0, "end-index": 0},
///	"subscriptions": {"size": 0,"items": [],"max-results": 1000,"start-index": 0,"end-index": 0}
///	}

	///#-- EXTRA FIELDS
	///-- Nested filter in Jira JQL represented by: ['0': 'filter index like 10000'; '1': 'filter name']
	private Integer jqlNestedFilterReferenceType;
	///-- Just a SymLink, has Filter ID and possibly Filter Name, no other values -- List of nested parental filters referenced in this filter.
	private LinkedHashMap<String, PojoFilter> nestedFilters;

	/// ~~~ Getters/Setters ~~~
	public String getSelf() {
		return self;
	}
	public void setSelf(String self) {
		this.self = self;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOwnerKey() {
		return ownerKey;
	}
	public void setOwnerKey(String ownerKey) {
		this.ownerKey = ownerKey;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public String getOwnerDisplayName() {
		return ownerDisplayName;
	}
	public void setOwnerDisplayName(String ownerDisplayName) {
		this.ownerDisplayName = ownerDisplayName;
	}
	public Boolean getOwnerActive() {
		return ownerActive;
	}
	public void setOwnerActive(Boolean ownerActive) {
		this.ownerActive = ownerActive;
	}
	public String getJql() {
		return jql;
	}
	public void setJql(String jql) {
		this.jql = jql;
	}
	public String getViewUrl() {
		return viewUrl;
	}
	public void setViewUrl(String viewUrl) {
		this.viewUrl = viewUrl;
	}
	public String getSearchUrl() {
		return searchUrl;
	}
	public void setSearchUrl(String searchUrl) {
		this.searchUrl = searchUrl;
	}
	public Boolean getFavourite() {
		return favourite;
	}
	public void setFavourite(Boolean favourite) {
		this.favourite = favourite;
	}
	public Boolean getEditable() {
		return editable;
	}
	public void setEditable(Boolean editable) {
		this.editable = editable;
	}
	public LinkedHashMap<String, PojoFilter> getNestedFilters() {
		return nestedFilters;
	}
	public void setNestedFilters(LinkedHashMap<String, PojoFilter> parentIDs) {
		this.nestedFilters = parentIDs;
	}
	public String getJqlFixed() {
		return jqlFixed;
	}
	public void setJqlFixed(String fixedJql) {
		this.jqlFixed = fixedJql;
	}
	public Integer getJqlNestedFilterReferenceType() {
		return jqlNestedFilterReferenceType;
	}
	public void setJqlNestedFilterReferenceType(Integer jqlNestedFilterReferenceType) {
		this.jqlNestedFilterReferenceType = jqlNestedFilterReferenceType;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Long getProjectid() {
		return projectid;
	}
	public void setProjectid(Long projectid) {
		this.projectid = projectid;
	}
}
