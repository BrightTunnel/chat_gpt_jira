package jiraPojoObjects;

public class PojoPermissionSchemePermissions {
	//--Jira Cloud--:
	//"permissions": [{
	//	"id": 10769,
	//	"self": "https://brighttunnel.atlassian.net/rest/api/2/permissionscheme/10003/permission/10769",
	//	"holder": {
	//		"type": "projectRole",
	//		"parameter": "10010",
	//		"value": "10010",
	//		"projectRole": {
	//			"self": "https://brighttunnel.atlassian.net/rest/api/2/role/10010",
	//			"name": "Viewer",
	//			"id": 10010,
	//			"description": "Viewers can search through, view, and comment on your team's work, but not much else.",
	//			"scope": {
	//				"type": "PROJECT",
	//				"project": {
	//					"id": "10003"
	//				}
	//			}
	//		},
	//		"expand": "projectRole"
	//	},
	//	"permission": "BROWSE_PROJECTS"	
	//},.. 

	private Long id; //--e.g.: 10004,.. 10343
	private String self; //--e.g.: "https://brighttunneldev.atlassian.net/rest/api/2/permissionscheme/0/permission/10004"
	private String holderType; //--e.g.: ["projectRole", "applicationRole"]
	private String holderParameter; //--e.g.: ["10002", "10003"]
	private String holderValue; //--e.g.: ["10002", "10003"]
	private String holderExpand; //--e.g.: ["projectRole"]
	private String permission; //--e.g: ["ADD_COMMENTS", "ADMINISTER_PROJECTS", "WORK_ON_ISSUES"]
	PojoPermissionSchemeProjectRole projectRole;

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getSelf() {
		return self;
	}
	public void setSelf(String self) {
		this.self = self;
	}
	public String getHolderType() {
		return holderType;
	}
	public void setHolderType(String holderType) {
		this.holderType = holderType;
	}
	public String getHolderParameter() {
		return holderParameter;
	}
	public void setHolderParameter(String holderParameter) {
		this.holderParameter = holderParameter;
	}
	public String getHolderValue() {
		return holderValue;
	}
	public void setHolderValue(String holderValue) {
		this.holderValue = holderValue;
	}
	public String getHolderExpand() {
		return holderExpand;
	}
	public void setHolderExpand(String holderExpand) {
		this.holderExpand = holderExpand;
	}
	public String getPermission() {
		return permission;
	}
	public void setPermission(String permission) {
		this.permission = permission;
	}
	public PojoPermissionSchemeProjectRole getProjectRole() {
		return projectRole;
	}
	public void setProjectRole(PojoPermissionSchemeProjectRole projectRole) {
		this.projectRole = projectRole;
	}
}
