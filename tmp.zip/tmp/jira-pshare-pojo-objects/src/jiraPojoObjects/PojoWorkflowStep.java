package jiraPojoObjects;

import java.util.ArrayList;
import java.util.HashMap;

public class PojoWorkflowStep {
	///~~ No such table 'WorkflowStep'., But there is table 'issuestatus' 
	///~~ This class reflects XML object only. WorkFlow for (only?) example.

	//<steps>
	//	<step id="32" name="AVP Approval Pending">
	//		<meta name="jira.status.id">13503</meta>
	//		<meta name="approval.active">true</meta>
	//		<meta name="approval.condition.type">percent</meta>
	//		<meta name="approval.condition.value">100</meta>
	//		<meta name="approval.field.id">customfield_11707</meta>
	//		<meta name="approval.transition.approved">1151</meta>
	//		<meta name="approval.transition.rejected">1111</meta>
	//		<actions>

	private Long stepId; // <step id="4" name="In Progress">
	private String stepName; // <step id="4" name="In Progress">
	private String issuestatusID; // "10001" from: <meta name="jira.status.id">10001</meta> ~~This XML node value matches exactly index field 'id' from table 'issuestatus.id':
	// 		"id","sequence","pname","description","iconurl","statuscategory" 
	// 		"10001",8,Done,...

	//private String metaMoreMetaHere...

	private ArrayList<PojoWorkflowAction> workflowActions; // [actions.common-action.action]

	///~~ Getters / Setters
	
	public Long getStepId() {
		return stepId;
	}

	public void setStepId(Long stepId) {
		this.stepId = stepId;
	}

	public String getStepName() {
		return stepName;
	}

	public void setStepName(String stepName) {
		this.stepName = stepName;
	}

	public String getIssuestatusID() {
		return issuestatusID;
	}

	public void setIssuestatusID(String issuestatusID) {
		this.issuestatusID = issuestatusID;
	}

	public ArrayList<PojoWorkflowAction> getWorkflowActions() {
		return workflowActions;
	}

	public void setWorkflowActions(ArrayList<PojoWorkflowAction> workflowActions) {
		this.workflowActions = workflowActions;
	}

	
	
}