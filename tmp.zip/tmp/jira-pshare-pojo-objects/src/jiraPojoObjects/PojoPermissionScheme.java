package jiraPojoObjects;

import java.util.HashMap;

public class PojoPermissionScheme {

	//--Jira Cloud--:
	//"permissionSchemes": [{
	//	"expand": "permissions,user,group,projectRole,field,all",
	//	"id": 0,
	//	"self": "https://brighttunneldev.atlassian.net/rest/api/2/permissionscheme/0",
	//	"name": "Default Permission Scheme",  "MDP: Simplified Permission Scheme",...
	//	"description": "This is the default Permission Scheme. Any new projects that are created will be assigned this scheme.",
	//	"scope": {
	//		"type": "PROJECT",
	//		"project": {
	//			"id": "10003"
	//		}
	//	},..
	//	"permissions": [{...

	private String expand; //-- "permissions,user,group,projectRole,field,all",
	private Long id; //-- 0,
	private String self; //-- "https://brighttunneldev.atlassian.net/rest/api/2/permissionscheme/0",
	private String name; //-- "Default Permission Scheme",
	private String description; //-- "This is the default Permission Scheme. Any new projects that are created will be assigned this scheme.",
	//private String scope; //--e.g.: {
	private String scopeType; //--e.g.: "scope": {"type": "PROJECT",
	//private String scopeProject; //--e.g.: {
	private String scopeProjectId; //--e.g.: "scope": {"type": "PROJECT", "project": {"id": "10003"}
	private HashMap<Long, PojoPermissionSchemePermissions> permissions; //--

	public String getExpand() {
		return expand;
	}
	public void setExpand(String expand) {
		this.expand = expand;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getSelf() {
		return self;
	}
	public void setSelf(String self) {
		this.self = self;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public HashMap<Long, PojoPermissionSchemePermissions> getPermissions() {
		return permissions;
	}
	public void setPermissions(HashMap<Long, PojoPermissionSchemePermissions> permissions) {
		this.permissions = permissions;
	}
	public String getScopeType() {
		return scopeType;
	}
	public void setScopeType(String scopeType) {
		this.scopeType = scopeType;
	}
	public String getScopeProjectId() {
		return scopeProjectId;
	}
	public void setScopeProjectId(String scopeProjectId) {
		this.scopeProjectId = scopeProjectId;
	}

}
