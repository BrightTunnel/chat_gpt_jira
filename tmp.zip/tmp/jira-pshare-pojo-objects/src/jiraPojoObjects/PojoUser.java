package jiraPojoObjects;

import java.util.HashMap;

public class PojoUser {
	//--JiraCloud Json response:
	//{
	//	"from": "https://brighttunnel.atlassian.net/rest/api/3/user?accountId=5a90f92154c8ff39bc24672d&expand=groups,applicationRoles",
	//	"self": "https://brighttunnel.atlassian.net/rest/api/3/user?accountId=5a90f92154c8ff39bc24672d",
	//	"accountId": "5a90f92154c8ff39bc24672d",
	//	"accountType": "atlassian",
	//	"emailAddress": "tikhboda@gmail.com",
	//	"avatarUrls": {"48x48": "https://secure.gravatar.com/avatar/48e846014a75aa8df418b75b190e6a1d?d=https%3A%2F%2Favatar-management--avatars.us-west-2.prod.public.atl-paas.net%2Finitials%2FVT-0.png",...},
	//	"displayName": "Valeri Tikhonov",
	//	"active": true,
	//	"timeZone": "America/New_York",
	//	"locale": "en_US",
	//	"groups": {
	//		"size": 5,
	//		"items": [{
	//				"name": "jira-admins-brighttunnel",
	//				"groupId": "6ae82f8f-f4a7-4ea8-a14c-5418451f9647",
	//				"self": "https://brighttunnel.atlassian.net/rest/api/3/group?groupId=6ae82f8f-f4a7-4ea8-a14c-5418451f9647"
	//			}, {
	//				"name": "jira-product-discovery-users-brighttunnel",
	//				"groupId": "e7f87295-1a55-4452-b3b3-ccf94205d71a",
	//				"self": "https://brighttunnel.atlassian.net/rest/api/3/group?groupId=e7f87295-1a55-4452-b3b3-ccf94205d71a"
	//			}, {
	//				"name": "jira-software-user-access-admins-brighttunnel",
	//				"groupId": "4e1fce1b-9cdd-4952-985c-f220290cb672",
	//				"self": "https://brighttunnel.atlassian.net/rest/api/3/group?groupId=4e1fce1b-9cdd-4952-985c-f220290cb672"
	//			}, {
	//				"name": "jira-software-users-brighttunnel",
	//				"groupId": "f52c0c36-1fec-441d-8dd0-6eec9c08fb8c",
	//				"self": "https://brighttunnel.atlassian.net/rest/api/3/group?groupId=f52c0c36-1fec-441d-8dd0-6eec9c08fb8c"
	//			}, {
	//				"name": "org-admins",
	//				"groupId": "51bece34-9760-42fb-8e08-8bad2944d63e",
	//				"self": "https://brighttunnel.atlassian.net/rest/api/3/group?groupId=51bece34-9760-42fb-8e08-8bad2944d63e"
	//			}
	//		]
	//	},
	//	"applicationRoles": {
	//		"size": 2,
	//		"items": [{
	//				"key": "jira-product-discovery",
	//				"name": "Jira Product Discovery"
	//			}, {
	//				"key": "jira-software",
	//				"name": "Jira Software"
	//			}
	//		]
	//	},
	//	"expand": "groups,applicationRoles"
	//}

	private String self; //--e.g.: ["https://brighttunneldev.atlassian.net/rest/api/2/user?accountId=5a90f92154c8ff39bc24672d",
	private String accountId; //--e.g.: "accountId": "5a90f92154c8ff39bc24672d", {Root User ID}
	private String accountType; //--e.g.: ["atlassian", "app"]
	private String emailAddress; //--e.g.: ["tikhboda@gmail.com",]
	//private HashMap<String, String> avatarUrls = null;
	private String html; //--e.g.: "html": "Valeri Tikhonov - tikhboda@gmail.com",
	private String displayName; //--e.g.: ["Valeri Tikhonov","Atlas for Jira Cloud","Atlassian Assist","Automation for Jira","Bemy Guest","Chat Notifications","Confluence Analytics (System)","Jira Outlook","Jira Service Management Widget","Jira Spreadsheets","Microsoft Teams for Confluence Cloud","Microsoft Teams for Jira Cloud","Opsgenie Incident Timeline","Proforma Migrator","Slack","Statuspage for Jira","System","Trello","app-customui","app-fragment","app-linkscaddy","app001-hello","app002-wf-validator","fullf"]
	private Boolean active; //--e.g.: [true, false]
	//private String timeZone; //--e.g.:  "timeZone": "America/New_York", 
	//private String locale; //--e.g.: ["en_US"]
	private HashMap<String, PojoGroup> groups;
	private HashMap<String, PojoApplicationRole> applicationRoles;

	public String getSelf() {
		return self;
	}
	public void setSelf(String self) {
		this.self = self;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getDisplayName() {
		return displayName;
	}
	public String getHtml() {
		return html;
	}
	public void setHtml(String html) {
		this.html = html;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public Boolean getActive() {
		return active;
	}
	public void setActive(Boolean active) {
		this.active = active;
	}
	public HashMap<String, PojoGroup> getGroups() {
		return groups;
	}
	public void setGroups(HashMap<String, PojoGroup> groups) {
		this.groups = groups;
	}
	public HashMap<String, PojoApplicationRole> getApplicationRoles() {
		return applicationRoles;
	}
	public void setApplicationRoles(HashMap<String, PojoApplicationRole> applicationRoles) {
		this.applicationRoles = applicationRoles;
	}

}
