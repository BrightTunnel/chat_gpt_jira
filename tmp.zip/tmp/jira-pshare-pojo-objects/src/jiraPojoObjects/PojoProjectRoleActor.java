package jiraPojoObjects;

public class PojoProjectRoleActor {
	//--JiraCloud--
	//"actors": [{
	//	"id": 10006,
	//	"displayName": "Slack",
	//	"type": "atlassian-user-role-actor",
	//	"actorUser": {
	//		"accountId": "557058:0867a421-a9ee-4659-801a-bc0ee4a4487e"
	//	}
	//},...

	private Long id; //--e.g.: [10000,10001,10002,10003,10004,10005,10006,10007,10008,10009,10010,10011,10028] (DC, Cloud)
	private String displayName; //--e.g.: ["Atlas for Jira Cloud","Atlassian Assist","Automation for Jira","Jira Outlook","Jira Service Management Widget","Jira Spreadsheets","Microsoft Teams for Jira Cloud","Proforma Migrator","Slack","Statuspage for Jira","System","Trello","app002-wf-validator"]
	private String type; //--e.g.: ["atlassian-user-role-actor"]
	private String actorUser; //--e.g.: "actorUser": {	"accountId": "557058:0867a421-a9ee-4659-801a-bc0ee4a4487e"}
	private String actorUserAccountId; //--e.g.: ["557058:0867a421-a9ee-4659-801a-bc0ee4a4487e",...]
	//--# Jira DataCenter Only:
	private Long pid; //--(DC)
	private Long projectroleid; //--(DC)
	private String roletype; //--(DC)
	private String roletypeparameter; //--(DC)

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getActorUser() {
		return actorUser;
	}
	public void setActorUser(String actorUser) {
		this.actorUser = actorUser;
	}
	public String getActorUserAccountId() {
		return actorUserAccountId;
	}
	public void setActorUserAccountId(String actorUserAccountId) {
		this.actorUserAccountId = actorUserAccountId;
	}

	public Long getPid() {
		return pid;
	}

	public void setPid(Long pid) {
		this.pid = pid;
	}

	public Long getProjectroleid() {
		return projectroleid;
	}

	public void setProjectroleid(Long projectroleid) {
		this.projectroleid = projectroleid;
	}

	public String getRoletype() {
		return roletype;
	}

	public void setRoletype(String roletype) {
		this.roletype = roletype;
	}

	public String getRoletypeparameter() {
		return roletypeparameter;
	}

	public void setRoletypeparameter(String roletypeparameter) {
		this.roletypeparameter = roletypeparameter;
	}
}
