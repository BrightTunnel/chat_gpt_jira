///package geobundle.pojo;
package jiraPojoObjects;

import java.util.Date;
import java.util.TreeMap;
import java.util.TreeSet; // Elements are automatically sorted and stored in ascending order.

///import jiraPojoTgNgAccounting.PojoTgngItemsToBePaidTable;
///import jiraPojoTgNgAccounting.PojoTgngTransactionHistoryTable;
public class PojoJiraIssue {
	/// ~~ 'JiraIssue' full list of table fields
	/// id numeric(18)
	/// pkey varchar(255)
	/// issuenum numeric(18)
	/// project numeric(18)
	/// reporter varchar(255)
	/// assignee varchar(255)
	/// creator varchar(255)
	/// issuetype varchar(255)
	/// summary varchar(255)
	/// description text
	/// environment text
	/// priority varchar(255)
	/// resolution varchar(255)
	/// issuestatus varchar(255)
	/// created timestamptz
	/// updated timestamptz
	/// duedate timestamptz ///
	/// resolutiondate timestamptz
	/// votes numeric(18)
	/// watches numeric(18)
	/// timeoriginalestimate numeric(18)
	/// timeestimate numeric(18)
	/// timespent numeric(18)
	/// workflow_id numeric(18)
	/// security numeric(18)
	/// fixfor numeric(18)
	/// component numeric(18)
	/// archived bpchar(1)
	/// archivedby varchar(255)
	/// archiveddate timestamptz

	private Long id;
	private String pkey; // ~~ Observed in DB: [NULL]
	private Long issuenum;
	private Long project; // ~~ Project ID = 10000L, attribute form <project id="10000" key="BUS">Business Systems</project>
	private String reporter; // ~~ <reporter username="user@null.null">Fname LastName</reporter>
	private String assignee; // ~~ <assignee username="user@null.null">Fname LastName</assignee>
	private String creator; // ~~ 'author'?
	private String issueType; // ~~ <type id="10003" iconUrl="/secure/viewavatar?size=xsmallavatarId=10645avatarType=issuetype">Task</type> Epic, Story, Task, Sub-task, Bug, Initiative
	private String summary; // ~~ <summary>My-Summary</summary>
	private String epicName; // ~~ customfield_12006
	private String description; // ~~ <description><h2>My Description</h2></description>
	private String status; //
	private String environment; // ~~ <environment />
	private String priority; // ~~ <priority id="3" iconUrl="http://localhost:8080/images/icons/priorities/medium.svg">Medium</priority> ~~ Highest, High, Medium, Low, Lowest ~~
	private String resolution; // ~~ <resolution id="-1">Unresolved</resolution>
	private String issuestatus; // ~~ <status id="1" description="The issue is open" iconUrl="../images/icons/statuses/open.png">Open</status> Issue Status: [To Do, Done, In Progress, Open, Reopened, Resolved, Closed]
	private Date created; // ~~<created>Tue, 28 Sep 2027 08:11:50 -0400</created>
	private Date updated; // ~~ <updated>Sat, 9 Oct 2027 23:47:25 -0400</updated> ~~ alias 'updatedDate'. Note - there is no such field 'modified'
	private Date duedate; // ~~ <due />, When generating JSON import file, have to use field 'duedate'
	private String targetEnd; // ~~ CF 'Target end'
	private Date resolutiondate;
	private Long votes; // ~~ <votes>0</votes>
	private Long watches; // ~~ <watches>1</watches>
	private TreeMap<String, PojoJiraIssue> epicChildren; //--Children of the epic (e.g. Tasks, Bugs, etc.)
	private TreeSet<String> components;
	private TreeSet<String> fixVersions;

	/// private Long timeoriginalestimate;
	/// private Long timeestimate;
	/// private Long timespent;
	private Long workflow_id;
	/// private Long security;
	/// private Long fixfor;
	private Long component; // ~~ ex: componentID
	private String archived;
	private String archivedby;
	private Date archiveddate;

	/// ~~~ Not in the db table 'JiraIssue' but may be a part of the XML Jira Issue Element ~~~
	private String key; // ~~ 'BST-123': <key id="10400">BST-123</key>
	private String title; // ~~ <title>[BST-123] My-Summary</title> ~~Automatically generated after 'summary'
	/// ~~private Long issuetypeID; //~~ Obsolete, replaced? with issuetype
	private String link; // ~~ <link>http://localhost:8080/browse/BST-123</link>
	private String statusCategory; // ~~ <statusCategory id="2" key="new" colorName="blue-gray" />
	private String labels; // ~~ <labels><label>scheduled-work</label></labels> {label in JSM?}
	private String attachments; // ~~ <attachments></attachments>
	private String subtasks; // ~~ <subtasks></subtasks>
	/// private HashMap<String, PojoCustomField> customfields; // ~~ <customfields></customfields> {key = cfName} // TODO - may be duplicates of CFNames
	/// private HashMap<String, PojoComment> comments; // ~~ <comments><comment id="10100" author="JIRAUSER10000" created="Sat, 9 Oct 2027 22:56:37 -0400"></comments>
	/// + private HashMap<String, PojoActivity> activity; //???
	/// + Change history ???
	private String body; // ~~ Description? ~~
	private String fixVersion; // ~~ <fixVersion>JIRA21_10</fixVersion>
	private String author; // creator?
	private Date dateCaseClosed; // ~~ <customfieldname>DateCaseClosed</customfieldname> ~~ dateCreated + 30 days
	/// private Date resolved; //~~Extra, see 'Status' ~~ Can't modify, set when issue resolved {resolutiondate?}
	private String issueLinks; // ~~ <issueLinks></issueLinks>
	private String cfMalCode; // -- for example MAL- Code
	/// private String customfield_12006; // -- EpicName in Toshiba

	/// ~~ Extra ~~
	private Date dateCommented; //TODO Find the correct place for it 
	private PojoJiraIssueBusiness pojoJiraIssueBusiness;

	/// ~~ Extra TGNG ~~
	/// private TreeMap<String, PojoTgngItemsToBePaidTable> cfItemsToBePaidTable;
	/// private TreeMap<String, PojoTgngTransactionHistoryTable> cfTransactionHistoryTable;

	/// ~~~ Getters/Setters ~~~

	public PojoJiraIssueBusiness getPojoJiraIssueBusiness() {
		return pojoJiraIssueBusiness;
	}

	public void setPojoJiraIssueBusiness(PojoJiraIssueBusiness pojoJiraIssueBusiness) {
		this.pojoJiraIssueBusiness = pojoJiraIssueBusiness;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPkey() {
		return pkey;
	}

	public void setPkey(String pkey) {
		this.pkey = pkey;
	}

	public Long getIssuenum() {
		return issuenum;
	}

	public void setIssuenum(Long issuenum) {
		this.issuenum = issuenum;
	}

	public Long getProject() {
		return project;
	}

	public void setProject(Long project) {
		this.project = project;
	}

	public String getReporter() {
		return reporter;
	}

	public void setReporter(String reporter) {
		this.reporter = reporter;
	}

	public String getAssignee() {
		return assignee;
	}

	public void setAssignee(String assignee) {
		this.assignee = assignee;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getIssueType() {
		return issueType;
	}

	public void setIssueType(String issueType) {
		this.issueType = issueType;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getResolution() {
		return resolution;
	}

	public void setResolution(String resolution) {
		this.resolution = resolution;
	}

	public String getIssuestatus() {
		return issuestatus;
	}

	public void setIssuestatus(String issuestatus) {
		this.issuestatus = issuestatus;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getUpdated() {
		return updated;
	}

	public void setUpdated(Date updated) {
		this.updated = updated;
	}

	public Date getDuedate() {
		return duedate;
	}

	public void setDuedate(Date duedate) {
		this.duedate = duedate;
	}

	public Date getResolutiondate() {
		return resolutiondate;
	}

	public void setResolutiondate(Date resolutiondate) {
		this.resolutiondate = resolutiondate;
	}

	public Long getVotes() {
		return votes;
	}

	public void setVotes(Long votes) {
		this.votes = votes;
	}

	public Long getWatches() {
		return watches;
	}

	public void setWatches(Long watches) {
		this.watches = watches;
	}

	public Long getWorkflow_id() {
		return workflow_id;
	}

	public void setWorkflow_id(Long workflow_id) {
		this.workflow_id = workflow_id;
	}

	public Long getComponent() {
		return component;
	}

	public void setComponent(Long component) {
		this.component = component;
	}

	public String getArchived() {
		return archived;
	}

	public void setArchived(String archived) {
		this.archived = archived;
	}

	public String getArchivedby() {
		return archivedby;
	}

	public void setArchivedby(String archivedby) {
		this.archivedby = archivedby;
	}

	public Date getArchiveddate() {
		return archiveddate;
	}

	public void setArchiveddate(Date archiveddate) {
		this.archiveddate = archiveddate;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getStatusCategory() {
		return statusCategory;
	}

	public void setStatusCategory(String statusCategory) {
		this.statusCategory = statusCategory;
	}

	public String getLabels() {
		return labels;
	}

	public void setLabels(String labels) {
		this.labels = labels;
	}

	public String getAttachments() {
		return attachments;
	}

	public void setAttachments(String attachments) {
		this.attachments = attachments;
	}

	public String getSubtasks() {
		return subtasks;
	}

	public void setSubtasks(String subtasks) {
		this.subtasks = subtasks;
	}

	///	public HashMap<String, PojoCustomField> getCustomfields() {
	///		return customfields;
	///	}
	///
	///	public void setCustomfields(HashMap<String, PojoCustomField> customfields) {
	///		this.customfields = customfields;
	///	}
	///
	///	public HashMap<String, PojoComment> getComments() {
	///		return comments;
	///	}
	///
	///	public void setComments(HashMap<String, PojoComment> comments) {
	///		this.comments = comments;
	///	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getFixVersion() {
		return fixVersion;
	}

	public void setFixVersion(String fixVersion) {
		this.fixVersion = fixVersion;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public Date getDateCaseClosed() {
		return dateCaseClosed;
	}

	public void setDateCaseClosed(Date dateCaseClosed) {
		this.dateCaseClosed = dateCaseClosed;
	}

	public String getIssueLinks() {
		return issueLinks;
	}

	public void setIssueLinks(String issueLinks) {
		this.issueLinks = issueLinks;
	}

	public Date getDateCommented() {
		return dateCommented;
	}

	public void setDateCommented(Date dateCommented) {
		this.dateCommented = dateCommented;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getEpicName() {
		return epicName;
	}

	public void setEpicName(String epicName) {
		this.epicName = epicName;
	}

	public String getCfMalCode() {
		return cfMalCode;
	}

	public void setCfMalCode(String cfMalCode) {
		this.cfMalCode = cfMalCode;
	}

	public TreeMap<String, PojoJiraIssue> getEpicChildren() {
		return epicChildren;
	}

	public void setEpicChildren(TreeMap<String, PojoJiraIssue> epicChildren) {
		this.epicChildren = epicChildren;
	}

	public TreeSet<String> getComponents() {
		return components;
	}

	public void setComponents(TreeSet<String> components) {
		this.components = components;
	}

	public TreeSet<String> getFixVersions() {
		return fixVersions;
	}

	public void setFixVersions(TreeSet<String> fixVersions) {
		this.fixVersions = fixVersions;
	}

	public String getTargetEnd() {
		return targetEnd;
	}

	public void setTargetEnd(String targetEnd) {
		this.targetEnd = targetEnd;
	}

}
