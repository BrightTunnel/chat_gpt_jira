package jiraPojoObjects;

import java.util.HashMap;

public class PojoProject {
	//    <Project id="10000" name="PR" lead="JIRAUSER10000" key="PR" counter="55" assigneetype="3" avatar="10324" originalkey="PR" projecttype="service_desk"/>
	//    <ProjectKey id="10000" projectId="10000" projectKey="PR"/>
	//    <ProjectRole id="10002" name="Administrators" description="This project role was re-created by Jira Service Management for managing administrators. Please do not delete this role or edit its name."/>
	//    <ProjectRole id="10100" name="Service Desk Customers" description="This project role was created by Jira Service Management for managing customers. Please do not delete this role or edit its name."/>
	//    <ProjectRoleActor id="10002" projectroleid="10002" roletype="atlassian-group-role-actor" roletypeparameter="jira-administrators"/>
	//    <ProjectRoleActor id="10101" pid="10000" projectroleid="10002" roletype="atlassian-user-role-actor" roletypeparameter="JIRAUSER10000"/>

	///~~ table 'project': [id,pname,url,"lead",description,pkey,pcounter,assigneetype,avatar,originalkey,projecttype]
	private Long id; // ~~ 10000
	private String pname; // ~~ projectName 'Service Desk'
	private String url;
	private String lead; // ~~ projectLead JIRAUSER10000
	private String description;
	private String pkey; // projectKey 'PRKEY', JiraCloud: "key": "PRKEY"
	private Long pcounter; // ~~ 55 issues
	private Long assigneetype; // ~~ 3
	private Long avatar; //~~ DC: 10324; JiraCloud: avatarUrls:{"48x48":"https://brighttunneldev.atlassian.net/rest/api/2/universal_avatar/view/type/project/avatar/10406",...}
	private String originalkey; //~~ projectOriginalKey 'PRO'
	private String projecttype; // ~~ ['business', service_desk']; JiraCloud: "projectTypeKey": {"software","product_discovery",...}

	//~~JiraCloud {rest/api/3/project}:
	//--JiraCloud REST API "https://brighttunnel.atlassian.net/rest/api/2/project/10002",
	//"values": [{
	//	"expand": "description,lead,issueTypes,url,projectKeys,permissions,insight",
	//	"self": "https://brighttunnel.atlassian.net/rest/api/2/project/10003",
	//	"id": "10003",
	//	"key": "MDP",
	//	"name": "My discovery project",
	//	"roles": {
	//		"atlassian-addons-project-access": "https://brighttunnel.atlassian.net/rest/api/3/project/10003/role/10011",
	//		"Administrator": "https://brighttunnel.atlassian.net/rest/api/3/project/10003/role/10008",
	//		"Viewer": "https://brighttunnel.atlassian.net/rest/api/3/project/10003/role/10010",
	//		"Member": "https://brighttunnel.atlassian.net/rest/api/3/project/10003/role/10009"
	//	},
	//	"avatarUrls": {"48x48": "https://brighttunnel.atlassian.net/rest/api/2/universal_avatar/view/type/project/avatar/10404",...	},
	//	"projectCategory": {
	//		"self": "https://site.atlassian.net/rest/api/3/projectCategory/10000",
	//		"id": "10000",
	//		"name": "bt_project_category",
	//		"description": "Some Test Project Category"
	//	},	
	//	"projectTypeKey": "product_discovery",
	//	"simplified": true,
	//	"style": "next-gen",
	//	"isPrivate": false,
	//	"properties": {},
	//	"entityId": "4cfc5dc1-b75b-45a3-81fc-ebbaf5aa3b30",
	//	"uuid": "4cfc5dc1-b75b-45a3-81fc-ebbaf5aa3b30"
	//},...
	private String expand; //~~JiraCloud: "expand": "description,lead,issueTypes,url,projectKeys,permissions,insight"
	private String self; //~~JiraCloud: "self": "https://brighttunneldev.atlassian.net/rest/api/2/project/10000"
	private String cldId; // ~~ JiraCloud "id": "10003", Note: same as "private Long id;" but JiraCloud has it as String, so added this another project ID 
	//--      key; //--Use 'pkey'
	//--      description; //--Use 'description'
	//--      lead {...}; //--Project Lead -- Not Used so far
	//--      components: [], //--Not Used so far
	//--      issueTypes": [{... //--Not Used so far
	//--      assigneeType: "UNASSIGNED" //--Not Used so far
	//--      versions": [...] //--Not Used so far	
	//--      name; //--Use 'pname' //-- "name": "My discovery project",
	private HashMap<String, PojoProjectRole> projectRoles;
	//--      avatarUrls; //--Use 'avatar'
	//--      projectCategory: {...}
	private String projectCategoryId; //--e.g.: "id": "10000", 	
	private String projectCategoryName; //--e.g.:"name": "bt_project_category", 
	private String projectCategoryDescription; //--e.g.: "description": "Some Test Project Category"
	//--      projectTypeKey; //--Use 'projecttype' --e.g.: "projectTypeKey": "product_discovery",
	private boolean simplified; //~~JiraCloud: "simplified": [true, false] 
	private String style; //~~JiraCloud: "style": ["next-gen", "classic"]
	private boolean isPrivate; //~~JiraCloud: "isPrivate": [true, false]
	private String[] properties; //~~JiraCloud: "properties": {...} //TODO Convert to the dictionary
	private String entityId; //--e.g.: "4cfc5dc1-b75b-45a3-81fc-ebbaf5aa3b30",
	private String uuid;//--e.g.: "4cfc5dc1-b75b-45a3-81fc-ebbaf5aa3b30"

	//-- Extra -- not part of the Jira Server/Cloud Project Table / Api Json Object
	private PojoPermissionScheme usedPermissionScheme; //-- Extra induced field, used by this project Permission Scheme

	// ~~~ Getters/Setters ~~
	public Long getId() {
		return id;
	}
	public void setId(Long projectId) {
		this.id = projectId;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String projectName) {
		this.pname = projectName;
	}
	public String getLead() {
		return lead;
	}
	public void setLead(String projectLead) {
		this.lead = projectLead;
	}
	public String getPkey() {
		return pkey;
	}
	public void setPkey(String projectKey) {
		this.pkey = projectKey;
	}
	public String getOriginalkey() {
		return originalkey;
	}
	public void setOriginalkey(String projectOriginalKey) {
		this.originalkey = projectOriginalKey;
	}
	public Long getPcounter() {
		return pcounter;
	}
	public void setPcounter(Long projectCounter) {
		this.pcounter = projectCounter;
	}
	public Long getAssigneetype() {
		return assigneetype;
	}
	public void setAssigneetype(Long projectAssigneetype) {
		this.assigneetype = projectAssigneetype;
	}
	public Long getAvatar() {
		return avatar;
	}
	public void setAvatar(Long projectAvatar) {
		this.avatar = projectAvatar;
	}
	public String getProjecttype() {
		return projecttype;
	}
	public void setProjecttype(String projecttype) {
		this.projecttype = projecttype;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getExpand() {
		return expand;
	}
	public void setExpand(String expand) {
		this.expand = expand;
	}
	public String getSelf() {
		return self;
	}
	public void setSelf(String self) {
		this.self = self;
	}
	public boolean isSimplified() {
		return simplified;
	}
	public void setSimplified(boolean simplified) {
		this.simplified = simplified;
	}
	public String getStyle() {
		return style;
	}
	public void setStyle(String style) {
		this.style = style;
	}
	public boolean isPrivate() {
		return isPrivate;
	}
	public void setPrivate(boolean isPrivate) {
		this.isPrivate = isPrivate;
	}
	public String[] getProperties() {
		return properties;
	}
	public void setProperties(String[] properties) {
		this.properties = properties;
	}
	public String getCldId() {
		return cldId;
	}
	public void setCldId(String cldId) {
		this.cldId = cldId;
	}
	public String getEntityId() {
		return entityId;
	}
	public void setEntityId(String entityId) {
		this.entityId = entityId;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getProjectCategoryId() {
		return projectCategoryId;
	}
	public void setProjectCategoryId(String projectCategoryId) {
		this.projectCategoryId = projectCategoryId;
	}
	public String getProjectCategoryName() {
		return projectCategoryName;
	}
	public void setProjectCategoryName(String projectCategoryName) {
		this.projectCategoryName = projectCategoryName;
	}
	public String getProjectCategoryDescription() {
		return projectCategoryDescription;
	}
	public void setProjectCategoryDescription(String projectCategoryDescription) {
		this.projectCategoryDescription = projectCategoryDescription;
	}
	public HashMap<String, PojoProjectRole> getProjectRoles() {
		return projectRoles;
	}
	public void setProjectRoles(HashMap<String, PojoProjectRole> projectRoles) {
		this.projectRoles = projectRoles;
	}
	public PojoPermissionScheme getUsedPermissionScheme() {
		return usedPermissionScheme;
	}
	public void setUsedPermissionScheme(PojoPermissionScheme usedPermissionScheme) {
		this.usedPermissionScheme = usedPermissionScheme;
	}

}
