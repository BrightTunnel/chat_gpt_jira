package jiraPojoObjects;

public class PojoApp_user {

	private Long id;
	private String user_key;
	private String lower_user_name;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUser_key() {
		return user_key;
	}

	public void setUser_key(String user_key) {
		this.user_key = user_key;
	}

	public String getLower_user_name() {
		return lower_user_name;
	}

	public void setLower_user_name(String lower_user_name) {
		this.lower_user_name = lower_user_name;
	}

}
