package jiraPojoObjects;

import java.util.TreeMap;

public class PojoBehaviour {
	private Long behaviourIdLong;
	private String behaviourID; // ~~ 'Behaviour_13'
	// private String behaviourShortID; // '13' Extracted from 'Behaviour_13'
	private String behaviourName; // ~~ 'tvnBehaviour Actual Name'
	private String description;
	private boolean disabled;
	private boolean useValidatorPlugin;
	private String guideWorkflow;

	// ~~ Extra
	private String behaviourKeyNameAndID;
	private TreeMap<String, PojoCustomFieldScript> mapOfFielsdScript;
	private TreeMap<String, String> listOfThisBehaviourCustomFieldsUsedInOtherBehaviour;

	// ~~~ Special ~~~

	@Override
	public String toString() {
		return "disabled: '" + disabled + "', useValidatorPlugin: '" + useValidatorPlugin + "', guideWF: '" + guideWorkflow + "'" + ", description: '" + description + "'";
	}

	// ~~~ Getters/Setters ~~~
	public String getBehaviourID() {
		return behaviourID;
	}

	public void setBehaviourID(String behaviourID) {
		this.behaviourID = behaviourID;
	}

	public String getBehaviourName() {
		return behaviourName;
	}

	public void setBehaviourName(String behaviourName) {
		this.behaviourName = behaviourName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isUseValidatorPlugin() {
		return useValidatorPlugin;
	}

	public void setUseValidatorPlugin(boolean useValidatorPlugin) {
		this.useValidatorPlugin = useValidatorPlugin;
	}

	public String getGuideWorkflow() {
		return guideWorkflow;
	}

	public void setGuideWorkflow(String guideWorkflow) {
		this.guideWorkflow = guideWorkflow;
	}

	public TreeMap<String, PojoCustomFieldScript> getMapOfFielsdScript() {
		return mapOfFielsdScript;
	}

	public void setMapOfFielsdScript(TreeMap<String, PojoCustomFieldScript> mapOfFielsdScript) {
		this.mapOfFielsdScript = mapOfFielsdScript;
	}

	public Long getBehaviourIdLong() {
		return behaviourIdLong;
	}

	public void setBehaviourIdLong(Long behaviourIdLong) {
		this.behaviourIdLong = behaviourIdLong;
	}

	public boolean isDisabled() {
		return disabled;
	}

	public void setDisabled(boolean disabled) {
		this.disabled = disabled;
	}

	public String getBehaviourKeyNameAndID() {
		return behaviourKeyNameAndID;
	}

	public void setBehaviourKeyNameAndID(String behaviourKeyNameAndID) {
		this.behaviourKeyNameAndID = behaviourKeyNameAndID;
	}

	public TreeMap<String, String> getListOfThisBehaviourCustomFieldsUsedInOtherBehaviour() {
		return listOfThisBehaviourCustomFieldsUsedInOtherBehaviour;
	}

	public void setListOfThisBehaviourCustomFieldsUsedInOtherBehaviour(TreeMap<String, String> listOfThisBehaviourCustomFieldsUsedInOtherBehaviour) {
		this.listOfThisBehaviourCustomFieldsUsedInOtherBehaviour = listOfThisBehaviourCustomFieldsUsedInOtherBehaviour;
	}
}
