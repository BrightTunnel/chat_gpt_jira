package pojo;

import java.time.LocalDateTime;
import java.util.HashSet;

public class PojoJsonSystemSettingsFile {

	private String inDirJiraApplicationLogs; // private String C:/Program Files/Atlassian/Jira/logs",
	private String inDirJiraHomeLogs; // private String C:/Program Files/Atlassian/Application Data/Jira/log"
	private String outDirReports; // Folder to save reports
	private String atlassianAppLogFileName; // e.g.: [atlassian-jira.log, confluence-jira.log]

	// ~~ connectionUrl = jdbc:postgresql://localhost/jira?user=uname&password=secret&ssl=true
	// ~~ connectionUrl = jdbc:postgresql://HOST/DATABASE

	// Class.forName("org.postgresql.Driver");
	// Connection conn = DriverManager.getConnection(url,"username", "password");

	// jdbc:derby:[subsubprotocol:][databaseName][;attribute=value]*
	// subsubprotocol specifies where Java DB should search for the database, either in a directory, in memory, in a class path, or in a JAR file. It is typically omitted.
	// attribute=value represents an optional, semicolon-separated list of attributes. These attributes enable you to instruct Java DB to perform various tasks, including the following:
	// Create the database specified in the connection URL.
	// Encrypt the database specified in the connection URL.
	// Specify directories to store logging and trace information.
	// Specify a user name and password to connect to the database.

	private String dbDriver; // org.postgresql.Driver
	private String dbHost; // ~~ postgresql
	private String dbPortNumber;
	private String dbName; // the name of the database to connect to
	private String dbUsername;
	private String dbPassword;
	private boolean dbEnableSsl;

	// ~~ Stable default ~~
	private boolean readAtlassianJiraLog;
	private boolean readSlowJqlLog;
	private boolean readCatalinaLog;
	private boolean readAccessLog;

	private boolean drawAtlassianJiraLog;
	private boolean drawSlowJqlLog;
	private boolean drawCatalinaLog;
	private boolean drawAccessLog;

	private boolean useJiraDbSearchRequest;

	private boolean jiraLogsIsCollectAllLogData; //~~ all jira logs: read and save all log entries 
	private boolean jiraLogsIsCollectIfStringToFindIsFound; //~~ jiraLogs: is Collect If SubString to be found is Present
	private boolean jiraLogsIsCollectErrorsAndWarnings; //~~ jiraLogs: is Collect ErrorsAndWarnings
	private boolean jiraLogsIsCollectWarnings; //~~ jiraLogs: to remove warnings from the graph

	private boolean drawCompressedAndHandPickedRanksOnly; //~~ Exclude noisy individual ranks, draw on chart only summary, compressed, filtered and error ranks only
	private boolean drawCompressedAndHandPickedRanksAndRelatedDetailes; //~~ Add all individual ranks with detales for hand Picked Ranks 

	private boolean drawExtraRankBytesSentPerTick;
	private int groupMessagesOption; // ~~ 0=ApiCallCore, 1=ApiCallCore+UserNameCore

	private boolean systemUseSingleColour; //~~ Make all rank's ticks bright and single colored
	private boolean accessLogExtractRestApiCallsOnly; //~~ Extract from Access Log only events, containing substring  
	private String accessLogRequiredRestApiRequestMethod; //~~ Use to filter specific RestApiRequestMethod, e.g:'/rest/scriptRunner/latest/'. If == '', will Extract ALL events and Rest API Request Methods   
	private boolean accessLogGroupApiCallsByExecutionTime; //~~ Add rounded to seconds execution time of each DataPoint (RestApiCall Event) to the top level order key and split events to the groups by the same execution time
	private int accessLogGroupApiCallsByPathDepth; //~~

	private int rankThresholdEvents; //~~ Remove all (user account) ranks with sum per day of all events (all logs entires) less than this count
	private int rankThresholdBytesSent; //~~ Remove all (user account) ranks with sum per day of all Rest Api bytes sent less than (bytes)
	private int rankThresholdExecutionTimesSec; //~~ remove all (user account) ranks with sum per day of all Rest Api execution times shorter than (sec)

	private Long chartThresholdEvents; //~~ "chartThresholdEvents": 10000, 
	private Long chartThresholdBytesSent; //~~ "chartThresholdBytesSent": 10000000,  
	private Long chartThresholdExecutionTimesSec; //~~"chartThresholdExecutionTimesSec": 1800,  

	private int highlightHeavyRanksWithSumExecutionTimeGreaterThanMin;
	private int highlightHeavyRanksWithNumberOfCallsPerDayMoreThan;
	private boolean excludeNonHumanAccounts; // NHID, NPID, non-person ID

	private boolean reportAllAccessLogRecordsNotErrorsOnly; // ~~ All log entries ||  Errors only
	private HashSet<String> collectIfAccountsAre;
	private HashSet<String> collectIfTheseSubstringsAreFound; // ~~ Collect to if substring(s) from this list is found in the log raw string - it will be put to the top level '!' section,  if not - to the '#' section below '!'
	private HashSet<String> doNotCollectExcludeIfSubstringsAreFound;
	//private int daysToShiftBack; // ~~ OBSOLETE Start day to shift back, (0 - current day, 1 - start day is - yesterday, etc.)
	//private int daysToCollect; // ~~ OBSOLETE Days to collect (1 - just start day only, 2 - start day + next day, etc.)
	private LocalDateTime collectDateTimeStart;
	private LocalDateTime collectDateTimeEnd;
	private boolean jiraLogsIsCheckFileMetaData; //~~ Consider (or not) File created/updated dates 

	// private Long shiftHrs; // ~~ UTC GMT to EST
	private int rankSizeHrs; // ~~ time axis size - will contain all events for this period, E.g. 24 hours
	private int tickSizeMinutes; // ~~ time line increment step (1 minute, 10 minutes etc) (graph resolution)

	//~~ Seismo
	private boolean seismoUseJiraDbToPersistData;
	private Long seismoChartTimeSpanMinutes; // A Chart Time Span is the range of time covered by the chart. Check also Runner's parameter '-charttimespanmin'.
	private int seismoXFuseJiraLogDataPointsToChartSlabSeconds; //~~seismo // A Chart Slab refers to a designated time interval, such as one minute, used to condense and summarize multiple frequent data points into a single data point. This approach helps prevent the overcrowding of the chart with numerous data points.
	private int seismoMinNumberOfEventsPerSlabToPersist; //~~seismo

	// ~~ Getters and Setters
	public String getInDirJiraApplicationLogs() {
		return inDirJiraApplicationLogs;
	}

	public void setInDirJiraApplicationLogs(String inDirJiraApplicationLogs) {
		this.inDirJiraApplicationLogs = inDirJiraApplicationLogs;
	}

	public String getInDirJiraHomeLogs() {
		return inDirJiraHomeLogs;
	}

	public void setInDirJiraHomeLogs(String InDirJiraHomeLogs) {
		this.inDirJiraHomeLogs = InDirJiraHomeLogs;
	}

	public String getOutDirReports() {
		return outDirReports;
	}

	public void setOutDirReports(String outDirReports) {
		this.outDirReports = outDirReports;
	}

	public String getAtlassianAppLogFileName() {
		return atlassianAppLogFileName;
	}

	public void setAtlassianAppLogFileName(String atlassianAppLogFileName) {
		this.atlassianAppLogFileName = atlassianAppLogFileName;
	}

	public String getDbDriver() {
		return dbDriver;
	}

	public void setDbDriver(String dbDriver) {
		this.dbDriver = dbDriver;
	}

	public String getDbHost() {
		return dbHost;
	}

	public void setDbHost(String dbHost) {
		this.dbHost = dbHost;
	}

	public String getDbPortNumber() {
		return dbPortNumber;
	}

	public void setDbPortNumber(String dbPortNumber) {
		this.dbPortNumber = dbPortNumber;
	}

	public String getDbName() {
		return dbName;
	}

	public void setDbName(String dbName) {
		this.dbName = dbName;
	}

	public String getDbUsername() {
		return dbUsername;
	}

	public void setDbUsername(String dbUsername) {
		this.dbUsername = dbUsername;
	}

	public String getDbPassword() {
		return dbPassword;
	}

	public void setDbPassword(String dbPassword) {
		this.dbPassword = dbPassword;
	}

	public boolean isDbEnableSsl() {
		return dbEnableSsl;
	}

	public void setDbEnableSsl(boolean dbEnableSsl) {
		this.dbEnableSsl = dbEnableSsl;
	}

	public boolean isUseJiraDbSearchRequest() {
		return useJiraDbSearchRequest;
	}

	public void setUseJiraDbSearchRequest(boolean useJiraDbFilters) {
		this.useJiraDbSearchRequest = useJiraDbFilters;
	}

	public int getRankSizeHrs() {
		return rankSizeHrs;
	}

	public void setRankSizeHrs(int rankSizeHrs) {
		this.rankSizeHrs = rankSizeHrs;
	}

	public int getTickSizeMinutes() {
		return tickSizeMinutes;
	}

	public void setTickSizeMinutes(int tickSizeMinutes) {
		this.tickSizeMinutes = tickSizeMinutes;
	}

	public boolean isReportAllAccessLogRecordsNotErrorsOnly() {
		return reportAllAccessLogRecordsNotErrorsOnly;
	}

	public void setReportAllAccessLogRecordsNotErrorsOnly(boolean reportAllAccessLogRecordsNotErrorsOnly) {
		this.reportAllAccessLogRecordsNotErrorsOnly = reportAllAccessLogRecordsNotErrorsOnly;
	}

	public int getGroupMessagesOption() {
		return groupMessagesOption;
	}

	public void setGroupMessagesOption(int groupMessagesOption) {
		this.groupMessagesOption = groupMessagesOption;
	}

	public boolean isDrawCompressedAndHandPickedRanksOnly() {
		return drawCompressedAndHandPickedRanksOnly;
	}

	public void setDrawCompressedAndHandPickedRanksOnly(boolean drawCompressedAndHandPickedRanksOnly) {
		this.drawCompressedAndHandPickedRanksOnly = drawCompressedAndHandPickedRanksOnly;
	}

	public boolean isReadSlowJqlLog() {
		return readSlowJqlLog;
	}

	public void setReadSlowJqlLog(boolean readSlowJqlLog) {
		this.readSlowJqlLog = readSlowJqlLog;
	}

	public boolean isReadCatalinaLog() {
		return readCatalinaLog;
	}

	public void setReadCatalinaLog(boolean readCatalinaLog) {
		this.readCatalinaLog = readCatalinaLog;
	}

	public boolean isReadAccessLog() {
		return readAccessLog;
	}

	public void setReadAccessLog(boolean readAccessLog) {
		this.readAccessLog = readAccessLog;
	}

	public boolean isReadAtlassianJiraLog() {
		return readAtlassianJiraLog;
	}

	public void setReadAtlassianJiraLog(boolean readAtlassianJiraLog) {
		this.readAtlassianJiraLog = readAtlassianJiraLog;
	}

	public boolean isDrawAtlassianJiraLog() {
		return drawAtlassianJiraLog;
	}

	public void setDrawAtlassianJiraLog(boolean drawAtlassianJiraLog) {
		this.drawAtlassianJiraLog = drawAtlassianJiraLog;
	}

	public boolean isDrawSlowJqlLog() {
		return drawSlowJqlLog;
	}

	public void setDrawSlowJqlLog(boolean drawSlowJqlLog) {
		this.drawSlowJqlLog = drawSlowJqlLog;
	}

	public boolean isDrawCatalinaLog() {
		return drawCatalinaLog;
	}

	public void setDrawCatalinaLog(boolean drawCatalinaLog) {
		this.drawCatalinaLog = drawCatalinaLog;
	}

	public boolean isDrawAccessLog() {
		return drawAccessLog;
	}

	public void setDrawAccessLog(boolean drawAccessLog) {
		this.drawAccessLog = drawAccessLog;
	}

	public boolean isAccessLogExtractRestApiCallsOnly() {
		return accessLogExtractRestApiCallsOnly;
	}

	public void setAccessLogExtractRestApiCallsOnly(boolean accessLogExtractRestApiCallsOnly) {
		this.accessLogExtractRestApiCallsOnly = accessLogExtractRestApiCallsOnly;
	}

	public String getAccessLogRequiredRestApiRequestMethod() {
		return accessLogRequiredRestApiRequestMethod;
	}

	public void setAccessLogRequiredRestApiRequestMethod(String accessLogRequiredRestApiRequestMethod) {
		this.accessLogRequiredRestApiRequestMethod = accessLogRequiredRestApiRequestMethod;
	}

	public int getRankThresholdExecutionTimesSec() {
		return rankThresholdExecutionTimesSec;
	}

	public void setRankThresholdExecutionTimesSec(int rankThresholdExecutionTimesSec) {
		this.rankThresholdExecutionTimesSec = rankThresholdExecutionTimesSec;
	}

	public int getRankThresholdEvents() {
		return rankThresholdEvents;
	}

	public void setRankThresholdEvents(int rankThresholdEvents) {
		this.rankThresholdEvents = rankThresholdEvents;
	}

	public int getHighlightHeavyRanksWithSumExecutionTimeGreaterThanMin() {
		return highlightHeavyRanksWithSumExecutionTimeGreaterThanMin;
	}

	public void setHighlightHeavyRanksWithSumExecutionTimeGreaterThanMin(int highlightHeavyRanksWithSumExecutionTimeGreaterThanMin) {
		this.highlightHeavyRanksWithSumExecutionTimeGreaterThanMin = highlightHeavyRanksWithSumExecutionTimeGreaterThanMin;
	}

	public boolean isAccessLogGroupApiCallsByExecutionTime() {
		return accessLogGroupApiCallsByExecutionTime;
	}

	public void setAccessLogGroupApiCallsByExecutionTime(boolean accessLogGroupApiCallsByExecutionTime) {
		this.accessLogGroupApiCallsByExecutionTime = accessLogGroupApiCallsByExecutionTime;
	}

	public boolean isExcludeNonHumanAccounts() {
		return excludeNonHumanAccounts;
	}

	public void setExcludeNonHumanAccounts(boolean excludeNonHumanAccounts) {
		this.excludeNonHumanAccounts = excludeNonHumanAccounts;
	}

	public HashSet<String> getCollectIfTheseSubstringsAreFound() {
		return collectIfTheseSubstringsAreFound;
	}

	public void setCollectIfTheseSubstringsAreFound(HashSet<String> collectIfTheseSubstringsAreFound) {
		this.collectIfTheseSubstringsAreFound = collectIfTheseSubstringsAreFound;
	}

	public int getHighlightHeavyRanksWithNumberOfCallsPerDayMoreThan() {
		return highlightHeavyRanksWithNumberOfCallsPerDayMoreThan;
	}

	public void setHighlightHeavyRanksWithNumberOfCallsPerDayMoreThan(int highlightHeavyRanksWithNumberOfCallsPerDayMoreThan) {
		this.highlightHeavyRanksWithNumberOfCallsPerDayMoreThan = highlightHeavyRanksWithNumberOfCallsPerDayMoreThan;
	}

	public boolean isSystemUseSingleColour() {
		return systemUseSingleColour;
	}

	public void setSystemUseSingleColour(boolean systemUseSingleColour) {
		this.systemUseSingleColour = systemUseSingleColour;
	}

	public int getAccessLogGroupApiCallsByPathDepth() {
		return accessLogGroupApiCallsByPathDepth;
	}

	public void setAccessLogGroupApiCallsByPathDepth(int accessLogGroupApiCallsByPathDepth) {
		this.accessLogGroupApiCallsByPathDepth = accessLogGroupApiCallsByPathDepth;
	}

	public LocalDateTime getCollectDateTimeStart() {
		return collectDateTimeStart;
	}

	public void setCollectDateTimeStart(LocalDateTime collectDateTimeStart) {
		this.collectDateTimeStart = collectDateTimeStart;
	}

	public LocalDateTime getCollectDateTimeEnd() {
		return collectDateTimeEnd;
	}

	public void setCollectDateTimeEnd(LocalDateTime collectDateTimeEnd) {
		this.collectDateTimeEnd = collectDateTimeEnd;
	}

	public int getSeismoXFuseJiraLogDataPointsToChartSlabSeconds() {
		return seismoXFuseJiraLogDataPointsToChartSlabSeconds;
	}

	public void setSeismoXFuseJiraLogDataPointsToChartSlabSeconds(int seismoXFuseJiraLogDataPointsToChartSlabSeconds) {
		this.seismoXFuseJiraLogDataPointsToChartSlabSeconds = seismoXFuseJiraLogDataPointsToChartSlabSeconds;
	}

	public int getSeismoMinNumberOfEventsPerSlabToPersist() {
		return seismoMinNumberOfEventsPerSlabToPersist;
	}

	public void setSeismoMinNumberOfEventsPerSlabToPersist(int seismoMinNumberOfEventsPerSlabToPersist) {
		this.seismoMinNumberOfEventsPerSlabToPersist = seismoMinNumberOfEventsPerSlabToPersist;
	}

	public Long getSeismoChartTimeSpanMinutes() {
		return seismoChartTimeSpanMinutes;
	}

	public void setSeismoChartTimeSpanMinutes(Long seismoChartTimeSpanMinutes) {
		this.seismoChartTimeSpanMinutes = seismoChartTimeSpanMinutes;
	}

	public boolean isSeismoUseJiraDbToPersistData() {
		return seismoUseJiraDbToPersistData;
	}

	public void setSeismoUseJiraDbToPersistData(boolean seismoUseJiraDbToPersistData) {
		this.seismoUseJiraDbToPersistData = seismoUseJiraDbToPersistData;
	}

	public boolean isJiraLogsIsCollectIfStringToFindIsFound() {
		return jiraLogsIsCollectIfStringToFindIsFound;
	}

	public void setJiraLogsIsCollectIfStringToFindIsFound(boolean jiraLogsIsCollectIfStringToFindIsFound) {
		this.jiraLogsIsCollectIfStringToFindIsFound = jiraLogsIsCollectIfStringToFindIsFound;
	}

	public boolean isJiraLogsIsCollectErrorsAndWarnings() {
		return jiraLogsIsCollectErrorsAndWarnings;
	}
	public void setJiraLogsIsCollectErrorsAndWarnings(boolean jiraLogsIsCollectErrorsAndWarnings) {
		this.jiraLogsIsCollectErrorsAndWarnings = jiraLogsIsCollectErrorsAndWarnings;
	}

	public boolean isJiraLogsIsCollectAllLogData() {
		return jiraLogsIsCollectAllLogData;
	}

	public void setJiraLogsIsCollectAllLogData(boolean jiraLogsIsCollectAllLogData) {
		this.jiraLogsIsCollectAllLogData = jiraLogsIsCollectAllLogData;
	}

	public boolean isJiraLogsIsCheckFileMetaData() {
		return jiraLogsIsCheckFileMetaData;
	}

	public void setJiraLogsIsCheckFileMetaData(boolean jiraLogsIsCheckFileMetaData) {
		this.jiraLogsIsCheckFileMetaData = jiraLogsIsCheckFileMetaData;
	}

	public boolean isJiraLogsIsCollectWarnings() {
		return jiraLogsIsCollectWarnings;
	}

	public void setJiraLogsIsCollectWarnings(boolean jiraLogsIsCollectWarnings) {
		this.jiraLogsIsCollectWarnings = jiraLogsIsCollectWarnings;
	}

	public HashSet<String> getCollectIfAccountsAre() {
		return collectIfAccountsAre;
	}

	public void setCollectIfAccountsAre(HashSet<String> collectIfAccountsAre) {
		this.collectIfAccountsAre = collectIfAccountsAre;
	}

	public HashSet<String> getDoNotCollectExcludeIfSubstringsAreFound() {
		return doNotCollectExcludeIfSubstringsAreFound;
	}

	public void setDoNotCollectExcludeIfSubstringsAreFound(HashSet<String> doNotCollectExcludeIfSubstringsAreFound) {
		this.doNotCollectExcludeIfSubstringsAreFound = doNotCollectExcludeIfSubstringsAreFound;
	}

	public boolean isDrawExtraRankBytesSentPerTick() {
		return drawExtraRankBytesSentPerTick;
	}

	public void setDrawExtraRankBytesSentPerTick(boolean drawExtraRankBytesSentPerTick) {
		this.drawExtraRankBytesSentPerTick = drawExtraRankBytesSentPerTick;
	}

	public boolean isDrawCompressedAndHandPickedRanksAndRelatedDetailes() {
		return drawCompressedAndHandPickedRanksAndRelatedDetailes;
	}

	public void setDrawCompressedAndHandPickedRanksAndRelatedDetailes(boolean drawCompressedAndHandPickedRanksAndRelatedDetailes) {
		this.drawCompressedAndHandPickedRanksAndRelatedDetailes = drawCompressedAndHandPickedRanksAndRelatedDetailes;
	}

	public int getRankThresholdBytesSent() {
		return rankThresholdBytesSent;
	}

	public void setRankThresholdBytesSent(int rankThresholdBytesSent) {
		this.rankThresholdBytesSent = rankThresholdBytesSent;
	}

	public Long getChartThresholdEvents() {
		return chartThresholdEvents;
	}

	public void setChartThresholdEvents(Long chartThresholdEvents) {
		this.chartThresholdEvents = chartThresholdEvents;
	}

	public Long getChartThresholdBytesSent() {
		return chartThresholdBytesSent;
	}

	public void setChartThresholdBytesSent(Long chartThresholdBytesSent) {
		this.chartThresholdBytesSent = chartThresholdBytesSent;
	}

	public Long getChartThresholdExecutionTimesSec() {
		return chartThresholdExecutionTimesSec;
	}

	public void setChartThresholdExecutionTimesSec(Long chartThresholdExecutionTimesSec) {
		this.chartThresholdExecutionTimesSec = chartThresholdExecutionTimesSec;
	}

	
	
	
}
