package jira_log_analyzer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.attribute.FileTime;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.TreeMap;
import java.time.LocalDate;

import org.apache.commons.io.input.ReversedLinesFileReader; // https://commons.apache.org/proper/commons-io/download_io.cgi ~~Download Apache Commons IO commons-io-2.15.1.jar
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import jira_log_analyzer.EpLogAnalyzer.EnumReportKind;
import jira_log_analyzer.EpLogAnalyzer.EnumSeverity;
import pojo.PojoJiraLogRowData;
import pojo.PojoJsonSystemSettingsFile;

public class UtilsLogsSys {

	private final static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

	///~~ Load settings ~~
	private final String readFile(String aFileName) {
		StringBuilder _sb = new StringBuilder("");
		try (BufferedReader _br = new BufferedReader(new FileReader(aFileName))) {
			String _line = "";
			while (_line != null) {
				_line = _br.readLine();
				if (_line != null) {
					_sb.append(_line);
				}
			}
		} catch (FileNotFoundException e) {
			// e.printStackTrace();
		} catch (IOException e) {
			// e.printStackTrace();
		}
		return _sb.toString();
	}
	
	public final TreeMap<Long, PojoJiraLogRowData> pullFewLastLinesFromJiraLog(String aParamAnyJiraLogFile, int aNumberOfTheLinesBottomUp, LocalDateTime toTime, Long aSecondsToThePastFromNow, int aLogType, Integer aLowestSeverity) {
		///~~~ File system ~~~
		ParseSlowQueriesLog parseSlowQueriesLog = new ParseSlowQueriesLog();
		ParseJiraAndAccessLogs parseJiraAndAccessLogs = new ParseJiraAndAccessLogs(null);

		TreeMap<Long, PojoJiraLogRowData> result = new TreeMap<Long, PojoJiraLogRowData>();
		try (ReversedLinesFileReader reader = new ReversedLinesFileReader(new File(aParamAnyJiraLogFile), StandardCharsets.UTF_8)) {
			String aFullLine = "";
			LocalDateTime fromTime = null;
			if (toTime != null) {
				fromTime = toTime.plusSeconds(-aSecondsToThePastFromNow); //~~Get some log lines from the near past	
			}
			//toTime = toTime.plusSeconds(aSecondsToThePastFromNow); //~~Get some log lines from the near future -- No point to do that, use just current time
			while ((aFullLine = reader.readLine()) != null && result.size() < aNumberOfTheLinesBottomUp) {
				if (isThisLooksLikeTimeStampedReportLine(aFullLine)) {
					PojoJiraLogRowData jiraLogRow = null;
					if (aLogType == EnumReportKind.JiraLog.getRepKindCode()) {
						LocalDateTime _logDateTime = parseJiraAndAccessLogs.parseJiraLogRowDateTimeStamp(aFullLine, aLogType);
						if (_logDateTime != null) {
							///System.out.println("info100 Jira Log line to parse" ); ///DEBUG
							Long _logLineTimeMsec = parseJiraAndAccessLogs.parseJiraLogRowDateTimeMsec(_logDateTime);
							jiraLogRow = parseJiraAndAccessLogs.parseAtlassianJiraLogRow(aFullLine);
							if (jiraLogRow.getSeverityLevel() != null && jiraLogRow.getSeverityLevel().length() > 0) {
								if (jiraLogRow.getSeverityLevel().compareTo(EnumSeverity.TRACE.toString()) == 0 && aLowestSeverity > EnumSeverity.TRACE.getRepKindCode() // 1
										|| jiraLogRow.getSeverityLevel().compareTo(EnumSeverity.DEBUG.toString()) == 0 && aLowestSeverity > EnumSeverity.DEBUG.getRepKindCode() // 2
										|| jiraLogRow.getSeverityLevel().compareTo(EnumSeverity.INFO.toString()) == 0 && aLowestSeverity > EnumSeverity.INFO.getRepKindCode() // 3
										|| jiraLogRow.getSeverityLevel().compareTo(EnumSeverity.WARN.toString()) == 0 && aLowestSeverity > EnumSeverity.WARN.getRepKindCode() // 4
										|| jiraLogRow.getSeverityLevel().compareTo(EnumSeverity.ERROR.toString()) == 0 && aLowestSeverity > EnumSeverity.ERROR.getRepKindCode() //5
										|| jiraLogRow.getSeverityLevel().compareTo(EnumSeverity.FATAL.toString()) == 0 && aLowestSeverity > EnumSeverity.FATAL.getRepKindCode()) { // 6
									jiraLogRow = null; //~ DO NOT Add to the SeismoLog 'INFO', 'WARN', etc.
								} else { //~~ Add to the SeismoLog ERROR, FATAL,etc.
									jiraLogRow.setFullOriginalLine(aFullLine);
									jiraLogRow.setLocalDateTime(_logDateTime);
									jiraLogRow.setLocalDateTimeMsec(_logLineTimeMsec);
								}
							} else {
								jiraLogRow = null; //~ DO NOT Add to the SeismoLog 'INFO', 'WARN', etc.
							}
							///System.out.println("info100 Jira Log line parsed" ); ///DEBUG
						}
					} else if (aLogType == EnumReportKind.SlowQuery.getRepKindCode()) {
						jiraLogRow = parseSlowQueriesLog.parseSlowQueryLogLine(aFullLine, aParamAnyJiraLogFile);
					} else if (aLogType == EnumReportKind.AtlassianJiraPerfLog.getRepKindCode()) {
						// jiraLogRow = parseJiraPerfLog.parseJiraPerfLogLine(aFullLine, aParamAnyJiraLogFile); // TODO
					}
					if (jiraLogRow != null) {
						///~NOTE: Condition 'toTime == null' allows to collect ANY data (e.g. for debugging)
						if (toTime == null || jiraLogRow.getLocalDateTime().isAfter(fromTime) && jiraLogRow.getLocalDateTime().isBefore(toTime)) {
							//System.out.print("t "); ///DEBUG Latest, Use it
							if (jiraLogRow.getLocalDateTimeMsec() != null) {
								result.put(jiraLogRow.getLocalDateTimeMsec(), jiraLogRow);
							} else {
								System.err.println("err045 in: " + jiraLogRow.getFullOriginalLine()); ///DEBUG	
							}
						} else {
							//System.err.print("f "); ///DEBUG     
							///break; //~~This log line is too old, exit loop when found first from the bottom older log line, because next and rest of the lines will be even older 
						}
						//System.out.println(this.getClass().getName() + " from\n\t" + fromTime + " it\n\t" + jiraLogRow.getLocalDateTime() + " to\n\t" + toTime); ///DEBUG
					}
				}
			}
			///System.out.println("Log read completed"); ///DEBUG
		} catch (IOException e) {
			//e.printStackTrace();
		}
		return result;
	}

	public static final String sanitizeString(String aStr) {
		String _s = aStr;
		if (aStr != null) {
			_s = _s.replace("\t", " ");
			_s = _s.replace("\r", "");
			_s = _s.replace("\n", "");
		}
		return _s;
	}

	public final LocalDateTime extractToLocalDateTime(String aDateInString) { // ~~ 2021-10-19 08:57:54,340 ~~ Refactored from 'getLocalDateTime'
		// ~~ [28]: 2021-10-19 08:57:54,340-0400
		// ~~ [23]: 2021-10-19 08:57:54,340
		// ~~ [10]: 2021-10-19
		LocalDateTime dateTime = null;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss,SSS");
		if (aDateInString != null) {
			aDateInString = aDateInString.trim();
			//System.out.println("~SP34280 DateTime: '" + aDateInString + "' " + aDateInString.length());
			try {
				if (aDateInString.length() == 10) { // ~~ 2021-10-19
					dateTime = LocalDateTime.parse(aDateInString + " 00:00:00,000", formatter);
				} else if (aDateInString.length() == 23) { // ~~ 2021-10-19 08:57:54,340
					dateTime = LocalDateTime.parse(aDateInString, formatter);
				} else {
					//System.err.println("~SP34287 Wrong DateTime: '" + aDateInString + "'");
					return null;
				}
			} catch (Exception e) {
				//System.err.println("~SP34280 Wrong DateTime: '" + aDateInString + "' [" + aDateInString.length() + "]");
				return null;
			}
		}
		return dateTime;
	}
	
	final boolean isThisLooksLikeTimeStampedReportLine(String aFullLine) {
		if (aFullLine != null && aFullLine.length() > 26 && aFullLine.substring(0, 1).compareTo(" ") != 0 && aFullLine.substring(0, 1).compareTo("\t") != 0) {
			return true;
		} else {
			return false;
		}
	}
	
	public final LocalDateTime formatDateTime(FileTime fileTime) {
		// DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
		//LocalDateTime localDateTime = fileTime.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
		LocalDateTime localDateTime = fileTime.toInstant().atZone(ZoneId.of("UTC")).toLocalDateTime();
		// return localDateTime.format(DATE_FORMATTER);
		return localDateTime;
	}
	
	public final String formatDateTimeFromMs(Long aMs) {
		///~~ Make DateTime from ms
		///~~ DateFormat obj = new SimpleDateFormat("dd MMM yyyy HH:mm:ss:SSS Z");   
		DateFormat obj = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		String dateTimeFormatted = obj.format(aMs);
		return dateTimeFormatted;
	}

	public final String formatDateTimeAsString(LocalDateTime localDate) {
		String dateAsString = null;
		if (localDate != null) {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			dateAsString = localDate.format(formatter);
		}
		return dateAsString;
	}

	public final LocalDate getLocalDate(String aDateInString) { // ~~ '2021-12-31' ~~
		LocalDate dateTime = null;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		try {
			dateTime = LocalDate.parse(aDateInString, formatter);
		} catch (Exception e) {
			// e.printStackTrace();
		}
		return dateTime;
	}

	public final LocalDateTime getLocalDateTimeShort(String aDateInString) { // ~~ '04/Jun/2021:00:02:00' ~~
		// ~~ File: 'access_log.2021-08-11'
		// ~~ 127.0.0.1 464x2x2 - [12/Aug/2021:07:44:35 -0400] "GET /rest/auditing/latest/statistics/database/usage- HTTP/1.1" 200 55 3588 "-" "Apache-HttpClient/4.5.13 (Java/1.8.0_201)" "-"
		LocalDateTime dateTime = null;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MMM/yyyy:HH:mm:ss");
		try {
			dateTime = LocalDateTime.parse(aDateInString, formatter);
		} catch (Exception e) {
			// e.printStackTrace();
		}
		return dateTime;
	}

	public final LocalDateTime getDateCatalinaLog(String aDateInString) { // ~~ 29-Sep-2021 09:49:32.694 ~~
		// ~~ 29-Sep-2021 09:49:32.694 INFO [main] org.apache.catalina.startup.VersionLoggerListener.log Server version name:   Apache Tomcat/8.5.65
		LocalDateTime dateTime = null;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm:ss.SSS");
		// System.out.println("aDateInString: " + aDateInString);
		try {
			dateTime = LocalDateTime.parse(aDateInString, formatter);
		} catch (Exception e) {
			// e.printStackTrace();
		}
		return dateTime;
	}

	public final PojoJsonSystemSettingsFile getSysSettings(String aJiraLogAnalyzerSettingsFileName) {
		PojoJsonSystemSettingsFile sysSettings = null;
		JSONParser jsonParser = new JSONParser(); //--Non-Standard custom JSON file to keep Settings
		String jsn = readFile(aJiraLogAnalyzerSettingsFileName);
		try {
			JSONObject obj = (JSONObject) jsonParser.parse(jsn);
			sysSettings = new PojoJsonSystemSettingsFile();
			sysSettings.setInDirJiraApplicationLogs(obj.get("inDirJiraApplicationLogs").toString());
			sysSettings.setInDirJiraHomeLogs(obj.get("inDirJiraHomeLogs").toString());
			sysSettings.setOutDirReports(obj.get("outDirReports").toString());
			sysSettings.setDbDriver(obj.get("db_driver").toString());
			sysSettings.setDbHost(obj.get("db_host").toString());
			sysSettings.setDbPortNumber(obj.get("db_portNumber").toString());
			sysSettings.setDbName(obj.get("db_name").toString());
			sysSettings.setDbUsername(obj.get("db_username").toString());
			sysSettings.setDbPassword(obj.get("db_password").toString());
			sysSettings.setDbEnableSsl((boolean) obj.get("db_enable_ssl"));
			sysSettings.setUseJiraDbSearchRequest((boolean) obj.get("useJiraDbSearchRequest"));

			sysSettings.setReadAtlassianJiraLog((boolean) obj.get("readAtlassianJiraLog"));
			sysSettings.setReadSlowJqlLog((boolean) obj.get("readSlowJqlLog"));
			sysSettings.setReadCatalinaLog((boolean) obj.get("readCatalinaLog"));
			sysSettings.setReadAccessLog((boolean) obj.get("readAccessLog"));

			sysSettings.setJiraLogsIsCollectAllLogData((boolean) obj.get("jiraLogs.isCollectAllLogData"));
			sysSettings.setJiraLogsIsCollectIfStringToFindIsFound((boolean) obj.get("jiraLogs.isCollectIfStringToFindIsFound"));
			sysSettings.setJiraLogsIsCollectErrorsAndWarnings((boolean) obj.get("jiraLogs.isCollectErrorsAndWarnings"));
			sysSettings.setJiraLogsIsCollectWarnings((boolean) obj.get("jiraLogs.isCollectWarnings"));

			sysSettings.setDrawAtlassianJiraLog((boolean) obj.get("drawAtlassianJiraLog"));
			sysSettings.setDrawSlowJqlLog((boolean) obj.get("drawSlowJqlLog"));
			sysSettings.setDrawCatalinaLog((boolean) obj.get("drawCatalinaLog"));
			sysSettings.setDrawAccessLog((boolean) obj.get("drawAccessLog"));

			sysSettings.setDrawCompressedAndHandPickedRanksOnly((boolean) obj.get("drawCompressedAndHandPickedRanksOnly"));
			sysSettings.setDrawCompressedAndHandPickedRanksAndRelatedDetailes((boolean) obj.get("drawCompressedAndHandPickedRanksAndRelatedDetailes"));

			sysSettings.setDrawExtraRankBytesSentPerTick((boolean) obj.get("drawExtraRankBytesSentPerTick"));
			sysSettings.setGroupMessagesOption(Integer.parseInt(obj.get("groupMessagesOption").toString()));

			sysSettings.setSystemUseSingleColour((boolean) obj.get("system.useSingleColour"));
			sysSettings.setAccessLogExtractRestApiCallsOnly((boolean) obj.get("accessLog.extractRestApiCallsOnly"));
			sysSettings.setAccessLogRequiredRestApiRequestMethod(obj.get("accessLog.requiredRestApiRequestMethod").toString());
			sysSettings.setAccessLogGroupApiCallsByExecutionTime((boolean) obj.get("accessLog.groupApiCallsByExecutionTime"));
			sysSettings.setAccessLogGroupApiCallsByPathDepth(Integer.parseInt(obj.get("accessLog.groupApiCallsByPathDepth").toString()));

			sysSettings.setRankThresholdEvents(Integer.parseInt(obj.get("rankThresholdEvents").toString()));
			sysSettings.setRankThresholdBytesSent(Integer.parseInt(obj.get("rankThresholdBytesSent").toString()));
			sysSettings.setRankThresholdExecutionTimesSec(Integer.parseInt(obj.get("rankThresholdExecutionTimesSec").toString()));

			sysSettings.setChartThresholdEvents(Long.parseLong(obj.get("chartThresholdEvents").toString()));
			sysSettings.setChartThresholdBytesSent(Long.parseLong(obj.get("chartThresholdBytesSent").toString()));
			sysSettings.setChartThresholdExecutionTimesSec(Long.parseLong(obj.get("chartThresholdExecutionTimesSec").toString()));

			sysSettings.setHighlightHeavyRanksWithNumberOfCallsPerDayMoreThan(Integer.parseInt(obj.get("highlightHeavyRanksWithNumberOfCallsPerDayMoreThan").toString()));
			sysSettings.setHighlightHeavyRanksWithSumExecutionTimeGreaterThanMin(Integer.parseInt(obj.get("highlightHeavyRanksWithSumExecutionTimeGreaterThanMin").toString()));

			sysSettings.setExcludeNonHumanAccounts((boolean) obj.get("excludeNonHumanAccounts"));

			JSONArray ja1 = (JSONArray) obj.get("collectIfAccountsAre");
			if (ja1 != null) {
				HashSet<String> hs1 = new HashSet<>();
				for (int ii = 0, size = ja1.size(); ii < size; ii++) {
					hs1.add(ja1.get(ii).toString().toLowerCase());
				} ;
				sysSettings.setCollectIfAccountsAre(hs1);
			}

			ja1 = (JSONArray) obj.get("collectIfTheseSubstringsAreFound");
			if (ja1 != null) {
				HashSet<String> hs1 = new HashSet<>();
				for (int ii = 0, size = ja1.size(); ii < size; ii++) {
					hs1.add(ja1.get(ii).toString().toLowerCase());
				} ;
				sysSettings.setCollectIfTheseSubstringsAreFound(hs1);
			}

			ja1 = (JSONArray) obj.get("doNotCollectExcludeIfSubstringsAreFound");
			if (ja1 != null) {
				HashSet<String> hs1 = new HashSet<>();
				for (int ii = 0, size = ja1.size(); ii < size; ii++) {
					hs1.add(ja1.get(ii).toString().toLowerCase());
				} ;
				sysSettings.setDoNotCollectExcludeIfSubstringsAreFound(hs1);
			}

			sysSettings.setReportAllAccessLogRecordsNotErrorsOnly((boolean) obj.get("reportAllAccessLogRecordsNotErrorsOnly"));

			LocalDateTime collectDateTime = LocalDateTime.parse(obj.get("collectDateTimeStart").toString(), formatter);
			sysSettings.setCollectDateTimeStart(collectDateTime);
			collectDateTime = LocalDateTime.parse(obj.get("collectDateTimeEnd").toString(), formatter);
			sysSettings.setCollectDateTimeEnd(collectDateTime);
			sysSettings.setJiraLogsIsCheckFileMetaData((boolean) obj.get("jiraLogs.isCheckFileMetaData"));

			//sysSettings.setShiftHrs(Long.parseLong(obj.get("shiftHrs").toString()));
			sysSettings.setRankSizeHrs(Integer.parseInt(obj.get("rankSizeHrs").toString()));
			sysSettings.setTickSizeMinutes(Integer.parseInt(obj.get("tickSizeMinutes").toString()));
			//~~ Seismo ~~
			sysSettings.setSeismoUseJiraDbToPersistData((boolean) obj.get("seismo.useJiraDbToPersistData"));
			sysSettings.setSeismoChartTimeSpanMinutes(Long.parseLong(obj.get("seismo.chartTimeSpanMinutes").toString()));
			sysSettings.setSeismoXFuseJiraLogDataPointsToChartSlabSeconds(Integer.parseInt(obj.get("seismo.xFuseJiraLogDataPointsToChartSlabSeconds").toString()));
			sysSettings.setSeismoMinNumberOfEventsPerSlabToPersist(Integer.parseInt(obj.get("seismo.minNumberOfEventsPerSlabToPersist").toString()));

		} catch (org.json.simple.parser.ParseException e) {
			// e.printStackTrace();
		}
		return sysSettings;
	}

	public final String formatDateAsString(LocalDateTime localDate) {
		String dateAsString = null;
		if (localDate != null) {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
			dateAsString = localDate.format(formatter);
		}
		return dateAsString;
	}

	///~~~ File system ~~~
	public final boolean isTheFileFound(String aFilePath) {
		if (aFilePath != null && aFilePath.length() > 0) {
			try {
				File fl = new File(aFilePath);
				if (!fl.exists()) {
					//~~ The directory does not exist.
					return false;
				} else if (!fl.isDirectory()) {
					//~~ It is not a directory (i.e. it is a file).
					return true;
				}
			} catch (Exception e) {
			}
		}
		return false;
	}
	
	public final void saveChartLegendLabels(String aStringToSave, PojoJsonSystemSettingsFile aSSet, String aFilePrefixDate) {
		//~~ Compact list of users with resources consumed during a day ~~ 
		if (aStringToSave != null) {
			String path = aSSet.getOutDirReports() + "/" + aFilePrefixDate + " ChartLabels.csv";
			try {
				Files.write(Paths.get(path), aStringToSave.getBytes());
			} catch (IOException e) {
				e.printStackTrace();
			}
			//System.out.println("ChartLabels saved to: '" + path + "'\n");
			//System.out.println("\n~~Compact list of users with resources consumed during a day saved:\n" + path); ///DEBUG
		}
	}

	///~~~ Test Run ~~~
	private final void UNUSED_TEST_METHOD() { ///DEBUG
		if (!false) { ///DEBUG pullFewLastLinesFromJiraLog()
			String aParamAnyJiraLogFile = "C:/Tmp/log/atlassian-jira-slow-queries.log"; ///DEBUG
			int numberOfTheLinesBottomUp = 10; ///DEBUG
			Long secondsToThePastFromNow = 100 * 60L; ///DEBUG
			LocalDateTime toTime = LocalDateTime.now();
			TreeMap<Long, PojoJiraLogRowData> lines = pullFewLastLinesFromJiraLog(aParamAnyJiraLogFile, numberOfTheLinesBottomUp, toTime, secondsToThePastFromNow, EnumReportKind.SlowQuery.getRepKindCode(), 4); ///DEBUG
			System.out.println("Exctracted last log lines:"); ///DEBUG
			lines.forEach((Long key, PojoJiraLogRowData itm) -> System.out.println(itm.getFullOriginalLine())); ///DEBUG
		} ///DEBUG
	} ///DEBUG

	//	public static void main(String[] args) { ///DEBUG
	//		if (false) { ///DEBUG
	//			new UtilsLogsSys().UNUSED_TEST_METHOD(); ///DEBUG
	//		} ///DEBUG
	//	} ///DEBUG

}
