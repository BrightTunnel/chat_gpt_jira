package jira_log_analyzer;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.TreeMap;

import jira_log_analyzer.EpLogAnalyzer.EnumReportKind;
import jira_log_analyzer.EpLogAnalyzer.EnumSeverity;
import pojo.PojoJiraLogRowData;
import serviceForLogParser.ConstantsOfJiraLogs;

public class UtilsLogsParsing {

	/// ~~ Set of specific utils to support Jira logs parsing and reporting
	private final static String chartSectionPrefixOfCompressedReportLinesWithError = "!"; // e.g.: !err !ERR
	private final static String httpErrorCode = "!http:";
	private final static String chartSectionPrefixOfCompressedReportLinesWithSubstring = "#has";
	private final static String theSourceLogKey = ".in:"; // --From the log type: atlassian-jira.log, atlassian-jira-slow-queries.log, etc.
	private final static String responsibleUserWhoKey = "usr:";
	public final static Long jiraLogValueUnavailable = -7L; // ~~ Note -7L is used as indicator of unavailability

	TreeMap<Long, TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>> reMap(TreeMap<String, TreeMap<Long, TreeMap<Long, PojoJiraLogRowData>>> aUsr) {
		TreeMap<Long, TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>> daysUsersItems = new TreeMap<Long, TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>>();
		Iterator<Entry<String, TreeMap<Long, TreeMap<Long, PojoJiraLogRowData>>>> usersIter = aUsr.entrySet().iterator();
		while (usersIter.hasNext()) {
			Entry<String, TreeMap<Long, TreeMap<Long, PojoJiraLogRowData>>> usersKeyValue = usersIter.next();
			Iterator<Entry<Long, TreeMap<Long, PojoJiraLogRowData>>> daysIter = usersKeyValue.getValue().entrySet().iterator();
			while (daysIter.hasNext()) {
				Entry<Long, TreeMap<Long, PojoJiraLogRowData>> dayKeyValue = daysIter.next();
				TreeMap<Long, PojoJiraLogRowData> rankData = dayKeyValue.getValue();
				if (daysUsersItems.containsKey(dayKeyValue.getKey())) {
					TreeMap<String, TreeMap<Long, PojoJiraLogRowData>> _usersKeyValue = daysUsersItems.get(dayKeyValue.getKey());
					if (_usersKeyValue.containsKey(usersKeyValue.getKey())) {
						TreeMap<Long, PojoJiraLogRowData> _rankKeyValue = _usersKeyValue.get(usersKeyValue.getKey());
						Iterator<Entry<Long, PojoJiraLogRowData>> itemsKeyValue = rankData.entrySet().iterator();
						while (itemsKeyValue.hasNext()) {
							Entry<Long, PojoJiraLogRowData> itemKeyValue = itemsKeyValue.next();
							PojoJiraLogRowData itemValue = itemKeyValue.getValue();
							_rankKeyValue.put(itemKeyValue.getKey(), itemValue);
						}
					} else {
						_usersKeyValue.put(usersKeyValue.getKey(), rankData);
					}
				} else {
					TreeMap<String, TreeMap<Long, PojoJiraLogRowData>> usersData = new TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>();
					TreeMap<Long, PojoJiraLogRowData> rf = rankData;
					// int size = dayKeyValue.getValue().size();
					// usersData.put(size + " "+ usersKeyValue.getKey(), rf);
					usersData.put(usersKeyValue.getKey(), rf);
					daysUsersItems.put(dayKeyValue.getKey(), usersData);
				}
			}
		}
		if (EpLogAnalyzer.SysSetngs.isDrawCompressedAndHandPickedRanksOnly()) {
			daysUsersItems = addEventsCountToTheKey(daysUsersItems);
		}
		return daysUsersItems;
	}

	private TreeMap<Long, TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>> addEventsCountToTheKey(TreeMap<Long, TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>> aDaysUsersItems) {
		// ~~ When drawing Errors only, add to the Map key a number of errors (events) in reverse order, so you will see users with most errors on top ~~
		TreeMap<Long, TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>> daysUsersItemsNew = new TreeMap<Long, TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>>();
		Iterator<Entry<Long, TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>>> daysIter = aDaysUsersItems.entrySet().iterator();
		while (daysIter.hasNext()) {
			TreeMap<String, TreeMap<Long, PojoJiraLogRowData>> userKeyValueNew = new TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>();
			Entry<Long, TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>> usersKeyValue = daysIter.next();
			Iterator<Entry<String, TreeMap<Long, PojoJiraLogRowData>>> rankIter = usersKeyValue.getValue().entrySet().iterator();
			while (rankIter.hasNext()) {
				Entry<String, TreeMap<Long, PojoJiraLogRowData>> userKeyValue = rankIter.next();
				String numberOfEventsAddToKeyToSort = String.format("%010d ", 9999999999L - userKeyValue.getValue().size());
				userKeyValueNew.put(numberOfEventsAddToKeyToSort + userKeyValue.getKey(), userKeyValue.getValue());
				daysUsersItemsNew.put(usersKeyValue.getKey(), userKeyValueNew);
			}
		}
		return daysUsersItemsNew;
	}

	void calculateSumOfAllResourcesUsedPerUserAccountRank(TreeMap<Long, TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>> aDaysUsersItems) {
		Iterator<Entry<Long, TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>>> daysIter = aDaysUsersItems.entrySet().iterator();
		while (daysIter.hasNext()) {
			Long _eventsCountPerDayAllRanks = 0L;
			Long _eventsCountMaxPerDayAllRanks = 0L;
			Long _bytesSentPerDayAllRanks = 0L;
			Long _bytesSentMaxPerDayAllRanks = 0L;
			Long _executionTimePerDayAllRanksMSec = 0L;
			Long _executionTimeMaxPerDayAllRanksMSec = 0L;
			Entry<Long, TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>> daySection = daysIter.next();
			Iterator<Entry<String, TreeMap<Long, PojoJiraLogRowData>>> daySectionIterator = daySection.getValue().entrySet().iterator();
			while (daySectionIterator.hasNext()) {
				Entry<String, TreeMap<Long, PojoJiraLogRowData>> userAccountRank = daySectionIterator.next();
				// int numberOfEventsAddToKeyToSort = userKeyValue.getValue().size(); //~~ may be used, good place to calculate it
				// ~~ Calculate sum of the all rank events execution time
				Long eventsCountPerDayPerRank = 0L;
				Long _bytesSentSumPerUserAccountRank = 0L;
				Long _executionTimeSumPerUserAccountRank = 0L;
				/// ~~ Loop data for the user account:
				Iterator<Entry<Long, PojoJiraLogRowData>> dataPointIter = userAccountRank.getValue().entrySet().iterator();
				while (dataPointIter.hasNext()) {
					Entry<Long, PojoJiraLogRowData> dataPoint = dataPointIter.next();
					if (dataPoint.getValue().getEventsCountDataPoint() != null) {
						eventsCountPerDayPerRank += dataPoint.getValue().getEventsCountDataPoint(); // ~~ including duplicates with the same log time
					}
					if (dataPoint.getValue().getBytesSentDataPoint() != null) {
						_bytesSentSumPerUserAccountRank += dataPoint.getValue().getBytesSentDataPoint();
					}
					if (dataPoint.getValue().getExecutionTimeDataPointMSec() != null) {
						_executionTimeSumPerUserAccountRank += dataPoint.getValue().getExecutionTimeDataPointMSec();
					}
				}
				if (userAccountRank.getValue().firstEntry() != null) {
					/// ~~~ Save first and last logged events this day for this user account rank
					PojoJiraLogRowData uafe = userAccountRank.getValue().firstEntry().getValue();
					uafe.setUserAccountFirstEventThisDay(uafe.getLocalDateTime());
					uafe.setUserAccountLastEventThisDay(userAccountRank.getValue().lastEntry().getValue().getLocalDateTime());
					/// ~~~ Save number of events/log lines this day form this user account
					uafe.setEventsCountPerDayPerRank(eventsCountPerDayPerRank);
					_eventsCountPerDayAllRanks += eventsCountPerDayPerRank;
					/// ~~~ Save byte sent this day form this user account
					uafe.setBytesSentPerDayPerRank(_bytesSentSumPerUserAccountRank);
					_bytesSentPerDayAllRanks += _bytesSentSumPerUserAccountRank;
					/// ~~~ Save overall execution Time this day by this user account
					uafe.setExecutionTimePerDayPerRankMSec(_executionTimeSumPerUserAccountRank);
					_executionTimePerDayAllRanksMSec += _executionTimeSumPerUserAccountRank;
				}
			}
			if (daySection.getValue().firstEntry().getValue().firstEntry() != null) {
				daySection.getValue().firstEntry().getValue().firstEntry().getValue().setEventsCountPerDayAllRanks(_eventsCountPerDayAllRanks);
				daySection.getValue().firstEntry().getValue().firstEntry().getValue().setEventsCountMaxPerDayAllRanks(_eventsCountMaxPerDayAllRanks);
				daySection.getValue().firstEntry().getValue().firstEntry().getValue().setBytesSentPerDayAllRanks(_bytesSentPerDayAllRanks);
				daySection.getValue().firstEntry().getValue().firstEntry().getValue().setBytesSentMaxPerDayAllRanks(_bytesSentMaxPerDayAllRanks);
				daySection.getValue().firstEntry().getValue().firstEntry().getValue().setExecutionTimePerDayAllRanksMSec(_executionTimePerDayAllRanksMSec);
				daySection.getValue().firstEntry().getValue().firstEntry().getValue().setExecutionTimeMaxPerDayAllRanksMSec(_executionTimeMaxPerDayAllRanksMSec);
			}
		}
	}

	Long[][] calculateDayRankSummaryPerTickTimeFrame(TreeMap<String, TreeMap<Long, PojoJiraLogRowData>> aRankData, Long aDay) {
		Iterator<Entry<String, TreeMap<Long, PojoJiraLogRowData>>> _rankDataIter = aRankData.entrySet().iterator();
		Long[][] _calculatedDayRank = new Long[4][EpLogAnalyzer.rankTicksCount];
		int indexDayEvents = 0; // ~~ Subarray of all events for a day
		int indexDayErrors = 1; // ~~ Subarray of all errors for a day
		int indexDayBytesSent = 2; // ~~ Subarray of all bytes sent at that tick time of the day
		int indexDayHttpTime = 3; // ~~ Subarray of all http request execution time
		int _tickPrev = 0;
		int _tickNext;
		for (int ii = 0; ii < EpLogAnalyzer.rankTicksCount; ii++) {
			_calculatedDayRank[indexDayEvents][ii] = 0L;
			_calculatedDayRank[indexDayErrors][ii] = 0L;
			_calculatedDayRank[indexDayBytesSent][ii] = 0L;
			_calculatedDayRank[indexDayHttpTime][ii] = 0L;
		}
		while (_rankDataIter.hasNext()) {
			Entry<String, TreeMap<Long, PojoJiraLogRowData>> _userKeyDataRank = _rankDataIter.next();
			TreeMap<Long, PojoJiraLogRowData> _userDataRank = _userKeyDataRank.getValue();
			if (_userDataRank != null) {
				Iterator<Entry<Long, PojoJiraLogRowData>> _userDataRankIter = _userDataRank.entrySet().iterator();
				while (_userDataRankIter.hasNext()) {
					Entry<Long, PojoJiraLogRowData> _userKeyDataPoint = _userDataRankIter.next();
					PojoJiraLogRowData _userDataPoint = _userKeyDataPoint.getValue();
					Long _tickNextLong = (_userDataPoint.getLocalDateTimeMsec() - aDay) / 1000 / 60 / EpLogAnalyzer.SysSetngs.getTickSizeMinutes();
					_tickNext = _tickNextLong.intValue();
					// System.out.println(_tickNext + " " + _tickPrev + " " + _userDataPoint.getFullOriginalLine());
					if (_tickPrev == _tickNext) {
					} else {
						_tickPrev = _tickNext;
					}
					_calculatedDayRank[indexDayEvents][_tickPrev] = _calculatedDayRank[indexDayEvents][_tickPrev] + 1;
					if (ifSeverityLevelIsAnError(_userDataPoint.getSeverityLevel())) {
						_calculatedDayRank[indexDayErrors][_tickPrev] = _calculatedDayRank[indexDayErrors][_tickPrev] + 1;
					}
					if (_userDataPoint.getBytesSentDataPoint() != null) {
						_calculatedDayRank[indexDayBytesSent][_tickPrev] = _calculatedDayRank[indexDayBytesSent][_tickPrev] + _userDataPoint.getBytesSentDataPoint();
					}
					if (_userDataPoint.getExecutionTimeDataPointMSec() != null) {
						_calculatedDayRank[indexDayHttpTime][_tickPrev] = _calculatedDayRank[indexDayHttpTime][_tickPrev] + _userDataPoint.getExecutionTimeDataPointMSec();
					}
				}
			}
		}
		return _calculatedDayRank;
	}

	boolean isSubStringToFindIsPresentInTheRawDataLine(String aRawLine, HashSet<String> aHashSetSubStringsToFind) {
		if (EpLogAnalyzer.SysSetngs.isJiraLogsIsCollectIfStringToFindIsFound() && aRawLine != null && aHashSetSubStringsToFind != null) {
			aRawLine = aRawLine.toLowerCase();
			for (String it : aHashSetSubStringsToFind) {
				if (aRawLine.indexOf(it.toLowerCase()) > -1) {
					return true;
				}
			}
		}
		return false;
	}

	void addSectionOfCompressedRanksWithAccountsToDayRank(TreeMap<String, TreeMap<Long, PojoJiraLogRowData>> aDayRankData, String anThisUserAccount) {
		// ~~ Add subset of compressed ranks to the main 'DictGroupByDateTypeMapped'
		if (anThisUserAccount != null) {
			anThisUserAccount = anThisUserAccount.trim();
			if (anThisUserAccount.length() > 0) {
				anThisUserAccount = anThisUserAccount.toLowerCase();
				TreeMap<String, TreeMap<Long, PojoJiraLogRowData>> subsetPerOwner = new TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>();
				TreeMap<Long, PojoJiraLogRowData> theSubsetPerOwner = null;
				TreeMap<Long, PojoJiraLogRowData> _collectedDataRankHasSubstring = null;
				Iterator<Entry<String, TreeMap<Long, PojoJiraLogRowData>>> _dayRankDataIterator = aDayRankData.entrySet().iterator();
				String _rankKeyOne = "";
				while (_dayRankDataIterator.hasNext()) {
					Entry<String, TreeMap<Long, PojoJiraLogRowData>> _userKeyDataRank = _dayRankDataIterator.next();
					TreeMap<Long, PojoJiraLogRowData> _userDataRank = _userKeyDataRank.getValue();
					if (_userDataRank != null) {
						Iterator<Entry<Long, PojoJiraLogRowData>> _userDataRankIter = _userDataRank.entrySet().iterator();
						while (_userDataRankIter.hasNext()) {
							Entry<Long, PojoJiraLogRowData> _userKeyDataPoint = _userDataRankIter.next();
							PojoJiraLogRowData _userDataPoint = _userKeyDataPoint.getValue();
							if (_userDataPoint.getUserNameFull().compareTo(anThisUserAccount) == 0) {
								HashSet<String> hmTop = EpLogAnalyzer.SysSetngs.getCollectIfAccountsAre();
								_rankKeyOne = chartSectionPrefixOfCompressedReportLinesWithSubstring;
								_rankKeyOne += theSourceLogKey + "'" + EnumReportKind.getKindName(_userDataPoint.getLogKind()) + "'"; // ~~ key has a name of the source log class
								if (hmTop != null && hmTop.contains(anThisUserAccount)) {
									_rankKeyOne += " spyon:'" + anThisUserAccount + "'"; // ~~ Key Starts with '!Has:' to keep the rank at the top
								}
								_rankKeyOne += " " + responsibleUserWhoKey + "'" + _userDataPoint.getUserNameCore() + "'";
								// _rankKey += "[" + ff.firstEntry().getValue().getLogKind() + "]"; //~~ May be and index of above
								// ~~ Change the rank sorting key to the rank in focus, so yes, move this regular rank higher to the top of the set
								_userDataPoint.setKeyUserReportKindSeverity(_rankKeyOne);
								_collectedDataRankHasSubstring = new TreeMap<Long, PojoJiraLogRowData>();
								_collectedDataRankHasSubstring.put(_userKeyDataPoint.getKey(), _userDataPoint);
								theSubsetPerOwner = subsetPerOwner.get(_rankKeyOne);
								if (theSubsetPerOwner == null) {
									theSubsetPerOwner = new TreeMap<Long, PojoJiraLogRowData>();
								}
								theSubsetPerOwner.putAll(_collectedDataRankHasSubstring);
								subsetPerOwner.put(_rankKeyOne, theSubsetPerOwner);
							}
						}
					}
				} // ~~ eof loop this Day data
				if (_collectedDataRankHasSubstring == null || _collectedDataRankHasSubstring.isEmpty()) {
					// return null;
				} else {
					aDayRankData.putAll(subsetPerOwner);
					// return _collectedDataRankHasSubstring;
				}
			}
		}
	}

	void addSectionOfCompressedFilteredRanksToDayRank(TreeMap<String, TreeMap<Long, PojoJiraLogRowData>> aDayRankData, String aSubStringToFind) {
		// ~~ Add subset of compressed ranks to the main 'DictGroupByDateTypeMapped', if orig data lines have subString of interest
		if (EpLogAnalyzer.SysSetngs.isJiraLogsIsCollectIfStringToFindIsFound()) {
			aSubStringToFind = aSubStringToFind.toLowerCase();
			TreeMap<String, TreeMap<Long, PojoJiraLogRowData>> subsetPerOwner = new TreeMap<String, TreeMap<Long, PojoJiraLogRowData>>();
			TreeMap<Long, PojoJiraLogRowData> theSubsetPerOwner = null;
			TreeMap<Long, PojoJiraLogRowData> _collectedDataRankHasSubstring = null;
			Iterator<Entry<String, TreeMap<Long, PojoJiraLogRowData>>> _dayRankDataIterator = aDayRankData.entrySet().iterator();
			String _rankKeyOne = "";
			while (_dayRankDataIterator.hasNext()) {
				Entry<String, TreeMap<Long, PojoJiraLogRowData>> _userKeyDataRank = _dayRankDataIterator.next();
				TreeMap<Long, PojoJiraLogRowData> _userDataRank = _userKeyDataRank.getValue();
				if (_userDataRank != null) {
					Iterator<Entry<Long, PojoJiraLogRowData>> _userDataRankIter = _userDataRank.entrySet().iterator();
					while (_userDataRankIter.hasNext()) {
						Entry<Long, PojoJiraLogRowData> _userKeyDataPoint = _userDataRankIter.next();
						PojoJiraLogRowData _userDataPoint = _userKeyDataPoint.getValue();
						if (_userDataPoint.getFullOriginalLine().toLowerCase().contains(aSubStringToFind)) {
							HashSet<String> hmTop = EpLogAnalyzer.SysSetngs.getCollectIfTheseSubstringsAreFound();
							_rankKeyOne = chartSectionPrefixOfCompressedReportLinesWithSubstring;
							_rankKeyOne += theSourceLogKey + "'" + EnumReportKind.getKindName(_userDataPoint.getLogKind()) + "'"; // ~~ key has a name of the source log class
							if (hmTop != null && hmTop.contains(aSubStringToFind)) {
								_rankKeyOne += ":'" + aSubStringToFind + "'"; // ~~ Key Starts with '!Has:' to keep the rank at the top
							}
							_rankKeyOne += " " + responsibleUserWhoKey + "'" + _userDataPoint.getUserNameCore() + "'";
							// _rankKey += "[" + ff.firstEntry().getValue().getLogKind() + "]"; //~~ May be and index of above
							// ~~ Change the rank sorting key to the rank in focus, so yes, move this regular rank higher to the top of the set
							_userDataPoint.setKeyUserReportKindSeverity(_rankKeyOne);
							_collectedDataRankHasSubstring = new TreeMap<Long, PojoJiraLogRowData>();
							_collectedDataRankHasSubstring.put(_userKeyDataPoint.getKey(), _userDataPoint);
							theSubsetPerOwner = subsetPerOwner.get(_rankKeyOne);
							if (theSubsetPerOwner == null) {
								theSubsetPerOwner = new TreeMap<Long, PojoJiraLogRowData>();
							}
							theSubsetPerOwner.putAll(_collectedDataRankHasSubstring);
							subsetPerOwner.put(_rankKeyOne, theSubsetPerOwner);
						}
					}
				}
			} // ~~ eof loop this Day data
			if (_collectedDataRankHasSubstring == null || _collectedDataRankHasSubstring.isEmpty()) {
				// return null;
			} else {
				aDayRankData.putAll(subsetPerOwner);
				// return _collectedDataRankHasSubstring;
			}
		}
	}

	/// ~~ User Account ~~~
	String extractUserNameCore(String aUserNameFull) {
		String userNameCore = "";
		if (aUserNameFull != null && aUserNameFull.trim().length() > 0) {
			int wSpIdx = aUserNameFull.indexOf(" ");
			if (wSpIdx > 0) {
				userNameCore = aUserNameFull.substring(0, wSpIdx).trim();
			} else {
				userNameCore = aUserNameFull.trim();
			}
		}
		return userNameCore;
	}

	String extractUserNameFromEmail(String aUserEmail) {
		String userNameCore = aUserEmail;
		if (aUserEmail != null && aUserEmail.trim().length() > 3) {
			int wSpIdx = aUserEmail.indexOf("@");
			if (wSpIdx > 0) {
				userNameCore = aUserEmail.substring(0, wSpIdx).trim();
			} else {
				userNameCore = aUserEmail.trim();
			}
		}
		return userNameCore;
	}

	private final String UNUSED_substituteNullName(String aUserName) {
		/// ~~ Exception for charting - add some name to make the label for null or "" names
		if (aUserName == null || aUserName.trim().length() == 0) {
			return "_BLANK_"; // ~~ Seems to be never used, may be rtemoved may be?
		} else
			return aUserName;
	}

	String[] splitFullLineBySeverityLevel(String aFullLine) {
		/// System.out.println("~in-line: " + aFullLine); ///DEBUG
		if (aFullLine != null && aFullLine.length() > 0) {
			String p0HeadTimeActingService = "";
			String p1SeverityLevel = "";
			String p2Tail = "";
			Integer idx = null;
			boolean isFound = false;
			for (EpLogAnalyzer.EnumSeverity severity : EpLogAnalyzer.EnumSeverity.values()) {
				String severityStr = " " + severity.toString() + " ";
				idx = aFullLine.indexOf(severityStr);
				if (idx != null && idx > 0) {
					isFound = true;
					p0HeadTimeActingService = aFullLine.substring(0, idx);
					p1SeverityLevel = severity.toString();
					p2Tail = aFullLine.substring(idx + severityStr.length());
					String[] splittedFullLine = { p0HeadTimeActingService, p1SeverityLevel, p2Tail };
					/// System.out.println("\tFound Severity: " + severity + " at " + idx); ///DEBUG
					return splittedFullLine;
				}
			}
			if (!isFound) {
				System.err.println("~ERR:No Severity1: " + aFullLine); /// DEBUG
				return null;
			}
		}
		System.err.println("~ERR:No Severity2: " + aFullLine); /// DEBUG
		return null;
	}

	private final String UNUSED_fundReportLineSeverityLevel(String aFullLine) {
		String severityLevel = "";
		if (aFullLine != null) {
			if (aFullLine.contains(" " + EnumSeverity.TRACE + " ")) {
				severityLevel = EnumSeverity.TRACE.toString();
			} else if (aFullLine.contains(" " + EnumSeverity.DEBUG + " ")) {
				severityLevel = EnumSeverity.DEBUG.toString();
			} else if (aFullLine.contains(" " + EnumSeverity.INFO + " ")) {
				severityLevel = EnumSeverity.INFO.toString();
			} else if (aFullLine.contains(" " + EnumSeverity.WARN + " ")) {
				severityLevel = EnumSeverity.WARN.toString();
			} else if (aFullLine.contains(" " + EnumSeverity.ERROR + " ")) {
				severityLevel = EnumSeverity.ERROR.toString();
			} else if (aFullLine.contains(" " + EnumSeverity.FATAL + " ")) {
				severityLevel = EnumSeverity.FATAL.toString();
			} else if (aFullLine.contains(" " + EnumSeverity.SEVERE + " ")) {
				severityLevel = EnumSeverity.SEVERE.toString();
			}
		}
		return severityLevel;
	}

	public boolean ifSeverityLevelIsAnError(String aSeverityLevel) {
		if (false) {
			for (EpLogAnalyzer.EnumSeverity severity : EpLogAnalyzer.EnumSeverity.values()) {
				if (aSeverityLevel.compareTo(severity.toString()) == 0) {
					break;
				} else {
					// System.out.println("Missisng in the enum: " + severity.toString() + " " + aSeverityLevel);
				}
			}
		}
		boolean severityLevel = false;
		if (aSeverityLevel != null) {
			severityLevel = severityLevel || aSeverityLevel.contains(EpLogAnalyzer.EnumSeverity.WARN.toString()) && EpLogAnalyzer.SysSetngs.isJiraLogsIsCollectWarnings();
			severityLevel = severityLevel || aSeverityLevel.contains(EpLogAnalyzer.EnumSeverity.ERROR.toString());
			severityLevel = severityLevel || aSeverityLevel.contains(EpLogAnalyzer.EnumSeverity.FATAL.toString());
			severityLevel = severityLevel || aSeverityLevel.contains(EpLogAnalyzer.EnumSeverity.SEVERE.toString());
		}
		return severityLevel;
	}

	boolean isShowStringsWhichHasSubString(String aKey) {
		boolean isShow1 = aKey.startsWith(chartSectionPrefixOfCompressedReportLinesWithSubstring);
		return isShow1;
	}

	String buildTheKeyForTheRankGrouping(String aUserNameCore, String aMethodAndEndpointShort, Long anExecutionTimeMilliSec, EnumReportKind aReportKind, PojoJiraLogRowData aSeverityLevel) {
		String key = "";
		if (aReportKind != null) {
			key += "" + theSourceLogKey; // " .in:'" --extra leading space could keep this line at the top of the list, if all before is null
			key += "'" + aReportKind.toString() + "'";
		}
		key += " ";
		/// ~~ Do not add SeverityLevel level, if it's not ERR, or WARN, etc
		if (aSeverityLevel.getSeverityLevel() == null || aSeverityLevel.getSeverityLevel().length() == 0 || aSeverityLevel.getSeverityLevel().equalsIgnoreCase(EnumSeverity.INFO.toString())) {
			if (aSeverityLevel.getHttpResponseStatusCode() >= ConstantsOfJiraLogs.HTTPStatusCodeGE400Fault) {
				aSeverityLevel.setSeverityLevel(EnumSeverity.ERROR.toString());
			} else if (aSeverityLevel.getHttpResponseStatusCode() >= ConstantsOfJiraLogs.HTTPStatusCodeGE300Rout) {
				aSeverityLevel.setSeverityLevel(EnumSeverity.WARN.toString());
			} else {
				/// ~~ Do not modify existing level, if it's already set to some kind of ERROR+ level
			}
		}
		/// ~~ ONLY Add HttpResponseStatusCode to the key if it's ABOVE 300
		if (aSeverityLevel.getHttpResponseStatusCode() >= ConstantsOfJiraLogs.HTTPStatusCodeGE300Rout) {
			key += httpErrorCode + aSeverityLevel.getHttpResponseStatusCode() + " ";
		}
		if (aUserNameCore != null && aUserNameCore.trim().length() > 0) {
			key += responsibleUserWhoKey + "'" + aUserNameCore + "'"; // ~~ Add UserName
		}
		if (aMethodAndEndpointShort != null && aMethodAndEndpointShort.trim().length() > 0) {
			key += " ep:'" + aMethodAndEndpointShort + "'";
		}
		double exectn;
		if (EpLogAnalyzer.SysSetngs != null && EpLogAnalyzer.SysSetngs.isAccessLogGroupApiCallsByExecutionTime()) {
			if (anExecutionTimeMilliSec != null && anExecutionTimeMilliSec >= 0) {
				exectn = anExecutionTimeMilliSec / 1000.0;
				exectn = (double) Math.round(exectn);
				key += " " + String.format("%04.0f", exectn) + "s"; // max 9999 Sec
			}
		}
		/// ~~ these two values are not available at the moment when I need a key, so just add the label later
		/// if (anExecutionTimeSumPerRankMilliSec != null && anExecutionTimeSumPerRankMilliSec >= 0) {
		/// exectn = anExecutionTimeSumPerRankMilliSec / 1000.0;
		/// exectn = (double) Math.round(exectn);
		/// key += " " + String.format("%04.0f", exectn) + "S"; // 3600 Sec
		/// }
		/// if (anEventsPerRank > -1) {key += "x" + anEventsPerRank;}

		/// ~~ Business Rules Filter ~~
		if (EpLogAnalyzer.SysSetngs != null && EpLogAnalyzer.SysSetngs.isJiraLogsIsCollectErrorsAndWarnings()) {
			if (aSeverityLevel.getSeverityLevel() != null) {
				if (aSeverityLevel.getSeverityLevel().equals(EnumSeverity.WARN.toString()) && EpLogAnalyzer.SysSetngs.isJiraLogsIsCollectWarnings() //
						|| aSeverityLevel.getSeverityLevel().equals(EnumSeverity.ERROR.toString()) //
						|| aSeverityLevel.getSeverityLevel().equals(EnumSeverity.FATAL.toString()) //
						|| aSeverityLevel.getSeverityLevel().equals(EnumSeverity.SEVERE.toString())) {
					key = chartSectionPrefixOfCompressedReportLinesWithError // ~~ '!'
							+ aSeverityLevel.getSeverityLevel().substring(0, 3) // e.g. '!ERR', !FAT
							+ key;
				} else {
					//--ADD: jiraLogs.isCollectUsers_UNUSED":false, "rem":"if isCollectErrorsAndWarnings=true add noisy list of users at the bottom",
					key = "!SeverityLevel: " + aSeverityLevel.getSeverityLevel(); // --comment this line to convert summary to to noisy list of users at the bottom.
				}
			} else {
				key = "!!2 aSeverityLevel.getSeverityLevel=null"; // --NEW TODO
			}
		} else {
			key = "!!3 isJiraLogsIsCollectErrorsAndWarnings=false"; // --NEW TODO
		}
		// System.out.println(key);
		return key;
	}

	String extractTheActingServiceCore(String anActingServiceFull) {
		String theActingServiceCore = anActingServiceFull;
		// System.out.println("actingServiceFull: " + anActingServiceFull);
		if (anActingServiceFull != null && anActingServiceFull.length() > 2) {
			String _split[] = anActingServiceFull.split("-");
			if (_split.length > 1) {
				String _lastToken = _split[_split.length - 1];
				int saveLastTokenStringSize = _lastToken.length();
				// ~~ test if it's int
				try {
					int _lastInt = Integer.parseInt(_lastToken);
					// ~~ Yes, last subString is the integer ~~
					theActingServiceCore = anActingServiceFull.substring(0, anActingServiceFull.length() - saveLastTokenStringSize - 1);
					// System.out.println("actingServiceCore: " + theActingServiceCore);
				} catch (NumberFormatException e) {
					// ~~ it's not int, so clone full string
					theActingServiceCore = anActingServiceFull;
				}
			} else { // ~~ Single word, so just clone it
				theActingServiceCore = anActingServiceFull;
			}
		}
		return theActingServiceCore;
	}

	void extractHttpRequestApiCallCore(PojoJiraLogRowData aJiraLogRow) {
		int aNumberOfSubDomainLevels = 2; // group by very beginning of URL, e.g. '/rest/api'
		if (EpLogAnalyzer.SysSetngs != null) {
			aNumberOfSubDomainLevels = EpLogAnalyzer.SysSetngs.getAccessLogGroupApiCallsByPathDepth();
		}
		if (aJiraLogRow != null) {
			if (aJiraLogRow.getHttpRequestApiCallFull().contains("null null- null")) {
				aJiraLogRow.setHttpRequestApiCallCore("null");
			} else if (aJiraLogRow.getHttpRequestApiCallFull().contains("null null-")) {
				aJiraLogRow.setHttpRequestApiCallCore("null");
			} else if (aJiraLogRow.getHttpRequestApiCallFull().contains("GET /-")) {
				aJiraLogRow.setHttpRequestApiCallCore("null");
			} else {
				String _httpRequestApiCallFull = aJiraLogRow.getHttpRequestApiCallFull();
				// System.out.println("~~: " + aJiraLogRow.getFullOriginalLine());
				if (_httpRequestApiCallFull != null && _httpRequestApiCallFull.length() > 2) {
					try {
						_httpRequestApiCallFull = _httpRequestApiCallFull.substring(_httpRequestApiCallFull.indexOf(' ') + 1); // ~~ remove Method (GET, PUT etc)
						String _split[] = _httpRequestApiCallFull.split("/"); // ~~Note: _split[0] always == "", so skip it
						if (_split.length > 0) {
							if (_split[1].compareTo("s") == 0) {
								// ~~ if URL started with '/s/' , remove it. Eg. GET /s/f0cb540872c0399a346a6ed95da5cf2b-CDN/piyjd7/930001/
								aJiraLogRow.setHttpRequestApiCallCore("/s/{some uuid}");
							} else {
								if (true || _split.length > aNumberOfSubDomainLevels) {
									String coreUrl = ""; // _split[0] + "/" + _split[1] + "/" + _split[2] + "/" + _split[3] + "/" + _split[4] + "/";
									int maxLoops = Math.min(aNumberOfSubDomainLevels + 1, _split.length);
									for (int ii = 1; ii < maxLoops; ii++) {
										coreUrl += "/" + _split[ii];
									}
									aJiraLogRow.setHttpRequestApiCallCore(coreUrl);
									// System.out.println("HttpRequestApiCallCore: " + _core);
								} else { // ~~ Single word, so just clone it
									// aJiraLogRow.setHttpRequestApiCallCore(_httpRequestApiCallFull);
								}
							}
						} else {
							aJiraLogRow.setHttpRequestApiCallCore("/");
						}
					} catch (Exception e) {
						// System.err.println("ERR077: " + e.getMessage() + "\n\t" + aJiraLogRow.getHttpRequestApiCallFull());
					}
				}
			}
		}
	}

	final int nthOccurrence(String aFullLine, String aCharOfOccurrence, int anOccurrence) {
		// TODO attention: check last arrSplit01 needed
		String tempStr = aFullLine;
		int tempIndex = -1;
		int finalIndex = 0;
		for (int occurrence = 0; occurrence < anOccurrence; ++occurrence) {
			tempIndex = tempStr.indexOf(aCharOfOccurrence);
			if (tempIndex == -1) {
				finalIndex = 0;
				break;
			}
			tempStr = tempStr.substring(++tempIndex);
			finalIndex += tempIndex;
		}
		// System.out.println("~~ str1 " + str1.length() + " -- str1" + str1);
		return --finalIndex;
	}

}
